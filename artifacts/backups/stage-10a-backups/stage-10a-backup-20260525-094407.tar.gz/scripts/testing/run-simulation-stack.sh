#!/usr/bin/env bash

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")"/../.. && pwd)"

source "${ROOT_DIR}/runtime/python/testing/venv/bin/activate"

echo "=================================================="
echo "STARTING SIMULATION STACK"
echo "=================================================="

python tests/mock-services/brokers/mock-broker.py &
BROKER_PID=$!

python tests/mock-services/market-data/synthetic-market-generator.py

echo "Mock Broker PID: ${BROKER_PID}"

echo ""
echo "Simulation stack initialized"
