#!/usr/bin/env bash

set -euo pipefail

echo "[Testing] setup-test-env initialized"
