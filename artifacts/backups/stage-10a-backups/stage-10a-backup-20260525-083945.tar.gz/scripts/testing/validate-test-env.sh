#!/usr/bin/env bash

set -euo pipefail

echo "[Testing] validate-test-env initialized"
