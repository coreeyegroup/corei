#!/usr/bin/env bash

set -euo pipefail

echo "[Testing] run-tests initialized"
