/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-07
 *
 * FILE
 * docking-engine.ts
 * ============================================================================
 */

import type {

    DockTree

} from "../models/dock-tree";

import type {

    DockNode

} from "../contracts/dock-node";

class DockingEngine {

    create(): DockTree {

        return {

            nodes: []

        };

    }

    add(

        tree: DockTree,

        node: DockNode

    ): DockTree {

        return {

            nodes: [

                ...tree.nodes,

                node

            ]

        };

    }

    remove(

        tree: DockTree,

        id: string

    ): DockTree {

        return {

            nodes:

                tree.nodes.filter(

                    node => node.id !== id

                )

        };

    }

}

export const dockingEngine =

new DockingEngine();

