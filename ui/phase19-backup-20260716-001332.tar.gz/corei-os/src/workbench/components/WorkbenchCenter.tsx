/**
 * ============================================================================
 * STAGE-25
 * STEP-01
 * BUILD UNIT-18
 *
 * FILE
 * WorkbenchCenter.tsx
 *
 * PURPOSE
 * Pure Workbench View
 *
 * RESPONSIBILITIES
 * - Render Tabs
 * - Render Dockview
 * - Handle Panel Focus
 *
 * DOES NOT
 * - Initialize Runtime
 * - Load Workspace
 * - Open Tabs
 * - Create Panels
 * ============================================================================
 */

import {

    WorkbenchTabs

} from "../tabs/components/WorkbenchTabs";

import {

    DockviewAdapter

} from "../../foundation/workspace/adapters/dockview-adapter";

import {

    panelFocusRuntime

} from "../panels/runtime";

import {

    usePanelFocusState

} from "../panels/state";

export function WorkbenchCenter():

React.JSX.Element {

    const focusedPanel =

        usePanelFocusState(

            state => state.focusedPanel

        );

    return (

        <div
            style={{

                height: "100%",

                display: "grid",

                gridTemplateRows:

                    "34px 1fr"

            }}
        >

            <WorkbenchTabs/>

            <div

                onClick={() =>

                    panelFocusRuntime.focus(

                        "editor"

                    )

                }

                style={{

                    overflow: "hidden",

                    border:

                        focusedPanel === "editor"

                            ? "1px solid #007ACC"

                            : "1px solid transparent",

                    transition:

                        "border 150ms ease"

                }}

            >

                <DockviewAdapter/>

            </div>

        </div>

    );

}