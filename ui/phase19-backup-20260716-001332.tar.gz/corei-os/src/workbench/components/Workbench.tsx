/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-03
 *
 * FILE
 * Workbench.tsx
 *
 * PURPOSE
 * Institutional Workbench Shell
 * ============================================================================
 */

import { useEffect } from "react";

import { WorkbenchCenter } from "./WorkbenchCenter";
import { ActivityBar } from "../activity-bar/ActivityBar";
import { Sidebar } from "../sidebar/Sidebar";

import { workbenchRuntime } from "../runtime/workbench-runtime";

import { useSidebarState } from "../sidebar/state/sidebar-state";

import { useDockState } from "../docking/state";

import { ResizeHandle } from "../docking/components/ResizeHandle";

export function Workbench(): React.JSX.Element {

    useEffect(() => {

        workbenchRuntime.initialize();

        return () => {

            workbenchRuntime.dispose();

        };

    }, []);

    const {

        visible,
        width

    } = useSidebarState();

    const {

        layout

    } = useDockState();

    return (

        <div
            style={{

                width: "100vw",

                height: "100vh",

                display: "grid",

                gridTemplateColumns:

                    `52px ${visible ? layout.leftWidth : 0}px 1fr ${layout.rightWidth}px`,

                gridTemplateRows:

                    `32px 1fr ${layout.bottomHeight}px 24px`,

                transition:

                    "grid-template-columns 180ms ease, grid-template-rows 180ms ease",

                background: "#1e1e1e",

                color: "#d4d4d4",

                overflow: "hidden"

            }}
        >

            <header
                style={{
                    gridColumn: "1 / 5",
                    gridRow: "1",
                    display: "flex",
                    alignItems: "center",
                    paddingInline: "10px",
                    borderBottom: "1px solid #313131",
                    background: "#181818",
                    fontWeight: 500,
                    fontSize: "12px"
                }}
            >
                COREI TOP RIBBON
            </header>

            <aside
                style={{
                    gridColumn: "1",
                    gridRow: "2 / 4",
                    borderRight: "1px solid #313131",
                    background: "#181818",
                    overflow: "hidden"
                }}
            >
                <ActivityBar/>
            </aside>

            <aside
                style={{
                    gridColumn: "2",
                    gridRow: "2 / 4",
                    borderRight: "1px solid #313131",
                    background: "#252526",
                    overflow: "hidden"
                }}
            >
                <Sidebar/>
            </aside>

            <main
                style={{
                    gridColumn: "3",
                    gridRow: "2",
                    borderRight: "1px solid #313131",
                    overflow: "hidden",
                    background: "#111111"
                }}
            >
                <WorkbenchCenter/>
            </main>

            <aside
                style={{
                    gridColumn: "4",
                    gridRow: "2 / 4",
                    borderLeft: "1px solid #313131",
                    background: "#252526",
                    overflow: "hidden"
                }}
            />

            <section
                style={{
                    gridColumn: "3",
                    gridRow: "3",
                    borderTop: "1px solid #313131",
                    background: "#181818",
                    overflow: "hidden"
                }}
            />

            <footer
                style={{
                    gridColumn: "1 / 5",
                    gridRow: "4",
                    display: "flex",
                    alignItems: "center",
                    paddingInline: "10px",
                    background: "#007acc",
                    color: "#ffffff",
                    fontSize: "10px"
                }}
            >
                COREI STATUS BAR
            </footer>

        </div>

    );

}