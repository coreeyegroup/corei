/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-15 — Shell ↔ Workbench ↔ Workspace Runtime Integration
 *
 * File:
 *   WindowWorkspaceRuntimeProvider.tsx
 *
 * Purpose:
 *   Exposes the Phase-19 Window & Workspace Platform integration authority to
 *   the Workbench React subtree without allowing the Institutional Shell to
 *   consume Phase-19 implementation internals.
 *
 * Ownership:
 *   Workbench integration boundary.
 *
 * Important:
 *   This provider does not construct Phase-19 authorities. The fully composed
 *   integration authority is injected by the Workbench composition root.
 *
 * =============================================================================
 */

import {
  createContext,
  useContext,
  useEffect,
  type ReactNode,
} from "react";

import type {
  ShellWorkbenchWorkspaceRuntimeIntegrationContract,
} from "../../window-workspace-platform";

/* =============================================================================
 * SECTION 01 — CONTEXT
 * =============================================================================
 */

const WindowWorkspaceRuntimeContext =
  createContext<
    ShellWorkbenchWorkspaceRuntimeIntegrationContract | null
  >(null);

/* =============================================================================
 * SECTION 02 — PROVIDER PROPS
 * =============================================================================
 */

export interface WindowWorkspaceRuntimeProviderProps {
  readonly integration:
    ShellWorkbenchWorkspaceRuntimeIntegrationContract;

  readonly children:
    ReactNode;
}

/* =============================================================================
 * SECTION 03 — PROVIDER
 * =============================================================================
 */

export function WindowWorkspaceRuntimeProvider({
  integration,
  children,
}: WindowWorkspaceRuntimeProviderProps) {
  useEffect(() => {
    integration.initialize();
    integration.start();

    return () => {
      integration.stop();
    };
  }, [integration]);

  return (
    <WindowWorkspaceRuntimeContext.Provider
      value={integration}
    >
      {children}
    </WindowWorkspaceRuntimeContext.Provider>
  );
}

/* =============================================================================
 * SECTION 04 — CONSUMPTION HOOK
 * =============================================================================
 */

export function useWindowWorkspaceRuntime():
  ShellWorkbenchWorkspaceRuntimeIntegrationContract {
  const integration =
    useContext(WindowWorkspaceRuntimeContext);

  if (integration === null) {
    throw new Error(
      "useWindowWorkspaceRuntime must be used within WindowWorkspaceRuntimeProvider.",
    );
  }

  return integration;
}
