/**
 * =============================================================================
 * COREI — WORKBENCH / WINDOW-WORKSPACE INTEGRATION
 * =============================================================================
 *
 * Public Workbench integration surface for Stage-25 Phase-19 Step-15.
 *
 * =============================================================================
 */

export {
  WindowWorkspaceRuntimeProvider,
  useWindowWorkspaceRuntime,
} from "./WindowWorkspaceRuntimeProvider";

export type {
  WindowWorkspaceRuntimeProviderProps,
} from "./WindowWorkspaceRuntimeProvider";
