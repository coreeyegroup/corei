/**
 * ============================================================================
 * STAGE-25
 * STEP-01
 * BUILD UNIT-17
 *
 * FILE
 * layout-runtime.ts
 *
 * PURPOSE
 * Temporary Layout Runtime
 *
 * DESCRIPTION
 * - Resolves workspace.
 * - Resolves layout.
 * - Does NOT create Dockview panels.
 * - Manual initialize() remains authoritative.
 * - Registry-driven Dockview creation will be implemented later.
 * ============================================================================
 */

import type {

    DockviewApi

} from "dockview";

import {

    workspaceRegistry,
    layoutRegistry

} from "../registries";

export class LayoutRuntime {

    load(

        api: DockviewApi,

        workspaceId: string

    ): void {

        /*
         * Resolve workspace
         */

        const workspace = workspaceRegistry.get(

            workspaceId

        );

        if (!workspace) {

            console.warn(

                "[LayoutRuntime] Workspace not found:",

                workspaceId

            );

            return;

        }

        /*
         * Resolve layout
         */

        const layout = layoutRegistry.get(

            workspace.layout

        );

        if (!layout) {

            console.warn(

                "[LayoutRuntime] Layout not found:",

                workspace.layout

            );

            return;

        }

        /*
         * Temporary runtime.
         *
         * BU-17 intentionally DOES NOT create Dockview panels.
         *
         * Manual initialize() in WorkbenchCenter remains the
         * authoritative layout builder until the Registry Driven
         * Dockview Runtime is completed.
         */

        console.log(

            "[LayoutRuntime]",

            {

                workspace,

                layout

            }

        );

        void api;

    }

}

export const layoutRuntime = new LayoutRuntime();