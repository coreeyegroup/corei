/**
 * ============================================================================
 * Register Institutional Panel Catalog
 * ============================================================================
 */

import {

    panelRuntime

} from "./panel-runtime";

import {

    panelCatalog

} from "../catalog";

for (

    const panel

    of panelCatalog

) {

    panelRuntime.register(

        panel

    );

}