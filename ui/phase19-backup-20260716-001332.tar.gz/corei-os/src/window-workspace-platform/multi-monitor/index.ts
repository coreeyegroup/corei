/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM MULTI-MONITOR RUNTIME
 * =============================================================================
 *
 * Public multi-monitor runtime surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  MultiMonitorRuntime,
} from "./multi-monitor-runtime";
