/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   multi-monitor-runtime.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-10 — Multi-Monitor Runtime
 *
 * Purpose:
 *   Provides deterministic provider-neutral monitor topology and runtime-window
 *   placement management.
 *
 * Ownership:
 *   - Owns logical monitor registration.
 *   - Owns primary-monitor identity.
 *   - Owns runtime-window-to-monitor assignment.
 *   - Owns placement metadata.
 *   - Consults Step-09 Multi-Window Runtime as runtime-window authority.
 *   - Does not discover physical monitors.
 *   - Does not move or resize browser windows.
 *   - Does not execute browser Screen APIs.
 *   - Does not execute Dockview APIs.
 *   - Does not render UI.
 *   - Does not persist state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  MultiMonitorRuntimeContract,
  MultiMonitorRuntimeSnapshot,
} from "../contracts/multi-monitor-runtime.contract";

import type {
  MultiWindowRuntimeContract,
} from "../contracts/multi-window-runtime.contract";

import type {
  MonitorBounds,
  MonitorId,
  MonitorReference,
  RuntimeWindowId,
  RuntimeWindowMonitorAssignment,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateMonitorMessage = (
  monitorId: MonitorId,
): string =>
  `Monitor is already registered: ${monitorId}`;

const unknownMonitorMessage = (
  monitorId: MonitorId,
): string =>
  `Monitor is not registered: ${monitorId}`;

const invalidBoundsMessage = (): string =>
  "Monitor bounds must be finite and dimensions must be greater than zero";

const unknownRuntimeWindowMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window is not registered: ${runtimeWindowId}`;

const assignedMonitorRemovalMessage = (
  monitorId: MonitorId,
): string =>
  `Monitor cannot be unregistered while runtime windows are assigned: ${monitorId}`;

const unknownAssignmentMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window does not have a monitor assignment: ${runtimeWindowId}`;

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyBounds = (
  bounds: MonitorBounds,
): MonitorBounds => ({
  x: bounds.x,
  y: bounds.y,
  width: bounds.width,
  height: bounds.height,
});

const copyMonitorReference = (
  monitor: MonitorReference,
): MonitorReference => ({
  monitorId: monitor.monitorId,
  isPrimary: monitor.isPrimary,
  bounds: copyBounds(monitor.bounds),
  workArea: copyBounds(monitor.workArea),
});

const copyAssignment = (
  assignment: RuntimeWindowMonitorAssignment,
): RuntimeWindowMonitorAssignment => ({
  runtimeWindowId: assignment.runtimeWindowId,
  monitorId: assignment.monitorId,
  bounds: copyBounds(assignment.bounds),
  placementMode: assignment.placementMode,
});

/* =============================================================================
 * SECTION 03 — MULTI-MONITOR RUNTIME
 * =============================================================================
 */

export class MultiMonitorRuntime
  implements MultiMonitorRuntimeContract
{
  private readonly monitors =
    new Map<MonitorId, MonitorReference>();

  private readonly assignments =
    new Map<
      RuntimeWindowId,
      RuntimeWindowMonitorAssignment
    >();

  private primaryMonitorId: MonitorId | null = null;

  public constructor(
    private readonly multiWindowRuntime:
      MultiWindowRuntimeContract,
  ) {}

  /* ===========================================================================
   * MONITOR REGISTRATION
   * ===========================================================================
   */

  public registerMonitor(
    monitor: MonitorReference,
  ): void {
    if (this.monitors.has(monitor.monitorId)) {
      throw new Error(
        duplicateMonitorMessage(monitor.monitorId),
      );
    }

    this.validateBounds(monitor.bounds);
    this.validateBounds(monitor.workArea);

    const shouldBePrimary =
      this.primaryMonitorId === null ||
      monitor.isPrimary;

    if (monitor.isPrimary) {
      this.demoteCurrentPrimary();
    }

    const reference: MonitorReference = {
      monitorId: monitor.monitorId,
      isPrimary: shouldBePrimary,
      bounds: copyBounds(monitor.bounds),
      workArea: copyBounds(monitor.workArea),
    };

    this.monitors.set(
      reference.monitorId,
      reference,
    );

    if (shouldBePrimary) {
      this.primaryMonitorId =
        reference.monitorId;
    }
  }

  public unregisterMonitor(
    monitorId: MonitorId,
  ): void {
    this.requireMonitor(monitorId);

    const hasAssignments = Array.from(
      this.assignments.values(),
    ).some(
      (assignment) =>
        assignment.monitorId === monitorId,
    );

    if (hasAssignments) {
      throw new Error(
        assignedMonitorRemovalMessage(monitorId),
      );
    }

    const wasPrimary =
      this.primaryMonitorId === monitorId;

    this.monitors.delete(monitorId);

    if (wasPrimary) {
      this.primaryMonitorId = null;

      const nextMonitor =
        this.monitors.values().next().value as
          | MonitorReference
          | undefined;

      if (nextMonitor !== undefined) {
        this.setPrimaryMonitor(
          nextMonitor.monitorId,
        );
      }
    }
  }

  /* ===========================================================================
   * MONITOR LOOKUP
   * ===========================================================================
   */

  public hasMonitor(
    monitorId: MonitorId,
  ): boolean {
    return this.monitors.has(monitorId);
  }

  public getMonitor(
    monitorId: MonitorId,
  ): MonitorReference | null {
    const monitor = this.monitors.get(monitorId);

    return monitor === undefined
      ? null
      : copyMonitorReference(monitor);
  }

  public getMonitors():
    readonly MonitorReference[] {
    return Array.from(
      this.monitors.values(),
      copyMonitorReference,
    );
  }

  public getPrimaryMonitor():
    MonitorReference | null {
    if (this.primaryMonitorId === null) {
      return null;
    }

    return this.getMonitor(this.primaryMonitorId);
  }

  public setPrimaryMonitor(
    monitorId: MonitorId,
  ): void {
    const monitor = this.requireMonitor(monitorId);

    this.demoteCurrentPrimary();

    this.monitors.set(
      monitorId,
      {
        ...monitor,
        isPrimary: true,
      },
    );

    this.primaryMonitorId = monitorId;
  }

  /* ===========================================================================
   * RUNTIME WINDOW ASSIGNMENT
   * ===========================================================================
   */

  public assignRuntimeWindow(
    assignment: RuntimeWindowMonitorAssignment,
  ): void {
    const runtimeWindow =
      this.multiWindowRuntime.getRuntimeWindow(
        assignment.runtimeWindowId,
      );

    if (runtimeWindow === null) {
      throw new Error(
        unknownRuntimeWindowMessage(
          assignment.runtimeWindowId,
        ),
      );
    }

    this.requireMonitor(assignment.monitorId);
    this.validateBounds(assignment.bounds);

    this.assignments.set(
      assignment.runtimeWindowId,
      copyAssignment(assignment),
    );
  }

  public removeRuntimeWindowAssignment(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    if (!this.assignments.has(runtimeWindowId)) {
      throw new Error(
        unknownAssignmentMessage(runtimeWindowId),
      );
    }

    this.assignments.delete(runtimeWindowId);
  }

  public getRuntimeWindowAssignment(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowMonitorAssignment | null {
    const assignment =
      this.assignments.get(runtimeWindowId);

    return assignment === undefined
      ? null
      : copyAssignment(assignment);
  }

  public getAssignments():
    readonly RuntimeWindowMonitorAssignment[] {
    return Array.from(
      this.assignments.values(),
      copyAssignment,
    );
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot():
    MultiMonitorRuntimeSnapshot {
    return {
      monitors: this.getMonitors(),
      primaryMonitorId: this.primaryMonitorId,
      assignments: this.getAssignments(),
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireMonitor(
    monitorId: MonitorId,
  ): MonitorReference {
    const monitor = this.monitors.get(monitorId);

    if (monitor === undefined) {
      throw new Error(
        unknownMonitorMessage(monitorId),
      );
    }

    return monitor;
  }

  private validateBounds(
    bounds: MonitorBounds,
  ): void {
    const values = [
      bounds.x,
      bounds.y,
      bounds.width,
      bounds.height,
    ];

    if (
      values.some(
        (value) => !Number.isFinite(value),
      ) ||
      bounds.width <= 0 ||
      bounds.height <= 0
    ) {
      throw new Error(invalidBoundsMessage());
    }
  }

  private demoteCurrentPrimary(): void {
    if (this.primaryMonitorId === null) {
      return;
    }

    const current =
      this.monitors.get(this.primaryMonitorId);

    if (current !== undefined) {
      this.monitors.set(
        current.monitorId,
        {
          ...current,
          isPrimary: false,
        },
      );
    }

    this.primaryMonitorId = null;
  }
}
