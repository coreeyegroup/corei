/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM LIFECYCLE
 * =============================================================================
 *
 * Public lifecycle coordination surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  WorkspaceEventsStateLifecycleCoordinator,
} from "./workspace-events-state-lifecycle-coordinator";
