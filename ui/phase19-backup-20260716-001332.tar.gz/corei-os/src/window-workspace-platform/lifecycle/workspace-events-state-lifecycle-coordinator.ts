/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-16 — Workspace Events, State & Lifecycle Coordination
 *
 * File:
 *   workspace-events-state-lifecycle-coordinator.ts
 *
 * Purpose:
 *   Coordinates deterministic Phase-19 lifecycle events and state projection,
 *   then delegates publication through injected Event Platform and State
 *   Platform adapter ports.
 *
 * Architectural Boundary:
 *   This coordinator owns Phase-19 coordination semantics only.
 *
 *   It does not implement:
 *   - an event bus;
 *   - a global state store;
 *   - Event Platform infrastructure;
 *   - State Platform infrastructure;
 *   - diagnostics;
 *   - telemetry;
 *   - UI state.
 *
 * =============================================================================
 */

import type {
  WorkspaceEventsStateLifecycleContract,
  WorkspaceEventsStateLifecycleSnapshot,
  WorkspacePlatformEventPublicationPort,
  WorkspacePlatformLifecycleEvent,
  WorkspacePlatformLifecycleEventType,
  WorkspacePlatformLifecycleState,
  WorkspacePlatformStatePublicationPort,
} from "../contracts/workspace-events-state-lifecycle.contract";

/* =============================================================================
 * SECTION 01 — INITIAL STATE
 * =============================================================================
 */

const INITIAL_STATE:
  WorkspacePlatformLifecycleState = {
    sequence: 0,
    activeWorkspaceId: null,
    activeWindowId: null,
    activeLayoutId: null,
    persistenceCompleted: false,
    recoveryInProgress: false,
    recoveryFailed: false,
    lastEventType: null,
  };

/* =============================================================================
 * SECTION 02 — COORDINATOR
 * =============================================================================
 */

export class WorkspaceEventsStateLifecycleCoordinator
  implements WorkspaceEventsStateLifecycleContract
{
  private sequence = 0;

  private state:
    WorkspacePlatformLifecycleState = {
      ...INITIAL_STATE,
    };

  private readonly events:
    WorkspacePlatformLifecycleEvent[] = [];

  public constructor(
    private readonly eventPublicationPort:
      WorkspacePlatformEventPublicationPort,

    private readonly statePublicationPort:
      WorkspacePlatformStatePublicationPort,
  ) {}

  /* ===========================================================================
   * COORDINATION
   * ===========================================================================
   */

  public coordinate(
    type:
      WorkspacePlatformLifecycleEventType,

    context: {
      readonly workspaceId?:
        WorkspacePlatformLifecycleEvent["workspaceId"];

      readonly windowId?:
        WorkspacePlatformLifecycleEvent["windowId"];

      readonly layoutId?:
        WorkspacePlatformLifecycleEvent["layoutId"];
    } = {},
  ): Readonly<WorkspacePlatformLifecycleEvent> {
    this.sequence += 1;

    const event:
      WorkspacePlatformLifecycleEvent = {
        type,
        sequence: this.sequence,
        workspaceId:
          context.workspaceId ?? null,
        windowId:
          context.windowId ?? null,
        layoutId:
          context.layoutId ?? null,
      };

    this.state =
      this.projectState(
        this.state,
        event,
      );

    this.events.push(event);

    this.eventPublicationPort.publish({
      ...event,
    });

    this.statePublicationPort.publish({
      ...this.state,
    });

    return {
      ...event,
    };
  }

  /* ===========================================================================
   * STATE PROJECTION
   * ===========================================================================
   */

  private projectState(
    current:
      Readonly<WorkspacePlatformLifecycleState>,

    event:
      Readonly<WorkspacePlatformLifecycleEvent>,
  ): WorkspacePlatformLifecycleState {
    const next:
      WorkspacePlatformLifecycleState = {
        ...current,
        sequence: event.sequence,
        lastEventType: event.type,
      };

    switch (event.type) {
      case "workspace.opened":
        return next;

      case "workspace.activated":
        return {
          ...next,
          activeWorkspaceId:
            event.workspaceId,
        };

      case "workspace.deactivated":
      case "workspace.closed":
        return {
          ...next,
          activeWorkspaceId:
            current.activeWorkspaceId ===
            event.workspaceId
              ? null
              : current.activeWorkspaceId,
        };

      case "window.opened":
        return next;

      case "window.focused":
        return {
          ...next,
          activeWindowId:
            event.windowId,
        };

      case "window.closed":
        return {
          ...next,
          activeWindowId:
            current.activeWindowId ===
            event.windowId
              ? null
              : current.activeWindowId,
        };

      case "layout.changed":
      case "layout.restored":
        return {
          ...next,
          activeLayoutId:
            event.layoutId,
        };

      case "workspace.persistence.completed":
        return {
          ...next,
          persistenceCompleted:
            true,
        };

      case "workspace.recovery.started":
        return {
          ...next,
          recoveryInProgress:
            true,
          recoveryFailed:
            false,
        };

      case "workspace.recovery.completed":
        return {
          ...next,
          recoveryInProgress:
            false,
          recoveryFailed:
            false,
        };

      case "workspace.recovery.failed":
        return {
          ...next,
          recoveryInProgress:
            false,
          recoveryFailed:
            true,
        };
    }
  }

  /* ===========================================================================
   * READ SURFACE
   * ===========================================================================
   */

  public getState():
    Readonly<WorkspacePlatformLifecycleState> {
    return {
      ...this.state,
    };
  }

  public getEvents():
    readonly Readonly<WorkspacePlatformLifecycleEvent>[] {
    return this.events.map(
      (event) => ({
        ...event,
      }),
    );
  }

  public getSnapshot():
    Readonly<WorkspaceEventsStateLifecycleSnapshot> {
    return {
      state:
        this.getState(),

      events:
        this.getEvents(),
    };
  }
}
