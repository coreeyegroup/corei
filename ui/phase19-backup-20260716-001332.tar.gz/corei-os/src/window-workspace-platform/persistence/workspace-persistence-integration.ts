/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-persistence-integration.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-13 — Workspace Persistence & Serialization Integration
 *
 * Purpose:
 *   Integrates canonical Phase-19 snapshot capture, deterministic serialization,
 *   and provider-neutral persistence delegation.
 *
 * Critical Boundary:
 *   Loading or deserializing a persistence record does not apply it to runtime
 *   state. Runtime restoration and recovery belong exclusively to Step-14.
 *
 * =============================================================================
 */

import type {
  WindowWorkspacePersistenceAdapter,
  WindowWorkspacePersistenceIntegrationContract,
  WindowWorkspacePersistenceSnapshot,
  WindowWorkspacePersistenceSnapshotSource,
  WindowWorkspaceSerializerContract,
} from "../contracts/workspace-persistence-serialization.contract";

import type {
  WindowWorkspacePersistenceKey,
  WindowWorkspacePersistenceRecord,
  WindowWorkspacePersistenceSchemaVersion,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — SCHEMA
 * =============================================================================
 */

const PERSISTENCE_SCHEMA_VERSION:
  WindowWorkspacePersistenceSchemaVersion =
    "corei.window-workspace.persistence.v1";

/* =============================================================================
 * SECTION 02 — INTEGRATION
 * =============================================================================
 */

export class WindowWorkspacePersistenceIntegration
  implements WindowWorkspacePersistenceIntegrationContract
{
  public constructor(
    private readonly snapshotSource:
      WindowWorkspacePersistenceSnapshotSource,

    private readonly serializer:
      WindowWorkspaceSerializerContract,

    private readonly adapter:
      WindowWorkspacePersistenceAdapter,
  ) {}

  /* ===========================================================================
   * CAPTURE
   * ===========================================================================
   */

  public capture():
    WindowWorkspacePersistenceSnapshot {
    const snapshot =
      this.snapshotSource.getPersistenceSnapshot();

    if (
      snapshot.schemaVersion !==
      PERSISTENCE_SCHEMA_VERSION
    ) {
      throw new Error(
        `Unsupported workspace persistence schema: ${snapshot.schemaVersion}`,
      );
    }

    return snapshot;
  }

  /* ===========================================================================
   * SERIALIZATION
   * ===========================================================================
   */

  public serialize(): string {
    return this.serializer.serialize(
      this.capture(),
    );
  }

  public deserializeRecord(
    record: WindowWorkspacePersistenceRecord,
  ): WindowWorkspacePersistenceSnapshot {
    this.requireRecordSchema(record);

    const snapshot =
      this.serializer.deserialize(
        record.serializedSnapshot,
      );

    if (
      snapshot.schemaVersion !==
      record.schemaVersion
    ) {
      throw new Error(
        "Persistence record schema does not match serialized snapshot schema.",
      );
    }

    return snapshot;
  }

  /* ===========================================================================
   * RECORD CREATION
   * ===========================================================================
   */

  public createRecord(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord {
    return {
      key,
      schemaVersion:
        PERSISTENCE_SCHEMA_VERSION,
      serializedSnapshot:
        this.serialize(),
    };
  }

  /* ===========================================================================
   * STORAGE DELEGATION
   * ===========================================================================
   */

  public save(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord {
    const record =
      this.createRecord(key);

    this.adapter.save(record);

    return record;
  }

  public load(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord | null {
    const record =
      this.adapter.load(key);

    if (record !== null) {
      this.requireRecordSchema(record);
    }

    return record;
  }

  public remove(
    key: WindowWorkspacePersistenceKey,
  ): void {
    this.adapter.remove(key);
  }

  public has(
    key: WindowWorkspacePersistenceKey,
  ): boolean {
    return this.adapter.has(key);
  }

  /* ===========================================================================
   * INTERNAL VALIDATION
   * ===========================================================================
   */

  private requireRecordSchema(
    record: WindowWorkspacePersistenceRecord,
  ): void {
    if (
      record.schemaVersion !==
      PERSISTENCE_SCHEMA_VERSION
    ) {
      throw new Error(
        `Unsupported workspace persistence record schema: ${record.schemaVersion}`,
      );
    }
  }
}
