/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM PERSISTENCE
 * =============================================================================
 *
 * Public persistence and deterministic serialization surface for
 * Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  DeterministicWorkspaceSerializer,
} from "./deterministic-workspace-serializer";

export {
  WindowWorkspacePersistenceIntegration,
} from "./workspace-persistence-integration";
