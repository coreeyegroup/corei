/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   deterministic-workspace-serializer.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-13 — Workspace Persistence & Serialization Integration
 *
 * Purpose:
 *   Provides deterministic canonical JSON serialization for the Phase-19
 *   persistence snapshot.
 *
 * Determinism Rules:
 *   - Object keys are recursively sorted.
 *   - Array order is preserved.
 *   - Undefined values are rejected.
 *   - Non-finite numbers are rejected.
 *   - Functions, symbols, and bigint values are rejected.
 *   - Circular object graphs are rejected.
 *
 * =============================================================================
 */

import type {
  WindowWorkspacePersistenceSnapshot,
  WindowWorkspaceSerializerContract,
} from "../contracts/workspace-persistence-serialization.contract";

/* =============================================================================
 * SECTION 01 — CANONICALIZATION
 * =============================================================================
 */

type CanonicalValue =
  | null
  | boolean
  | number
  | string
  | readonly CanonicalValue[]
  | {
      readonly [key: string]: CanonicalValue;
    };

const canonicalize = (
  value: unknown,
  ancestors: ReadonlySet<object>,
): CanonicalValue => {
  if (value === null) {
    return null;
  }

  switch (typeof value) {
    case "boolean":
    case "string":
      return value;

    case "number":
      if (!Number.isFinite(value)) {
        throw new Error(
          "Cannot serialize a non-finite number.",
        );
      }

      return value;

    case "undefined":
      throw new Error(
        "Cannot serialize an undefined value.",
      );

    case "bigint":
    case "function":
    case "symbol":
      throw new Error(
        `Cannot serialize value of type: ${typeof value}.`,
      );

    case "object":
      break;

    default:
      throw new Error(
        `Unsupported serialization value type: ${typeof value}.`,
      );
  }

  const objectValue = value as object;

  if (ancestors.has(objectValue)) {
    throw new Error(
      "Cannot serialize a circular object graph.",
    );
  }

  const nextAncestors = new Set(ancestors);
  nextAncestors.add(objectValue);

  if (Array.isArray(value)) {
    return value.map(
      (entry) =>
        canonicalize(
          entry,
          nextAncestors,
        ),
    );
  }

  const source =
    value as Record<string, unknown>;

  const canonicalObject:
    Record<string, CanonicalValue> = {};

  for (
    const key of Object.keys(source).sort()
  ) {
    canonicalObject[key] =
      canonicalize(
        source[key],
        nextAncestors,
      );
  }

  return canonicalObject;
};

/* =============================================================================
 * SECTION 02 — SERIALIZER
 * =============================================================================
 */

export class DeterministicWorkspaceSerializer
  implements WindowWorkspaceSerializerContract
{
  public serialize(
    snapshot: WindowWorkspacePersistenceSnapshot,
  ): string {
    return JSON.stringify(
      canonicalize(
        snapshot,
        new Set<object>(),
      ),
    );
  }

  public deserialize(
    serializedSnapshot: string,
  ): WindowWorkspacePersistenceSnapshot {
    const parsed: unknown =
      JSON.parse(serializedSnapshot);

    if (
      parsed === null ||
      typeof parsed !== "object" ||
      Array.isArray(parsed)
    ) {
      throw new Error(
        "Serialized workspace snapshot must decode to an object.",
      );
    }

    return parsed as
      WindowWorkspacePersistenceSnapshot;
  }
}
