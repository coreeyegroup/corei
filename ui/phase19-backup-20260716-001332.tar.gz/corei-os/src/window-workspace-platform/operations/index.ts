/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM OPERATIONS
 * =============================================================================
 *
 * Public logical operation surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  LayoutCompositionRuntime,
} from "./layout-composition-runtime";
