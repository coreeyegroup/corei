/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   layout-composition-runtime.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-07 — Split / Tab / Group Operations
 *
 * Purpose:
 *   Provides deterministic provider-neutral logical composition operations for
 *   layouts registered with the Step-06 Layout Runtime.
 *
 * Ownership:
 *   - Owns logical group registration.
 *   - Owns logical item/tab registration.
 *   - Owns item ordering within groups.
 *   - Owns active item identity per group.
 *   - Owns logical split relationships.
 *   - Consults Step-06 Layout Runtime as layout authority.
 *   - Does not execute Dockview APIs.
 *   - Does not render UI.
 *   - Does not persist state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  LayoutCompositionContract,
  LayoutCompositionSnapshot,
} from "../contracts/layout-composition.contract";

import type {
  LayoutRuntimeContract,
} from "../contracts/layout-runtime.contract";

import type {
  LayoutGroupId,
  LayoutGroupReference,
  LayoutId,
  LayoutItemId,
  LayoutItemReference,
  LayoutSplitRelationship,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateGroupMessage = (groupId: LayoutGroupId): string =>
  `Layout group is already registered: ${groupId}`;

const unknownGroupMessage = (groupId: LayoutGroupId): string =>
  `Layout group is not registered: ${groupId}`;

const nonEmptyGroupMessage = (groupId: LayoutGroupId): string =>
  `Layout group cannot be removed while it contains items: ${groupId}`;

const duplicateItemMessage = (itemId: LayoutItemId): string =>
  `Layout item is already registered: ${itemId}`;

const unknownItemMessage = (itemId: LayoutItemId): string =>
  `Layout item is not registered: ${itemId}`;

const unknownLayoutMessage = (layoutId: LayoutId): string =>
  `Layout is not registered: ${layoutId}`;

const itemGroupMismatchMessage = (
  itemId: LayoutItemId,
  groupId: LayoutGroupId,
): string =>
  `Layout item ${itemId} does not belong to group ${groupId}`;

const crossLayoutMoveMessage = (
  itemId: LayoutItemId,
  targetGroupId: LayoutGroupId,
): string =>
  `Layout item ${itemId} cannot move to group ${targetGroupId} in another layout`;

const crossLayoutSplitMessage = (
  sourceGroupId: LayoutGroupId,
  targetGroupId: LayoutGroupId,
): string =>
  `Groups ${sourceGroupId} and ${targetGroupId} belong to different layouts`;

const selfSplitMessage = (groupId: LayoutGroupId): string =>
  `Layout group cannot split against itself: ${groupId}`;

const invalidTargetIndexMessage = (targetIndex: number): string =>
  `Target index must be a non-negative integer: ${targetIndex}`;

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyGroupReference = (
  group: LayoutGroupReference,
): LayoutGroupReference => ({
  groupId: group.groupId,
  layoutId: group.layoutId,
});

const copyItemReference = (
  item: LayoutItemReference,
): LayoutItemReference => ({
  itemId: item.itemId,
  layoutId: item.layoutId,
  groupId: item.groupId,
});

const copySplitRelationship = (
  relationship: LayoutSplitRelationship,
): LayoutSplitRelationship => ({
  sourceGroupId: relationship.sourceGroupId,
  targetGroupId: relationship.targetGroupId,
  orientation: relationship.orientation,
});

/* =============================================================================
 * SECTION 03 — LAYOUT COMPOSITION RUNTIME
 * =============================================================================
 */

export class LayoutCompositionRuntime
  implements LayoutCompositionContract
{
  private readonly groups =
    new Map<LayoutGroupId, LayoutGroupReference>();

  private readonly items =
    new Map<LayoutItemId, LayoutItemReference>();

  private readonly itemOrderByGroup =
    new Map<LayoutGroupId, LayoutItemId[]>();

  private readonly activeItemByGroup =
    new Map<LayoutGroupId, LayoutItemId>();

  private readonly splitRelationships =
    new Map<string, LayoutSplitRelationship>();

  public constructor(
    private readonly layoutRuntime: LayoutRuntimeContract,
  ) {}

  /* ===========================================================================
   * GROUP OPERATIONS
   * ===========================================================================
   */

  public registerGroup(group: LayoutGroupReference): void {
    if (this.groups.has(group.groupId)) {
      throw new Error(duplicateGroupMessage(group.groupId));
    }

    this.requireLayout(group.layoutId);

    this.groups.set(
      group.groupId,
      copyGroupReference(group),
    );

    this.itemOrderByGroup.set(group.groupId, []);
  }

  public unregisterGroup(groupId: LayoutGroupId): void {
    this.requireGroup(groupId);

    const itemOrder = this.requireItemOrder(groupId);

    if (itemOrder.length > 0) {
      throw new Error(nonEmptyGroupMessage(groupId));
    }

    this.groups.delete(groupId);
    this.itemOrderByGroup.delete(groupId);
    this.activeItemByGroup.delete(groupId);

    for (
      const [key, relationship]
      of this.splitRelationships.entries()
    ) {
      if (
        relationship.sourceGroupId === groupId ||
        relationship.targetGroupId === groupId
      ) {
        this.splitRelationships.delete(key);
      }
    }
  }

  public hasGroup(groupId: LayoutGroupId): boolean {
    return this.groups.has(groupId);
  }

  public getGroup(
    groupId: LayoutGroupId,
  ): LayoutGroupReference | null {
    const group = this.groups.get(groupId);

    return group === undefined
      ? null
      : copyGroupReference(group);
  }

  public getGroupsForLayout(
    layoutId: LayoutId,
  ): readonly LayoutGroupReference[] {
    this.requireLayout(layoutId);

    return Array.from(this.groups.values())
      .filter((group) => group.layoutId === layoutId)
      .map(copyGroupReference);
  }

  /* ===========================================================================
   * ITEM / TAB OPERATIONS
   * ===========================================================================
   */

  public registerItem(item: LayoutItemReference): void {
    if (this.items.has(item.itemId)) {
      throw new Error(duplicateItemMessage(item.itemId));
    }

    this.requireLayout(item.layoutId);

    const group = this.requireGroup(item.groupId);

    if (group.layoutId !== item.layoutId) {
      throw new Error(
        crossLayoutMoveMessage(
          item.itemId,
          item.groupId,
        ),
      );
    }

    this.items.set(
      item.itemId,
      copyItemReference(item),
    );

    this.requireItemOrder(item.groupId).push(item.itemId);
  }

  public unregisterItem(itemId: LayoutItemId): void {
    const item = this.requireItem(itemId);

    this.items.delete(itemId);

    const itemOrder = this.requireItemOrder(item.groupId);
    const index = itemOrder.indexOf(itemId);

    if (index >= 0) {
      itemOrder.splice(index, 1);
    }

    if (
      this.activeItemByGroup.get(item.groupId) ===
      itemId
    ) {
      this.activeItemByGroup.delete(item.groupId);
    }
  }

  public hasItem(itemId: LayoutItemId): boolean {
    return this.items.has(itemId);
  }

  public getItem(
    itemId: LayoutItemId,
  ): LayoutItemReference | null {
    const item = this.items.get(itemId);

    return item === undefined
      ? null
      : copyItemReference(item);
  }

  public getItemsForGroup(
    groupId: LayoutGroupId,
  ): readonly LayoutItemReference[] {
    this.requireGroup(groupId);

    return this.requireItemOrder(groupId)
      .map((itemId) => this.requireItem(itemId))
      .map(copyItemReference);
  }

  public moveItem(
    itemId: LayoutItemId,
    targetGroupId: LayoutGroupId,
    targetIndex?: number,
  ): void {
    const item = this.requireItem(itemId);
    const targetGroup = this.requireGroup(targetGroupId);

    if (item.layoutId !== targetGroup.layoutId) {
      throw new Error(
        crossLayoutMoveMessage(
          itemId,
          targetGroupId,
        ),
      );
    }

    const sourceGroupId = item.groupId;
    const sourceOrder = this.requireItemOrder(sourceGroupId);
    const sourceIndex = sourceOrder.indexOf(itemId);

    if (sourceIndex >= 0) {
      sourceOrder.splice(sourceIndex, 1);
    }

    if (
      sourceGroupId !== targetGroupId &&
      this.activeItemByGroup.get(sourceGroupId) === itemId
    ) {
      this.activeItemByGroup.delete(sourceGroupId);
    }

    const targetOrder = this.requireItemOrder(targetGroupId);
    const insertionIndex = this.resolveInsertionIndex(
      targetIndex,
      targetOrder.length,
    );

    targetOrder.splice(insertionIndex, 0, itemId);

    this.items.set(itemId, {
      itemId: item.itemId,
      layoutId: item.layoutId,
      groupId: targetGroupId,
    });
  }

  public reorderItem(
    groupId: LayoutGroupId,
    itemId: LayoutItemId,
    targetIndex: number,
  ): void {
    this.requireGroup(groupId);

    const item = this.requireItem(itemId);

    if (item.groupId !== groupId) {
      throw new Error(
        itemGroupMismatchMessage(itemId, groupId),
      );
    }

    const itemOrder = this.requireItemOrder(groupId);
    const currentIndex = itemOrder.indexOf(itemId);

    if (currentIndex >= 0) {
      itemOrder.splice(currentIndex, 1);
    }

    const insertionIndex = this.resolveInsertionIndex(
      targetIndex,
      itemOrder.length,
    );

    itemOrder.splice(insertionIndex, 0, itemId);
  }

  /* ===========================================================================
   * ACTIVE ITEM COORDINATION
   * ===========================================================================
   */

  public setActiveItem(
    groupId: LayoutGroupId,
    itemId: LayoutItemId,
  ): void {
    this.requireGroup(groupId);

    const item = this.requireItem(itemId);

    if (item.groupId !== groupId) {
      throw new Error(
        itemGroupMismatchMessage(itemId, groupId),
      );
    }

    this.activeItemByGroup.set(groupId, itemId);
  }

  public clearActiveItem(
    groupId: LayoutGroupId,
  ): void {
    this.requireGroup(groupId);
    this.activeItemByGroup.delete(groupId);
  }

  public getActiveItemId(
    groupId: LayoutGroupId,
  ): LayoutItemId | null {
    this.requireGroup(groupId);

    return (
      this.activeItemByGroup.get(groupId) ??
      null
    );
  }

  /* ===========================================================================
   * SPLIT RELATIONSHIPS
   * ===========================================================================
   */

  public setSplitRelationship(
    relationship: LayoutSplitRelationship,
  ): void {
    if (
      relationship.sourceGroupId ===
      relationship.targetGroupId
    ) {
      throw new Error(
        selfSplitMessage(relationship.sourceGroupId),
      );
    }

    const sourceGroup =
      this.requireGroup(relationship.sourceGroupId);

    const targetGroup =
      this.requireGroup(relationship.targetGroupId);

    if (sourceGroup.layoutId !== targetGroup.layoutId) {
      throw new Error(
        crossLayoutSplitMessage(
          relationship.sourceGroupId,
          relationship.targetGroupId,
        ),
      );
    }

    this.splitRelationships.set(
      this.createSplitKey(
        relationship.sourceGroupId,
        relationship.targetGroupId,
      ),
      copySplitRelationship(relationship),
    );
  }

  public clearSplitRelationship(
    sourceGroupId: LayoutGroupId,
    targetGroupId: LayoutGroupId,
  ): void {
    this.requireGroup(sourceGroupId);
    this.requireGroup(targetGroupId);

    this.splitRelationships.delete(
      this.createSplitKey(
        sourceGroupId,
        targetGroupId,
      ),
    );
  }

  public getSplitRelationshipsForLayout(
    layoutId: LayoutId,
  ): readonly LayoutSplitRelationship[] {
    this.requireLayout(layoutId);

    return Array.from(this.splitRelationships.values())
      .filter((relationship) => {
        const sourceGroup =
          this.groups.get(relationship.sourceGroupId);

        return sourceGroup?.layoutId === layoutId;
      })
      .map(copySplitRelationship);
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): LayoutCompositionSnapshot {
    const itemOrderByGroup: Partial<
      Record<LayoutGroupId, readonly LayoutItemId[]>
    > = {};

    for (
      const [groupId, itemOrder]
      of this.itemOrderByGroup.entries()
    ) {
      itemOrderByGroup[groupId] = [...itemOrder];
    }

    const activeItemByGroup: Partial<
      Record<LayoutGroupId, LayoutItemId>
    > = {};

    for (
      const [groupId, itemId]
      of this.activeItemByGroup.entries()
    ) {
      activeItemByGroup[groupId] = itemId;
    }

    return {
      groups: Array.from(
        this.groups.values(),
        copyGroupReference,
      ),
      items: Array.from(
        this.items.values(),
        copyItemReference,
      ),
      itemOrderByGroup,
      activeItemByGroup,
      splitRelationships: Array.from(
        this.splitRelationships.values(),
        copySplitRelationship,
      ),
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireLayout(layoutId: LayoutId): void {
    if (!this.layoutRuntime.hasLayout(layoutId)) {
      throw new Error(unknownLayoutMessage(layoutId));
    }
  }

  private requireGroup(
    groupId: LayoutGroupId,
  ): LayoutGroupReference {
    const group = this.groups.get(groupId);

    if (group === undefined) {
      throw new Error(unknownGroupMessage(groupId));
    }

    return group;
  }

  private requireItem(
    itemId: LayoutItemId,
  ): LayoutItemReference {
    const item = this.items.get(itemId);

    if (item === undefined) {
      throw new Error(unknownItemMessage(itemId));
    }

    return item;
  }

  private requireItemOrder(
    groupId: LayoutGroupId,
  ): LayoutItemId[] {
    const itemOrder = this.itemOrderByGroup.get(groupId);

    if (itemOrder === undefined) {
      throw new Error(unknownGroupMessage(groupId));
    }

    return itemOrder;
  }

  private resolveInsertionIndex(
    targetIndex: number | undefined,
    maximumIndex: number,
  ): number {
    if (targetIndex === undefined) {
      return maximumIndex;
    }

    if (
      !Number.isInteger(targetIndex) ||
      targetIndex < 0
    ) {
      throw new Error(
        invalidTargetIndexMessage(targetIndex),
      );
    }

    return Math.min(targetIndex, maximumIndex);
  }

  private createSplitKey(
    sourceGroupId: LayoutGroupId,
    targetGroupId: LayoutGroupId,
  ): string {
    return `${sourceGroupId}::${targetGroupId}`;
  }
}
