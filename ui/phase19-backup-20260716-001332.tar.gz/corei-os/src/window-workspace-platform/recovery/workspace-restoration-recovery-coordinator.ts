/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-restoration-recovery-coordinator.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-14 — Workspace Restoration & Recovery
 *
 * Purpose:
 *   Coordinates deterministic restoration validation and fallback recovery
 *   using the completed Step-13 persistence authority.
 *
 * Critical Boundary:
 *   A successful restoration result means that persisted state has been
 *   validated and is ready for later runtime application.
 *
 *   This coordinator does not directly mutate active runtime authorities.
 *
 * =============================================================================
 */

import type {
  WorkspaceRecoveryRequest,
  WorkspaceRecoveryResult,
  WorkspaceRestorationPersistenceAuthority,
  WorkspaceRestorationRecoveryContract,
  WorkspaceRestorationResult,
} from "../contracts/workspace-restoration-recovery.contract";

import type {
  WindowWorkspacePersistenceKey,
  WorkspaceRecoveryFailureCode,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — COORDINATOR
 * =============================================================================
 */

export class WorkspaceRestorationRecoveryCoordinator
  implements WorkspaceRestorationRecoveryContract
{
  public constructor(
    private readonly persistence:
      WorkspaceRestorationPersistenceAuthority,
  ) {}

  /* ===========================================================================
   * RESTORATION
   * ===========================================================================
   */

  public restore(
    key: WindowWorkspacePersistenceKey,
  ): WorkspaceRestorationResult {
    if (!this.persistence.has(key)) {
      return {
        key,
        status: "missing",
        snapshot: null,
        failureMessage:
          "No persistence record exists for the requested workspace key.",
      };
    }

    const record =
      this.persistence.load(key);

    if (record === null) {
      return {
        key,
        status: "missing",
        snapshot: null,
        failureMessage:
          "Persistence authority reported existence but returned no record.",
      };
    }

    if (record.key !== key) {
      return {
        key,
        status: "invalid-record",
        snapshot: null,
        failureMessage:
          "Persistence record key does not match the requested workspace key.",
      };
    }

    try {
      const snapshot =
        this.persistence.deserializeRecord(record);

      return {
        key,
        status: "ready",
        snapshot,
        failureMessage: null,
      };
    } catch (error: unknown) {
      return {
        key,
        status: "deserialization-failed",
        snapshot: null,
        failureMessage:
          this.toFailureMessage(error),
      };
    }
  }

  /* ===========================================================================
   * RECOVERY
   * ===========================================================================
   */

  public recover(
    request: WorkspaceRecoveryRequest,
  ): WorkspaceRecoveryResult {
    const primary =
      this.restore(request.primaryKey);

    if (primary.status === "ready") {
      if (primary.snapshot === null) {
        throw new Error(
          "Workspace restoration invariant violated: ready primary result has no snapshot.",
        );
      }

      return {
        status: "primary-ready",
        selectedKey: primary.key,
        snapshot: primary.snapshot,
        primary,
        fallback: null,
        failureCodes: [],
      };
    }

    const failureCodes:
      WorkspaceRecoveryFailureCode[] = [
        this.toPrimaryFailureCode(
          primary.status,
        ),
      ];

    if (request.fallbackKey === null) {
      return {
        status: "failed",
        selectedKey: null,
        snapshot: null,
        primary,
        fallback: null,
        failureCodes,
      };
    }

    const fallback =
      this.restore(request.fallbackKey);

    if (fallback.status === "ready") {
      if (fallback.snapshot === null) {
        throw new Error(
          "Workspace restoration invariant violated: ready fallback result has no snapshot.",
        );
      }

      return {
        status: "fallback-ready",
        selectedKey: fallback.key,
        snapshot: fallback.snapshot,
        primary,
        fallback,
        failureCodes,
      };
    }

    failureCodes.push(
      this.toFallbackFailureCode(
        fallback.status,
      ),
    );

    return {
      status: "failed",
      selectedKey: null,
      snapshot: null,
      primary,
      fallback,
      failureCodes,
    };
  }

  /* ===========================================================================
   * FAILURE CLASSIFICATION
   * ===========================================================================
   */

  private toPrimaryFailureCode(
    status: Exclude<
      WorkspaceRestorationResult["status"],
      "ready"
    >,
  ): WorkspaceRecoveryFailureCode {
    switch (status) {
      case "missing":
        return "primary-missing";

      case "invalid-record":
        return "primary-invalid-record";

      case "deserialization-failed":
        return "primary-deserialization-failed";
    }
  }

  private toFallbackFailureCode(
    status: Exclude<
      WorkspaceRestorationResult["status"],
      "ready"
    >,
  ): WorkspaceRecoveryFailureCode {
    switch (status) {
      case "missing":
        return "fallback-missing";

      case "invalid-record":
        return "fallback-invalid-record";

      case "deserialization-failed":
        return "fallback-deserialization-failed";
    }
  }

  /* ===========================================================================
   * ERROR NORMALIZATION
   * ===========================================================================
   */

  private toFailureMessage(
    error: unknown,
  ): string {
    if (error instanceof Error) {
      return error.message;
    }

    return "Unknown workspace restoration failure.";
  }
}
