/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM RESTORATION / RECOVERY
 * =============================================================================
 *
 * Public restoration and recovery surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  WorkspaceRestorationRecoveryCoordinator,
} from "./workspace-restoration-recovery-coordinator";
