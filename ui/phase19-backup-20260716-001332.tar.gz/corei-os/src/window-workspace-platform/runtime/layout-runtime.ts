/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   layout-runtime.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-06 — Layout Runtime
 *
 * Purpose:
 *   Provides deterministic in-memory coordination of logical layouts owned by
 *   registered Phase-19 workspaces.
 *
 * Ownership:
 *   - Owns logical layout registration state.
 *   - Owns active layout identity per workspace.
 *   - Consults Step-03 workspace authority.
 *   - Does not own workspace registration.
 *   - Does not own window registration.
 *   - Does not directly import Dockview.
 *   - Does not manipulate layout geometry.
 *   - Does not render UI.
 *   - Does not persist state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  LayoutRuntimeContract,
  LayoutRuntimeSnapshot,
} from "../contracts/layout-runtime.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  LayoutId,
  LayoutLifecycleState,
  LayoutReference,
  WorkspaceId,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateLayoutMessage = (layoutId: LayoutId): string =>
  `Layout is already registered: ${layoutId}`;

const unknownLayoutMessage = (layoutId: LayoutId): string =>
  `Layout is not registered: ${layoutId}`;

const unknownWorkspaceMessage = (workspaceId: WorkspaceId): string =>
  `Workspace is not registered: ${workspaceId}`;

const layoutWorkspaceMismatchMessage = (
  layoutId: LayoutId,
  workspaceId: WorkspaceId,
): string =>
  `Layout ${layoutId} does not belong to workspace ${workspaceId}`;

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyLayoutReference = (
  layout: LayoutReference,
): LayoutReference => ({
  layoutId: layout.layoutId,
  workspaceId: layout.workspaceId,
  lifecycleState: layout.lifecycleState,
});

/* =============================================================================
 * SECTION 03 — LAYOUT RUNTIME
 * =============================================================================
 */

export class LayoutRuntime implements LayoutRuntimeContract {
  private readonly layouts = new Map<LayoutId, LayoutReference>();

  private readonly activeLayoutByWorkspace =
    new Map<WorkspaceId, LayoutId>();

  public constructor(
    private readonly workspaceCoordinator:
      WorkspaceOperationalCoordinatorContract,
  ) {}

  /* ===========================================================================
   * REGISTRATION
   * ===========================================================================
   */

  public registerLayout(layout: LayoutReference): void {
    if (this.layouts.has(layout.layoutId)) {
      throw new Error(duplicateLayoutMessage(layout.layoutId));
    }

    this.requireWorkspace(layout.workspaceId);

    this.layouts.set(
      layout.layoutId,
      copyLayoutReference(layout),
    );
  }

  public unregisterLayout(layoutId: LayoutId): void {
    const layout = this.requireLayout(layoutId);

    this.layouts.delete(layoutId);

    if (
      this.activeLayoutByWorkspace.get(layout.workspaceId) ===
      layoutId
    ) {
      this.activeLayoutByWorkspace.delete(layout.workspaceId);
    }
  }

  /* ===========================================================================
   * LOOKUP
   * ===========================================================================
   */

  public hasLayout(layoutId: LayoutId): boolean {
    return this.layouts.has(layoutId);
  }

  public getLayout(layoutId: LayoutId): LayoutReference | null {
    const layout = this.layouts.get(layoutId);

    return layout === undefined
      ? null
      : copyLayoutReference(layout);
  }

  public getLayouts(): readonly LayoutReference[] {
    return Array.from(
      this.layouts.values(),
      copyLayoutReference,
    );
  }

  public getLayoutsForWorkspace(
    workspaceId: WorkspaceId,
  ): readonly LayoutReference[] {
    this.requireWorkspace(workspaceId);

    return Array.from(this.layouts.values())
      .filter(
        (layout) =>
          layout.workspaceId === workspaceId,
      )
      .map(copyLayoutReference);
  }

  /* ===========================================================================
   * LIFECYCLE COORDINATION
   * ===========================================================================
   */

  public setLayoutLifecycleState(
    layoutId: LayoutId,
    lifecycleState: LayoutLifecycleState,
  ): void {
    const layout = this.requireLayout(layoutId);

    this.layouts.set(layoutId, {
      layoutId: layout.layoutId,
      workspaceId: layout.workspaceId,
      lifecycleState,
    });
  }

  /* ===========================================================================
   * ACTIVE LAYOUT COORDINATION
   * ===========================================================================
   */

  public setActiveLayout(
    workspaceId: WorkspaceId,
    layoutId: LayoutId,
  ): void {
    this.requireWorkspace(workspaceId);

    const layout = this.requireLayout(layoutId);

    if (layout.workspaceId !== workspaceId) {
      throw new Error(
        layoutWorkspaceMismatchMessage(
          layoutId,
          workspaceId,
        ),
      );
    }

    this.activeLayoutByWorkspace.set(
      workspaceId,
      layoutId,
    );
  }

  public clearActiveLayout(
    workspaceId: WorkspaceId,
  ): void {
    this.requireWorkspace(workspaceId);
    this.activeLayoutByWorkspace.delete(workspaceId);
  }

  public getActiveLayoutId(
    workspaceId: WorkspaceId,
  ): LayoutId | null {
    this.requireWorkspace(workspaceId);

    return (
      this.activeLayoutByWorkspace.get(workspaceId) ??
      null
    );
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): LayoutRuntimeSnapshot {
    const activeLayoutByWorkspace: Partial<
      Record<WorkspaceId, LayoutId>
    > = {};

    for (
      const [workspaceId, layoutId]
      of this.activeLayoutByWorkspace.entries()
    ) {
      activeLayoutByWorkspace[workspaceId] = layoutId;
    }

    return {
      layouts: this.getLayouts(),
      activeLayoutByWorkspace,
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireLayout(
    layoutId: LayoutId,
  ): LayoutReference {
    const layout = this.layouts.get(layoutId);

    if (layout === undefined) {
      throw new Error(unknownLayoutMessage(layoutId));
    }

    return layout;
  }

  private requireWorkspace(
    workspaceId: WorkspaceId,
  ): void {
    if (!this.workspaceCoordinator.hasWorkspace(workspaceId)) {
      throw new Error(
        unknownWorkspaceMessage(workspaceId),
      );
    }
  }
}
