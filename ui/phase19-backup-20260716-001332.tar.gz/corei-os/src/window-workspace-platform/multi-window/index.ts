/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM MULTI-WINDOW RUNTIME
 * =============================================================================
 *
 * Public multi-window runtime surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  MultiWindowRuntime,
} from "./multi-window-runtime";
