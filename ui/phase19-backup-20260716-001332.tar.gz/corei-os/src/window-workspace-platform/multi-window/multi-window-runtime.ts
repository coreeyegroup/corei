/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   multi-window-runtime.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-09 — Multi-Window Runtime
 *
 * Purpose:
 *   Provides deterministic provider-neutral logical runtime coordination for
 *   multiple simultaneous COREI operational windows.
 *
 * Ownership:
 *   - Owns runtime-window registration and lifecycle.
 *   - Owns active runtime-window identity.
 *   - Owns focused runtime-window identity.
 *   - Preserves application-runtime identity.
 *   - Preserves Step-04 logical window identity.
 *   - Preserves workspace identity.
 *   - Preserves runtime-context identity.
 *   - Consults Step-04 Window Management as logical window authority.
 *   - Does not open, close, or focus browser windows.
 *   - Does not execute cross-window messaging.
 *   - Does not implement multi-monitor semantics.
 *   - Does not execute Dockview APIs.
 *   - Does not render UI.
 *   - Does not persist state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  MultiWindowRuntimeContract,
  MultiWindowRuntimeSnapshot,
  RegisterRuntimeWindowRequest,
} from "../contracts/multi-window-runtime.contract";

import type {
  WindowManagementContract,
} from "../contracts/window-management.contract";

import type {
  ApplicationRuntimeId,
  RuntimeWindowId,
  RuntimeWindowLifecycleState,
  RuntimeWindowReference,
  WindowId,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateRuntimeWindowMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window is already registered: ${runtimeWindowId}`;

const duplicateLogicalWindowMessage = (
  windowId: WindowId,
): string =>
  `Logical window already has a runtime window: ${windowId}`;

const unknownRuntimeWindowMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window is not registered: ${runtimeWindowId}`;

const applicationRuntimeMismatchMessage = (
  applicationRuntimeId: ApplicationRuntimeId,
): string =>
  `Runtime window belongs to another application runtime: ${applicationRuntimeId}`;

const unknownLogicalWindowMessage = (
  windowId: WindowId,
): string =>
  `Logical window is not registered: ${windowId}`;

const workspaceMismatchMessage = (
  windowId: WindowId,
): string =>
  `Runtime window workspace does not match logical window: ${windowId}`;

const closedRuntimeWindowMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window is closed: ${runtimeWindowId}`;

const restoreStateMessage = (
  runtimeWindowId: RuntimeWindowId,
): string =>
  `Runtime window must be closed before restore: ${runtimeWindowId}`;

/* =============================================================================
 * SECTION 02 — COPY HELPER
 * =============================================================================
 */

const copyRuntimeWindowReference = (
  reference: RuntimeWindowReference,
): RuntimeWindowReference => ({
  runtimeWindowId: reference.runtimeWindowId,
  applicationRuntimeId:
    reference.applicationRuntimeId,
  windowId: reference.windowId,
  workspaceId: reference.workspaceId,
  runtimeContextId: reference.runtimeContextId,
  lifecycleState: reference.lifecycleState,
});

/* =============================================================================
 * SECTION 03 — MULTI-WINDOW RUNTIME
 * =============================================================================
 */

export class MultiWindowRuntime
  implements MultiWindowRuntimeContract
{
  private readonly runtimeWindows =
    new Map<RuntimeWindowId, RuntimeWindowReference>();

  private readonly runtimeWindowByWindow =
    new Map<WindowId, RuntimeWindowId>();

  private activeRuntimeWindowId:
    RuntimeWindowId | null = null;

  private focusedRuntimeWindowId:
    RuntimeWindowId | null = null;

  public constructor(
    private readonly applicationRuntimeId:
      ApplicationRuntimeId,
    private readonly windowManager:
      WindowManagementContract,
  ) {}

  /* ===========================================================================
   * REGISTRATION
   * ===========================================================================
   */

  public registerRuntimeWindow(
    request: RegisterRuntimeWindowRequest,
  ): void {
    if (
      request.applicationRuntimeId !==
      this.applicationRuntimeId
    ) {
      throw new Error(
        applicationRuntimeMismatchMessage(
          request.applicationRuntimeId,
        ),
      );
    }

    if (
      this.runtimeWindows.has(request.runtimeWindowId)
    ) {
      throw new Error(
        duplicateRuntimeWindowMessage(
          request.runtimeWindowId,
        ),
      );
    }

    if (
      this.runtimeWindowByWindow.has(request.windowId)
    ) {
      throw new Error(
        duplicateLogicalWindowMessage(request.windowId),
      );
    }

    const logicalWindow =
      this.windowManager.getWindow(request.windowId);

    if (logicalWindow === null) {
      throw new Error(
        unknownLogicalWindowMessage(request.windowId),
      );
    }

    if (
      logicalWindow.workspaceId !== request.workspaceId
    ) {
      throw new Error(
        workspaceMismatchMessage(request.windowId),
      );
    }

    const reference: RuntimeWindowReference = {
      runtimeWindowId: request.runtimeWindowId,
      applicationRuntimeId:
        request.applicationRuntimeId,
      windowId: request.windowId,
      workspaceId: request.workspaceId,
      runtimeContextId: request.runtimeContextId,
      lifecycleState: "open",
    };

    this.runtimeWindows.set(
      reference.runtimeWindowId,
      reference,
    );

    this.runtimeWindowByWindow.set(
      reference.windowId,
      reference.runtimeWindowId,
    );
  }

  public unregisterRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const reference =
      this.requireRuntimeWindow(runtimeWindowId);

    this.runtimeWindows.delete(runtimeWindowId);

    this.runtimeWindowByWindow.delete(
      reference.windowId,
    );

    if (
      this.activeRuntimeWindowId === runtimeWindowId
    ) {
      this.activeRuntimeWindowId = null;
    }

    if (
      this.focusedRuntimeWindowId === runtimeWindowId
    ) {
      this.focusedRuntimeWindowId = null;
    }
  }

  /* ===========================================================================
   * LOOKUP
   * ===========================================================================
   */

  public hasRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): boolean {
    return this.runtimeWindows.has(runtimeWindowId);
  }

  public getRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowReference | null {
    const reference =
      this.runtimeWindows.get(runtimeWindowId);

    return reference === undefined
      ? null
      : copyRuntimeWindowReference(reference);
  }

  public getRuntimeWindowForWindow(
    windowId: WindowId,
  ): RuntimeWindowReference | null {
    const runtimeWindowId =
      this.runtimeWindowByWindow.get(windowId);

    if (runtimeWindowId === undefined) {
      return null;
    }

    return this.getRuntimeWindow(runtimeWindowId);
  }

  public getRuntimeWindows():
    readonly RuntimeWindowReference[] {
    return Array.from(
      this.runtimeWindows.values(),
      copyRuntimeWindowReference,
    );
  }

  /* ===========================================================================
   * ACTIVE / FOCUS COORDINATION
   * ===========================================================================
   */

  public activateRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const reference =
      this.requireOpenRuntimeWindow(runtimeWindowId);

    this.clearActiveStateExcept(runtimeWindowId);

    this.activeRuntimeWindowId = runtimeWindowId;

    this.replaceRuntimeWindow(reference, {
      lifecycleState: "active",
    });
  }

  public focusRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const reference =
      this.requireOpenRuntimeWindow(runtimeWindowId);

    this.clearFocusStateExcept(runtimeWindowId);
    this.clearActiveStateExcept(runtimeWindowId);

    this.activeRuntimeWindowId = runtimeWindowId;
    this.focusedRuntimeWindowId = runtimeWindowId;

    this.replaceRuntimeWindow(reference, {
      lifecycleState: "focused",
    });
  }

  /* ===========================================================================
   * CLOSE / RESTORE
   * ===========================================================================
   */

  public closeRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const reference =
      this.requireRuntimeWindow(runtimeWindowId);

    if (
      this.activeRuntimeWindowId === runtimeWindowId
    ) {
      this.activeRuntimeWindowId = null;
    }

    if (
      this.focusedRuntimeWindowId === runtimeWindowId
    ) {
      this.focusedRuntimeWindowId = null;
    }

    this.replaceRuntimeWindow(reference, {
      lifecycleState: "closed",
    });
  }

  public restoreRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const reference =
      this.requireRuntimeWindow(runtimeWindowId);

    if (reference.lifecycleState !== "closed") {
      throw new Error(
        restoreStateMessage(runtimeWindowId),
      );
    }

    this.replaceRuntimeWindow(reference, {
      lifecycleState: "open",
    });
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): MultiWindowRuntimeSnapshot {
    return {
      applicationRuntimeId:
        this.applicationRuntimeId,
      runtimeWindows: Array.from(
        this.runtimeWindows.values(),
        copyRuntimeWindowReference,
      ),
      activeRuntimeWindowId:
        this.activeRuntimeWindowId,
      focusedRuntimeWindowId:
        this.focusedRuntimeWindowId,
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowReference {
    const reference =
      this.runtimeWindows.get(runtimeWindowId);

    if (reference === undefined) {
      throw new Error(
        unknownRuntimeWindowMessage(runtimeWindowId),
      );
    }

    return reference;
  }

  private requireOpenRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowReference {
    const reference =
      this.requireRuntimeWindow(runtimeWindowId);

    if (reference.lifecycleState === "closed") {
      throw new Error(
        closedRuntimeWindowMessage(runtimeWindowId),
      );
    }

    return reference;
  }

  private replaceRuntimeWindow(
    reference: RuntimeWindowReference,
    changes: {
      readonly lifecycleState?:
        RuntimeWindowLifecycleState;
    },
  ): void {
    this.runtimeWindows.set(
      reference.runtimeWindowId,
      {
        ...reference,
        lifecycleState:
          changes.lifecycleState ??
          reference.lifecycleState,
      },
    );
  }

  private clearActiveStateExcept(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const currentId = this.activeRuntimeWindowId;

    if (
      currentId === null ||
      currentId === runtimeWindowId
    ) {
      return;
    }

    const current =
      this.runtimeWindows.get(currentId);

    if (
      current !== undefined &&
      current.lifecycleState !== "closed"
    ) {
      this.replaceRuntimeWindow(current, {
        lifecycleState: "open",
      });
    }

    this.activeRuntimeWindowId = null;

    if (this.focusedRuntimeWindowId === currentId) {
      this.focusedRuntimeWindowId = null;
    }
  }

  private clearFocusStateExcept(
    runtimeWindowId: RuntimeWindowId,
  ): void {
    const currentId = this.focusedRuntimeWindowId;

    if (
      currentId === null ||
      currentId === runtimeWindowId
    ) {
      return;
    }

    const current =
      this.runtimeWindows.get(currentId);

    if (
      current !== undefined &&
      current.lifecycleState === "focused"
    ) {
      this.replaceRuntimeWindow(current, {
        lifecycleState:
          this.activeRuntimeWindowId === currentId
            ? "active"
            : "open",
      });
    }

    this.focusedRuntimeWindowId = null;
  }
}
