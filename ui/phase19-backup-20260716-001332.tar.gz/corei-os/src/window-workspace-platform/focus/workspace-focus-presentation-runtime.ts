/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-focus-presentation-runtime.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-11 — Workspace Focus & Presentation Modes
 *
 * Purpose:
 *   Provides deterministic workspace mode transitions and restoration semantics
 *   for Normal, Focus, Fullscreen, and Presentation operation.
 *
 * Ownership:
 *   - Owns workspace mode state.
 *   - Owns focus target metadata.
 *   - Owns semantic visibility metadata.
 *   - Owns restoration-point capture and consumption.
 *   - Consults Step-03 as workspace identity authority.
 *   - Consults Step-06 as layout identity authority.
 *   - Does not execute browser fullscreen APIs.
 *   - Does not mutate DOM or Shell regions.
 *   - Does not switch workspaces.
 *   - Does not persist or recover state.
 *   - Does not render UI.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  WorkspaceFocusPresentationContract,
  WorkspaceFocusPresentationSnapshot,
  WorkspaceModeEntry,
} from "../contracts/workspace-focus-presentation.contract";

import type {
  LayoutRuntimeContract,
} from "../contracts/layout-runtime.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  LayoutId,
  WorkspaceId,
  WorkspaceModeRestorationPoint,
  WorkspaceModeState,
  WorkspaceVisibilityState,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const unknownWorkspaceMessage = (
  workspaceId: WorkspaceId,
): string =>
  `Workspace is not registered: ${workspaceId}`;

const duplicateWorkspaceModeMessage = (
  workspaceId: WorkspaceId,
): string =>
  `Workspace mode state is already initialized: ${workspaceId}`;

const uninitializedWorkspaceModeMessage = (
  workspaceId: WorkspaceId,
): string =>
  `Workspace mode state is not initialized: ${workspaceId}`;

const unknownLayoutMessage = (
  layoutId: LayoutId,
): string =>
  `Layout is not registered: ${layoutId}`;

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyVisibility = (
  visibility: WorkspaceVisibilityState,
): WorkspaceVisibilityState => ({
  topRegionVisible: visibility.topRegionVisible,
  leftRegionVisible: visibility.leftRegionVisible,
  rightRegionVisible: visibility.rightRegionVisible,
  bottomRegionVisible: visibility.bottomRegionVisible,
  statusRegionVisible: visibility.statusRegionVisible,
});

const copyRestorationPoint = (
  restorationPoint: WorkspaceModeRestorationPoint,
): WorkspaceModeRestorationPoint => ({
  workspaceId: restorationPoint.workspaceId,
  layoutId: restorationPoint.layoutId,
  focusTargetId: restorationPoint.focusTargetId,
  visibility: copyVisibility(restorationPoint.visibility),
});

const copyModeState = (
  state: WorkspaceModeState,
): WorkspaceModeState => ({
  workspaceId: state.workspaceId,
  mode: state.mode,
  focusTargetId: state.focusTargetId,
  visibility: copyVisibility(state.visibility),
  restorationPoint:
    state.restorationPoint === null
      ? null
      : copyRestorationPoint(state.restorationPoint),
});

/* =============================================================================
 * SECTION 03 — WORKSPACE FOCUS / PRESENTATION RUNTIME
 * =============================================================================
 */

export class WorkspaceFocusPresentationRuntime
  implements WorkspaceFocusPresentationContract
{
  private readonly workspaceModes =
    new Map<WorkspaceId, WorkspaceModeState>();

  public constructor(
    private readonly workspaceCoordinator:
      WorkspaceOperationalCoordinatorContract,
    private readonly layoutRuntime:
      LayoutRuntimeContract,
  ) {}

  /* ===========================================================================
   * INITIALIZATION
   * ===========================================================================
   */

  public initializeWorkspace(
    workspaceId: WorkspaceId,
    visibility: WorkspaceVisibilityState,
  ): void {
    this.requireWorkspace(workspaceId);

    if (this.workspaceModes.has(workspaceId)) {
      throw new Error(
        duplicateWorkspaceModeMessage(workspaceId),
      );
    }

    this.workspaceModes.set(
      workspaceId,
      {
        workspaceId,
        mode: "normal",
        focusTargetId: null,
        visibility: copyVisibility(visibility),
        restorationPoint: null,
      },
    );
  }

  /* ===========================================================================
   * SPECIALIZED MODE ENTRY
   * ===========================================================================
   */

  public enterMode(
    entry: WorkspaceModeEntry,
  ): void {
    this.requireWorkspace(entry.workspaceId);

    if (entry.layoutId !== null) {
      this.requireLayout(entry.layoutId);
    }

    const current =
      this.requireWorkspaceMode(entry.workspaceId);

    const restorationPoint =
      current.restorationPoint ??
      {
        workspaceId: entry.workspaceId,
        layoutId: entry.layoutId,
        focusTargetId: current.focusTargetId,
        visibility: copyVisibility(
          entry.currentVisibility,
        ),
      };

    this.workspaceModes.set(
      entry.workspaceId,
      {
        workspaceId: entry.workspaceId,
        mode: entry.mode,
        focusTargetId: entry.focusTargetId,
        visibility: copyVisibility(
          entry.targetVisibility,
        ),
        restorationPoint:
          copyRestorationPoint(restorationPoint),
      },
    );
  }

  /* ===========================================================================
   * RESTORATION
   * ===========================================================================
   */

  public restoreNormalMode(
    workspaceId: WorkspaceId,
  ): void {
    this.requireWorkspace(workspaceId);

    const current =
      this.requireWorkspaceMode(workspaceId);

    if (current.mode === "normal") {
      return;
    }

    const restorationPoint =
      current.restorationPoint;

    if (restorationPoint === null) {
      throw new Error(
        `Specialized workspace mode is missing its restoration point: ${workspaceId}`,
      );
    }

    this.workspaceModes.set(
      workspaceId,
      {
        workspaceId,
        mode: "normal",
        focusTargetId:
          restorationPoint.focusTargetId,
        visibility: copyVisibility(
          restorationPoint.visibility,
        ),
        restorationPoint: null,
      },
    );
  }

  /* ===========================================================================
   * LOOKUP
   * ===========================================================================
   */

  public hasWorkspaceMode(
    workspaceId: WorkspaceId,
  ): boolean {
    return this.workspaceModes.has(workspaceId);
  }

  public getWorkspaceMode(
    workspaceId: WorkspaceId,
  ): WorkspaceModeState | null {
    const state =
      this.workspaceModes.get(workspaceId);

    return state === undefined
      ? null
      : copyModeState(state);
  }

  public getWorkspaceModes():
    readonly WorkspaceModeState[] {
    return Array.from(
      this.workspaceModes.values(),
      copyModeState,
    );
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot():
    WorkspaceFocusPresentationSnapshot {
    return {
      workspaceModes: this.getWorkspaceModes(),
    };
  }

  /* ===========================================================================
   * INTERNAL AUTHORITY VALIDATION
   * ===========================================================================
   */

  private requireWorkspace(
    workspaceId: WorkspaceId,
  ): void {
    if (
      !this.workspaceCoordinator.hasWorkspace(
        workspaceId,
      )
    ) {
      throw new Error(
        unknownWorkspaceMessage(workspaceId),
      );
    }
  }

  private requireWorkspaceMode(
    workspaceId: WorkspaceId,
  ): WorkspaceModeState {
    const state =
      this.workspaceModes.get(workspaceId);

    if (state === undefined) {
      throw new Error(
        uninitializedWorkspaceModeMessage(
          workspaceId,
        ),
      );
    }

    return state;
  }

  private requireLayout(
    layoutId: LayoutId,
  ): void {
    if (!this.layoutRuntime.hasLayout(layoutId)) {
      throw new Error(
        unknownLayoutMessage(layoutId),
      );
    }
  }
}
