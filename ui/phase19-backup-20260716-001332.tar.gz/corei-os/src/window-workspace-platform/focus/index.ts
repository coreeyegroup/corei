/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM FOCUS / PRESENTATION RUNTIME
 * =============================================================================
 *
 * Public focus and presentation mode runtime surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  WorkspaceFocusPresentationRuntime,
} from "./workspace-focus-presentation-runtime";
