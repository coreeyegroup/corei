/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM
 * =============================================================================
 *
 * Stage-25 Phase-19 public API.
 *
 * Step-02 exposes contracts only.
 *
 * Runtime implementation is intentionally deferred to subsequent Phase-19
 * steps.
 *
 * =============================================================================
 */

export type {
  WindowId,
  WindowLifecycleState,
  WindowReference,
  WindowWorkspacePlatformContext,
  WindowWorkspacePlatformContract,
  WindowWorkspacePlatformId,
  WindowWorkspacePlatformLifecycleState,
  WindowWorkspacePlatformSnapshot,
  WorkspaceId,
  WorkspaceLifecycleState,
  WorkspaceReference,
} from "./contracts";

export type {
  WorkspaceOperationalCoordinatorContract,
  WorkspaceOperationalSnapshot,
} from "./contracts";

export {
  WorkspaceOperationalCoordinator,
} from "./coordination";

export type {
  WindowManagementContract,
  WindowManagementSnapshot,
} from "./contracts";

export {
  WindowManager,
} from "./coordination";

export type {
  DockviewRuntimeAdapterContract,
  DockviewRuntimeIntegrationContract,
  DockviewRuntimeIntegrationSnapshot,
} from "./contracts";

export {
  DockviewRuntimeIntegration,
} from "./integration";

export type {
  LayoutRuntimeContract,
  LayoutRuntimeSnapshot,
} from "./contracts";

export type {
  LayoutId,
  LayoutLifecycleState,
  LayoutReference,
} from "./contracts/window-workspace-platform.types";

export {
  LayoutRuntime,
} from "./runtime";

export type {
  LayoutCompositionContract,
  LayoutCompositionSnapshot,
} from "./contracts";

export type {
  LayoutGroupId,
  LayoutGroupReference,
  LayoutItemId,
  LayoutItemReference,
  LayoutSplitOrientation,
  LayoutSplitRelationship,
} from "./contracts/window-workspace-platform.types";

export {
  LayoutCompositionRuntime,
} from "./operations";

export type {
  FloatWindowRequest,
  FloatingWindowManagementContract,
  FloatingWindowManagementSnapshot,
} from "./contracts";

export type {
  FloatingWindowBounds,
  FloatingWindowId,
  FloatingWindowLifecycleState,
  FloatingWindowReference,
  FloatingWindowRestorationMetadata,
} from "./contracts/window-workspace-platform.types";

export {
  FloatingWindowManager,
} from "./floating";

export type {
  MultiWindowRuntimeContract,
  MultiWindowRuntimeSnapshot,
  RegisterRuntimeWindowRequest,
} from "./contracts";

export type {
  ApplicationRuntimeId,
  RuntimeWindowId,
  RuntimeWindowLifecycleState,
  RuntimeWindowReference,
} from "./contracts/window-workspace-platform.types";

export {
  MultiWindowRuntime,
} from "./multi-window";

export type {
  MultiMonitorRuntimeContract,
  MultiMonitorRuntimeSnapshot,
} from "./contracts";

export type {
  MonitorBounds,
  MonitorId,
  MonitorReference,
  RuntimeWindowMonitorAssignment,
  RuntimeWindowPlacementMode,
} from "./contracts/window-workspace-platform.types";

export {
  MultiMonitorRuntime,
} from "./multi-monitor";

export type {
  WorkspaceFocusPresentationContract,
  WorkspaceFocusPresentationSnapshot,
  WorkspaceModeEntry,
} from "./contracts";

export type {
  WorkspaceModeRestorationPoint,
  WorkspaceModeState,
  WorkspacePresentationMode,
  WorkspaceVisibilityState,
} from "./contracts/window-workspace-platform.types";

export {
  WorkspaceFocusPresentationRuntime,
} from "./focus";

export type {
  WorkspaceSwitchingContract,
  WorkspaceSwitchingSnapshot,
} from "./contracts";

export type {
  WorkspaceActiveContext,
  WorkspaceSwitchResult,
} from "./contracts/window-workspace-platform.types";

export {
  WorkspaceSwitchingCoordinator,
} from "./switching";

export type {
  WindowWorkspacePersistenceAdapter,
  WindowWorkspacePersistenceIntegrationContract,
  WindowWorkspacePersistenceSnapshot,
  WindowWorkspacePersistenceSnapshotSource,
  WindowWorkspaceSerializerContract,
} from "./contracts";

export type {
  WindowWorkspacePersistenceKey,
  WindowWorkspacePersistenceRecord,
  WindowWorkspacePersistenceSchemaVersion,
} from "./contracts/window-workspace-platform.types";

export {
  DeterministicWorkspaceSerializer,
  WindowWorkspacePersistenceIntegration,
} from "./persistence";

export type {
  WorkspaceRecoveryRequest,
  WorkspaceRecoveryResult,
  WorkspaceRestorationPersistenceAuthority,
  WorkspaceRestorationRecoveryContract,
  WorkspaceRestorationResult,
} from "./contracts";

export type {
  WorkspaceRecoveryFailureCode,
  WorkspaceRecoveryStatus,
  WorkspaceRestorationStatus,
} from "./contracts/window-workspace-platform.types";

export {
  WorkspaceRestorationRecoveryCoordinator,
} from "./recovery";

export type {
  ShellWorkbenchWorkspaceRuntimeAuthorities,
  ShellWorkbenchWorkspaceRuntimeIntegrationContract,
  ShellWorkbenchWorkspaceRuntimeIntegrationState,
} from "./contracts";

export {
  ShellWorkbenchWorkspaceRuntimeCoordinator,
} from "./composition";

export type {
  WorkspaceEventsStateLifecycleContract,
  WorkspaceEventsStateLifecycleSnapshot,
  WorkspacePlatformEventPublicationPort,
  WorkspacePlatformLifecycleEvent,
  WorkspacePlatformLifecycleEventSequence,
  WorkspacePlatformLifecycleEventType,
  WorkspacePlatformLifecycleState,
  WorkspacePlatformStatePublicationPort,
} from "./contracts";

export {
  WorkspaceEventsStateLifecycleCoordinator,
} from "./lifecycle";
