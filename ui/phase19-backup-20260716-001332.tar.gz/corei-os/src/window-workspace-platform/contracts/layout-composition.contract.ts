/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   layout-composition.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-07 — Split / Tab / Group Operations
 *
 * Purpose:
 *   Defines provider-neutral logical composition operations for registered
 *   Phase-19 layouts.
 *
 * Architectural Boundary:
 *   This contract owns logical group, item/tab, ordering, active-item, and
 *   split-relationship coordination only.
 *
 *   It does not execute:
 *   - Dockview APIs;
 *   - browser APIs;
 *   - DOM operations;
 *   - rendering;
 *   - persistence;
 *   - restoration.
 *
 * Browser Visibility:
 *   Step-07 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  LayoutGroupId,
  LayoutGroupReference,
  LayoutId,
  LayoutItemId,
  LayoutItemReference,
  LayoutSplitRelationship,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — COMPOSITION SNAPSHOT
 * =============================================================================
 */

export interface LayoutCompositionSnapshot {
  readonly groups: readonly LayoutGroupReference[];
  readonly items: readonly LayoutItemReference[];
  readonly itemOrderByGroup: Readonly<
    Partial<Record<LayoutGroupId, readonly LayoutItemId[]>>
  >;
  readonly activeItemByGroup: Readonly<
    Partial<Record<LayoutGroupId, LayoutItemId>>
  >;
  readonly splitRelationships: readonly LayoutSplitRelationship[];
}

/* =============================================================================
 * SECTION 02 — COMPOSITION CONTRACT
 * =============================================================================
 */

export interface LayoutCompositionContract {
  registerGroup(group: LayoutGroupReference): void;

  unregisterGroup(groupId: LayoutGroupId): void;

  hasGroup(groupId: LayoutGroupId): boolean;

  getGroup(groupId: LayoutGroupId): LayoutGroupReference | null;

  getGroupsForLayout(
    layoutId: LayoutId,
  ): readonly LayoutGroupReference[];

  registerItem(item: LayoutItemReference): void;

  unregisterItem(itemId: LayoutItemId): void;

  hasItem(itemId: LayoutItemId): boolean;

  getItem(itemId: LayoutItemId): LayoutItemReference | null;

  getItemsForGroup(
    groupId: LayoutGroupId,
  ): readonly LayoutItemReference[];

  moveItem(
    itemId: LayoutItemId,
    targetGroupId: LayoutGroupId,
    targetIndex?: number,
  ): void;

  reorderItem(
    groupId: LayoutGroupId,
    itemId: LayoutItemId,
    targetIndex: number,
  ): void;

  setActiveItem(
    groupId: LayoutGroupId,
    itemId: LayoutItemId,
  ): void;

  clearActiveItem(groupId: LayoutGroupId): void;

  getActiveItemId(
    groupId: LayoutGroupId,
  ): LayoutItemId | null;

  setSplitRelationship(
    relationship: LayoutSplitRelationship,
  ): void;

  clearSplitRelationship(
    sourceGroupId: LayoutGroupId,
    targetGroupId: LayoutGroupId,
  ): void;

  getSplitRelationshipsForLayout(
    layoutId: LayoutId,
  ): readonly LayoutSplitRelationship[];

  getSnapshot(): LayoutCompositionSnapshot;
}
