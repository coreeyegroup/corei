/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   window-workspace-platform.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-02 — Window & Workspace Platform Contract Boundary
 *
 * Purpose:
 *   Defines the authoritative provider-independent coordination contract for
 *   the Window & Workspace Platform.
 *
 * Important:
 *   This contract defines the platform boundary only.
 *
 *   It does not implement:
 *   - workspace coordination;
 *   - window management;
 *   - Dockview integration;
 *   - layout operations;
 *   - persistence;
 *   - restoration;
 *   - recovery;
 *   - events;
 *   - diagnostics.
 *
 * =============================================================================
 */

import type {
  WindowId,
  WindowReference,
  WindowWorkspacePlatformContext,
  WindowWorkspacePlatformLifecycleState,
  WindowWorkspacePlatformSnapshot,
  WorkspaceId,
  WorkspaceReference,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — PLATFORM CONTRACT
 * =============================================================================
 */

export interface WindowWorkspacePlatformContract {
  /**
   * Returns the current platform lifecycle state.
   */
  getLifecycleState(): WindowWorkspacePlatformLifecycleState;

  /**
   * Returns the current immutable platform context.
   */
  getContext(): WindowWorkspacePlatformContext;

  /**
   * Returns the current immutable platform snapshot.
   */
  getSnapshot(): WindowWorkspacePlatformSnapshot;

  /**
   * Returns all workspaces currently known to the platform boundary.
   */
  getWorkspaces(): readonly WorkspaceReference[];

  /**
   * Returns a workspace reference when known.
   */
  getWorkspace(workspaceId: WorkspaceId): WorkspaceReference | null;

  /**
   * Returns all windows currently known to the platform boundary.
   */
  getWindows(): readonly WindowReference[];

  /**
   * Returns a window reference when known.
   */
  getWindow(windowId: WindowId): WindowReference | null;

  /**
   * Returns the active workspace identity when one exists.
   */
  getActiveWorkspaceId(): WorkspaceId | null;

  /**
   * Returns the active window identity when one exists.
   */
  getActiveWindowId(): WindowId | null;
}
