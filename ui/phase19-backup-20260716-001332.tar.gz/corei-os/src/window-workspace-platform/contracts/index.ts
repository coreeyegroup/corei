/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM CONTRACTS
 * =============================================================================
 *
 * Public contract surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export type {
  WindowId,
  WindowLifecycleState,
  WindowReference,
  WindowWorkspacePlatformContext,
  WindowWorkspacePlatformId,
  WindowWorkspacePlatformLifecycleState,
  WindowWorkspacePlatformSnapshot,
  WorkspaceId,
  WorkspaceLifecycleState,
  WorkspaceReference,
} from "./window-workspace-platform.types";

export type {
  WindowWorkspacePlatformContract,
} from "./window-workspace-platform.contract";

export type {
  WorkspaceOperationalCoordinatorContract,
  WorkspaceOperationalSnapshot,
} from "./workspace-operational-coordinator.contract";

export type {
  WindowManagementContract,
  WindowManagementSnapshot,
} from "./window-management.contract";

export type {
  DockviewRuntimeAdapterContract,
  DockviewRuntimeIntegrationContract,
  DockviewRuntimeIntegrationSnapshot,
} from "./dockview-runtime-integration.contract";

export type {
  LayoutRuntimeContract,
  LayoutRuntimeSnapshot,
} from "./layout-runtime.contract";

export type {
  LayoutCompositionContract,
  LayoutCompositionSnapshot,
} from "./layout-composition.contract";

export type {
  FloatWindowRequest,
  FloatingWindowManagementContract,
  FloatingWindowManagementSnapshot,
} from "./floating-window-management.contract";

export type {
  MultiWindowRuntimeContract,
  MultiWindowRuntimeSnapshot,
  RegisterRuntimeWindowRequest,
} from "./multi-window-runtime.contract";

export type {
  MultiMonitorRuntimeContract,
  MultiMonitorRuntimeSnapshot,
} from "./multi-monitor-runtime.contract";

export type {
  WorkspaceFocusPresentationContract,
  WorkspaceFocusPresentationSnapshot,
  WorkspaceModeEntry,
} from "./workspace-focus-presentation.contract";

export type {
  WorkspaceSwitchingContract,
  WorkspaceSwitchingSnapshot,
} from "./workspace-switching.contract";

export type {
  WindowWorkspacePersistenceAdapter,
  WindowWorkspacePersistenceIntegrationContract,
  WindowWorkspacePersistenceSnapshot,
  WindowWorkspacePersistenceSnapshotSource,
  WindowWorkspaceSerializerContract,
} from "./workspace-persistence-serialization.contract";

export type {
  WorkspaceRecoveryRequest,
  WorkspaceRecoveryResult,
  WorkspaceRestorationPersistenceAuthority,
  WorkspaceRestorationRecoveryContract,
  WorkspaceRestorationResult,
} from "./workspace-restoration-recovery.contract";

export type {
  ShellWorkbenchWorkspaceRuntimeAuthorities,
  ShellWorkbenchWorkspaceRuntimeIntegrationContract,
  ShellWorkbenchWorkspaceRuntimeIntegrationState,
} from "./shell-workbench-workspace-runtime-integration.contract";

export type {
  WorkspaceEventsStateLifecycleContract,
  WorkspaceEventsStateLifecycleSnapshot,
  WorkspacePlatformEventPublicationPort,
  WorkspacePlatformLifecycleEvent,
  WorkspacePlatformLifecycleEventSequence,
  WorkspacePlatformLifecycleEventType,
  WorkspacePlatformLifecycleState,
  WorkspacePlatformStatePublicationPort,
} from "./workspace-events-state-lifecycle.contract";
