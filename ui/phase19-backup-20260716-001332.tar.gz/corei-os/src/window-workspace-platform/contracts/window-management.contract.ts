/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   window-management.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-04 — Window Management Platform
 *
 * Purpose:
 *   Defines the provider-independent operational management contract for
 *   window references known to the Phase-19 platform boundary.
 *
 * Architectural Boundary:
 *   This contract coordinates logical platform windows.
 *
 *   It does not define or own:
 *   - browser Window objects;
 *   - DOM rendering;
 *   - Dockview panels;
 *   - layout geometry;
 *   - floating-window geometry;
 *   - persistence;
 *   - restoration;
 *   - multi-monitor placement.
 *
 * =============================================================================
 */

import type {
  WindowId,
  WindowLifecycleState,
  WindowReference,
  WorkspaceId,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — WINDOW MANAGEMENT SNAPSHOT
 * =============================================================================
 */

export interface WindowManagementSnapshot {
  readonly activeWindowId: WindowId | null;
  readonly windows: readonly WindowReference[];
}

/* =============================================================================
 * SECTION 02 — WINDOW MANAGEMENT CONTRACT
 * =============================================================================
 */

export interface WindowManagementContract {
  /**
   * Registers a logical window with the Phase-19 platform boundary.
   *
   * Duplicate window identities are rejected.
   *
   * When workspaceId is non-null, that workspace must already be known to the
   * workspace coordination boundary.
   */
  registerWindow(window: WindowReference): void;

  /**
   * Removes a known logical window.
   *
   * Removing the active window also clears the active window identity.
   */
  unregisterWindow(windowId: WindowId): void;

  /**
   * Returns whether a window identity is currently known.
   */
  hasWindow(windowId: WindowId): boolean;

  /**
   * Returns a window reference when known.
   */
  getWindow(windowId: WindowId): WindowReference | null;

  /**
   * Returns an immutable snapshot of all known window references.
   */
  getWindows(): readonly WindowReference[];

  /**
   * Updates the lifecycle state of a known window.
   */
  setWindowLifecycleState(
    windowId: WindowId,
    lifecycleState: WindowLifecycleState,
  ): void;

  /**
   * Associates a known window with a known workspace.
   */
  assignWindowToWorkspace(
    windowId: WindowId,
    workspaceId: WorkspaceId,
  ): void;

  /**
   * Removes workspace association from a known window.
   */
  detachWindowFromWorkspace(windowId: WindowId): void;

  /**
   * Makes a known window the active window.
   */
  setActiveWindow(windowId: WindowId): void;

  /**
   * Clears the active window identity.
   */
  clearActiveWindow(): void;

  /**
   * Returns the active window identity when one exists.
   */
  getActiveWindowId(): WindowId | null;

  /**
   * Returns an immutable operational snapshot.
   */
  getSnapshot(): WindowManagementSnapshot;
}
