/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   layout-runtime.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-06 — Layout Runtime
 *
 * Purpose:
 *   Defines the provider-independent operational contract for logical layout
 *   state known to the Phase-19 platform boundary.
 *
 * Architectural Boundary:
 *   This contract owns logical layout coordination only.
 *
 *   It does not define or own:
 *   - Dockview layout JSON;
 *   - split operations;
 *   - tab operations;
 *   - group operations;
 *   - panel placement;
 *   - floating-window geometry;
 *   - persistence;
 *   - restoration;
 *   - rendering.
 *
 * Browser Visibility:
 *   Step-06 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  LayoutId,
  LayoutLifecycleState,
  LayoutReference,
  WorkspaceId,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — LAYOUT RUNTIME SNAPSHOT
 * =============================================================================
 */

export interface LayoutRuntimeSnapshot {
  readonly layouts: readonly LayoutReference[];
  readonly activeLayoutByWorkspace: Readonly<
    Partial<Record<WorkspaceId, LayoutId>>
  >;
}

/* =============================================================================
 * SECTION 02 — LAYOUT RUNTIME CONTRACT
 * =============================================================================
 */

export interface LayoutRuntimeContract {
  /**
   * Registers a logical layout.
   *
   * The owning workspace must already be registered.
   * Duplicate layout identities are rejected.
   */
  registerLayout(layout: LayoutReference): void;

  /**
   * Removes a known logical layout.
   *
   * If the layout is active for its workspace, the active layout association
   * is cleared.
   */
  unregisterLayout(layoutId: LayoutId): void;

  /**
   * Returns whether a layout identity is currently known.
   */
  hasLayout(layoutId: LayoutId): boolean;

  /**
   * Returns a copied layout reference when known.
   */
  getLayout(layoutId: LayoutId): LayoutReference | null;

  /**
   * Returns copied references for all known layouts.
   */
  getLayouts(): readonly LayoutReference[];

  /**
   * Returns copied references for layouts owned by one workspace.
   */
  getLayoutsForWorkspace(
    workspaceId: WorkspaceId,
  ): readonly LayoutReference[];

  /**
   * Updates the lifecycle state of a known layout.
   */
  setLayoutLifecycleState(
    layoutId: LayoutId,
    lifecycleState: LayoutLifecycleState,
  ): void;

  /**
   * Makes a known layout active for its owning workspace.
   */
  setActiveLayout(
    workspaceId: WorkspaceId,
    layoutId: LayoutId,
  ): void;

  /**
   * Clears the active layout identity for a known workspace.
   */
  clearActiveLayout(workspaceId: WorkspaceId): void;

  /**
   * Returns the active layout identity for a workspace when one exists.
   */
  getActiveLayoutId(
    workspaceId: WorkspaceId,
  ): LayoutId | null;

  /**
   * Returns the immutable logical layout runtime snapshot.
   */
  getSnapshot(): LayoutRuntimeSnapshot;
}
