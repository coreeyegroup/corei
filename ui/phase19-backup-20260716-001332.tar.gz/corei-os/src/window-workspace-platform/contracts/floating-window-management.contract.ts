/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   floating-window-management.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-08 — Floating Window Management
 *
 * Purpose:
 *   Defines provider-neutral logical floating-window management for detachable
 *   operational surfaces.
 *
 * Architectural Boundary:
 *   This contract owns floating identity, logical detachment, reattachment,
 *   geometry, activation, focus, close, restore, context preservation, and
 *   deterministic snapshots.
 *
 *   It does not execute:
 *   - browser window creation;
 *   - Dockview provider APIs;
 *   - DOM operations;
 *   - cross-window synchronization;
 *   - persistence;
 *   - panel rendering.
 *
 * Browser Visibility:
 *   Step-08 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  FloatingWindowBounds,
  FloatingWindowId,
  FloatingWindowReference,
  LayoutGroupId,
  LayoutItemId,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — FLOAT REQUEST
 * =============================================================================
 */

export interface FloatWindowRequest
  extends FloatingWindowReference {}

/* =============================================================================
 * SECTION 02 — FLOATING WINDOW SNAPSHOT
 * =============================================================================
 */

export interface FloatingWindowManagementSnapshot {
  readonly floatingWindows: readonly FloatingWindowReference[];
  readonly activeFloatingWindowId: FloatingWindowId | null;
  readonly focusedFloatingWindowId: FloatingWindowId | null;
}

/* =============================================================================
 * SECTION 03 — FLOATING WINDOW MANAGEMENT CONTRACT
 * =============================================================================
 */

export interface FloatingWindowManagementContract {
  float(request: FloatWindowRequest): void;

  reattach(
    floatingWindowId: FloatingWindowId,
    targetGroupId?: LayoutGroupId,
    targetIndex?: number,
  ): void;

  move(
    floatingWindowId: FloatingWindowId,
    x: number,
    y: number,
  ): void;

  resize(
    floatingWindowId: FloatingWindowId,
    width: number,
    height: number,
  ): void;

  activate(floatingWindowId: FloatingWindowId): void;

  focus(floatingWindowId: FloatingWindowId): void;

  close(floatingWindowId: FloatingWindowId): void;

  restore(floatingWindowId: FloatingWindowId): void;

  hasFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): boolean;

  getFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): FloatingWindowReference | null;

  getFloatingWindowForItem(
    itemId: LayoutItemId,
  ): FloatingWindowReference | null;

  getSnapshot(): FloatingWindowManagementSnapshot;
}
