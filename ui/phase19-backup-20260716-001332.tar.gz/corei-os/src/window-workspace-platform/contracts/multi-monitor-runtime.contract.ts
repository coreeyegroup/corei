/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   multi-monitor-runtime.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-10 — Multi-Monitor Runtime
 *
 * Purpose:
 *   Defines provider-neutral monitor topology and runtime-window placement
 *   authority.
 *
 * Architectural Boundary:
 *   This contract owns logical monitor registration, primary-monitor state,
 *   runtime-window-to-monitor assignment, placement metadata, and deterministic
 *   snapshots.
 *
 *   It does not execute:
 *   - browser Screen APIs;
 *   - browser Window APIs;
 *   - operating-system monitor discovery;
 *   - browser window movement or resize;
 *   - cross-window transport;
 *   - Dockview provider APIs;
 *   - persistence;
 *   - rendering.
 *
 * Browser Visibility:
 *   Step-10 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  MonitorId,
  MonitorReference,
  RuntimeWindowId,
  RuntimeWindowMonitorAssignment,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — MULTI-MONITOR RUNTIME SNAPSHOT
 * =============================================================================
 */

export interface MultiMonitorRuntimeSnapshot {
  readonly monitors: readonly MonitorReference[];
  readonly primaryMonitorId: MonitorId | null;
  readonly assignments:
    readonly RuntimeWindowMonitorAssignment[];
}

/* =============================================================================
 * SECTION 02 — MULTI-MONITOR RUNTIME CONTRACT
 * =============================================================================
 */

export interface MultiMonitorRuntimeContract {
  registerMonitor(monitor: MonitorReference): void;

  unregisterMonitor(monitorId: MonitorId): void;

  hasMonitor(monitorId: MonitorId): boolean;

  getMonitor(
    monitorId: MonitorId,
  ): MonitorReference | null;

  getMonitors(): readonly MonitorReference[];

  getPrimaryMonitor(): MonitorReference | null;

  setPrimaryMonitor(monitorId: MonitorId): void;

  assignRuntimeWindow(
    assignment: RuntimeWindowMonitorAssignment,
  ): void;

  removeRuntimeWindowAssignment(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  getRuntimeWindowAssignment(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowMonitorAssignment | null;

  getAssignments():
    readonly RuntimeWindowMonitorAssignment[];

  getSnapshot(): MultiMonitorRuntimeSnapshot;
}
