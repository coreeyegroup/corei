/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   dockview-runtime-integration.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-05 — Dockview Runtime Integration
 *
 * Purpose:
 *   Defines the controlled provider-facing integration seam between the
 *   Phase-19 logical Window & Workspace Platform and an existing Dockview
 *   runtime implementation.
 *
 * Architectural Boundary:
 *   - The Phase-19 core does not directly import Dockview.
 *   - The adapter represents the existing Dockview runtime boundary.
 *   - The integration layer coordinates logical state with that adapter.
 *   - The integration layer does not own workspace or window registries.
 *
 * Browser Visibility:
 *   Step-05 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  WindowId,
  WindowReference,
  WorkspaceId,
  WorkspaceReference,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — RUNTIME ADAPTER CONTRACT
 * =============================================================================
 */

export interface DockviewRuntimeAdapterContract {
  /**
   * Returns whether the underlying Dockview runtime is ready to receive
   * synchronization commands.
   */
  isReady(): boolean;

  /**
   * Synchronizes a known logical workspace with the existing Dockview runtime.
   */
  synchronizeWorkspace(workspace: WorkspaceReference): void;

  /**
   * Synchronizes a known logical window with the existing Dockview runtime.
   */
  synchronizeWindow(window: WindowReference): void;

  /**
   * Removes a workspace representation from the existing Dockview runtime.
   */
  removeWorkspace(workspaceId: WorkspaceId): void;

  /**
   * Removes a window representation from the existing Dockview runtime.
   */
  removeWindow(windowId: WindowId): void;
}

/* =============================================================================
 * SECTION 02 — INTEGRATION SNAPSHOT
 * =============================================================================
 */

export interface DockviewRuntimeIntegrationSnapshot {
  readonly attached: boolean;
  readonly ready: boolean;
}

/* =============================================================================
 * SECTION 03 — INTEGRATION CONTRACT
 * =============================================================================
 */

export interface DockviewRuntimeIntegrationContract {
  /**
   * Attaches the existing Dockview runtime adapter.
   *
   * Duplicate attachment is rejected.
   */
  attachRuntime(adapter: DockviewRuntimeAdapterContract): void;

  /**
   * Detaches the currently attached runtime adapter.
   */
  detachRuntime(): void;

  /**
   * Returns whether a runtime adapter is attached.
   */
  isAttached(): boolean;

  /**
   * Returns whether the attached runtime is ready.
   */
  isReady(): boolean;

  /**
   * Synchronizes a known workspace through the attached runtime adapter.
   */
  synchronizeWorkspace(workspaceId: WorkspaceId): void;

  /**
   * Synchronizes a known window through the attached runtime adapter.
   */
  synchronizeWindow(windowId: WindowId): void;

  /**
   * Removes a known workspace representation from the attached runtime.
   */
  removeWorkspace(workspaceId: WorkspaceId): void;

  /**
   * Removes a known window representation from the attached runtime.
   */
  removeWindow(windowId: WindowId): void;

  /**
   * Returns the current immutable integration snapshot.
   */
  getSnapshot(): DockviewRuntimeIntegrationSnapshot;
}
