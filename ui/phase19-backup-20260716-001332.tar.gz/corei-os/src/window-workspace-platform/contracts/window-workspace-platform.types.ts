/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   window-workspace-platform.types.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-02 — Window & Workspace Platform Contract Boundary
 *
 * Purpose:
 *   Defines the provider-independent identity, lifecycle, reference, context,
 *   and snapshot vocabulary for the Window & Workspace Platform.
 *
 * Architectural Rules:
 *   - No React dependency.
 *   - No Dockview dependency.
 *   - No Zustand dependency.
 *   - No persistence implementation dependency.
 *   - No Shell implementation dependency.
 *   - No provider implementation dependency.
 *
 * =============================================================================
 */

/* =============================================================================
 * SECTION 01 — BRANDED IDENTITIES
 * =============================================================================
 */

declare const windowWorkspacePlatformIdBrand: unique symbol;
declare const workspaceIdBrand: unique symbol;
declare const windowIdBrand: unique symbol;

export type WindowWorkspacePlatformId = string & {
  readonly [windowWorkspacePlatformIdBrand]: true;
};

export type WorkspaceId = string & {
  readonly [workspaceIdBrand]: true;
};

export type WindowId = string & {
  readonly [windowIdBrand]: true;
};

/* =============================================================================
 * SECTION 02 — LIFECYCLE VOCABULARY
 * =============================================================================
 */

export type WindowWorkspacePlatformLifecycleState =
  | "idle"
  | "starting"
  | "running"
  | "stopping"
  | "stopped"
  | "failed";

export type WorkspaceLifecycleState =
  | "registered"
  | "inactive"
  | "activating"
  | "active"
  | "deactivating"
  | "failed";

export type WindowLifecycleState =
  | "registered"
  | "opening"
  | "open"
  | "closing"
  | "closed"
  | "failed";

/* =============================================================================
 * SECTION 03 — PLATFORM REFERENCES
 * =============================================================================
 */

export interface WorkspaceReference {
  readonly workspaceId: WorkspaceId;
  readonly lifecycleState: WorkspaceLifecycleState;
}

export interface WindowReference {
  readonly windowId: WindowId;
  readonly workspaceId: WorkspaceId | null;
  readonly lifecycleState: WindowLifecycleState;
}

/* =============================================================================
 * SECTION 04 — PLATFORM CONTEXT
 * =============================================================================
 */

export interface WindowWorkspacePlatformContext {
  readonly platformId: WindowWorkspacePlatformId;
  readonly lifecycleState: WindowWorkspacePlatformLifecycleState;
  readonly activeWorkspaceId: WorkspaceId | null;
  readonly activeWindowId: WindowId | null;
}

/* =============================================================================
 * SECTION 05 — PLATFORM SNAPSHOT
 * =============================================================================
 */

export interface WindowWorkspacePlatformSnapshot {
  readonly context: WindowWorkspacePlatformContext;
  readonly workspaces: readonly WorkspaceReference[];
  readonly windows: readonly WindowReference[];
}

/* =============================================================================
 * SECTION — LAYOUT RUNTIME TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-06
 *
 * These types define logical layout identity and lifecycle state only.
 *
 * They intentionally do not define:
 * - Dockview JSON;
 * - split geometry;
 * - tab ordering;
 * - group hierarchy;
 * - floating-window geometry;
 * - persistence payloads.
 *
 * =============================================================================
 */

export type LayoutId = string & {
  readonly __brand: "LayoutId";
};

export type LayoutLifecycleState =
  | "registered"
  | "active"
  | "inactive";

export interface LayoutReference {
  readonly layoutId: LayoutId;
  readonly workspaceId: WorkspaceId;
  readonly lifecycleState: LayoutLifecycleState;
}

/* =============================================================================
 * SECTION — LAYOUT COMPOSITION TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-07
 *
 * These types define provider-neutral logical layout composition.
 *
 * They intentionally do not define:
 * - Dockview provider objects;
 * - pixel geometry;
 * - split ratios;
 * - browser window coordinates;
 * - React components;
 * - persistence payloads.
 *
 * =============================================================================
 */

export type LayoutGroupId = string & {
  readonly __brand: "LayoutGroupId";
};

export type LayoutItemId = string & {
  readonly __brand: "LayoutItemId";
};

export type LayoutSplitOrientation =
  | "horizontal"
  | "vertical";

export interface LayoutGroupReference {
  readonly groupId: LayoutGroupId;
  readonly layoutId: LayoutId;
}

export interface LayoutItemReference {
  readonly itemId: LayoutItemId;
  readonly layoutId: LayoutId;
  readonly groupId: LayoutGroupId;
}

export interface LayoutSplitRelationship {
  readonly sourceGroupId: LayoutGroupId;
  readonly targetGroupId: LayoutGroupId;
  readonly orientation: LayoutSplitOrientation;
}

/* =============================================================================
 * SECTION — FLOATING WINDOW MANAGEMENT TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-08
 *
 * These types define provider-neutral logical floating-window state.
 *
 * They intentionally do not define:
 * - browser Window objects;
 * - DOM references;
 * - Screen API objects;
 * - Dockview provider objects;
 * - React components;
 * - persistence payloads.
 *
 * =============================================================================
 */

export type FloatingWindowId = string & {
  readonly __brand: "FloatingWindowId";
};

export type FloatingWindowLifecycleState =
  | "floating"
  | "active"
  | "focused"
  | "closed";

export interface FloatingWindowBounds {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export interface FloatingWindowRestorationMetadata {
  readonly sourceGroupId: LayoutGroupId;
  readonly sourceIndex: number;
}

export interface FloatingWindowReference {
  readonly floatingWindowId: FloatingWindowId;
  readonly windowId: WindowId;
  readonly workspaceId: WorkspaceId;
  readonly layoutId: LayoutId;
  readonly itemId: LayoutItemId;
  readonly sourceGroupId: LayoutGroupId;
  readonly lifecycleState: FloatingWindowLifecycleState;
  readonly bounds: FloatingWindowBounds;
  readonly runtimeContextId: string;
  readonly restorationMetadata: FloatingWindowRestorationMetadata;
}

/* =============================================================================
 * SECTION — MULTI-WINDOW RUNTIME TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-09
 *
 * These types define provider-neutral logical runtime-window coordination.
 *
 * They intentionally do not define:
 * - browser Window objects;
 * - DOM references;
 * - Screen API objects;
 * - cross-window transport channels;
 * - Dockview provider objects;
 * - React components;
 * - persistence payloads.
 *
 * =============================================================================
 */

export type ApplicationRuntimeId = string & {
  readonly __brand: "ApplicationRuntimeId";
};

export type RuntimeWindowId = string & {
  readonly __brand: "RuntimeWindowId";
};

export type RuntimeWindowLifecycleState =
  | "open"
  | "active"
  | "focused"
  | "closed";

export interface RuntimeWindowReference {
  readonly runtimeWindowId: RuntimeWindowId;
  readonly applicationRuntimeId: ApplicationRuntimeId;
  readonly windowId: WindowId;
  readonly workspaceId: WorkspaceId;
  readonly runtimeContextId: string;
  readonly lifecycleState: RuntimeWindowLifecycleState;
}

/* =============================================================================
 * SECTION — MULTI-MONITOR RUNTIME TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-10
 *
 * These types define provider-neutral logical monitor topology and runtime-window
 * placement state.
 *
 * They intentionally do not define:
 * - browser Screen objects;
 * - ScreenDetailed objects;
 * - browser Window objects;
 * - operating-system monitor handles;
 * - DOM references;
 * - Dockview provider objects;
 * - React components;
 * - persistence payloads.
 *
 * =============================================================================
 */

export type MonitorId = string & {
  readonly __brand: "MonitorId";
};

export interface MonitorBounds {
  readonly x: number;
  readonly y: number;
  readonly width: number;
  readonly height: number;
}

export interface MonitorReference {
  readonly monitorId: MonitorId;
  readonly isPrimary: boolean;
  readonly bounds: MonitorBounds;
  readonly workArea: MonitorBounds;
}

export type RuntimeWindowPlacementMode =
  | "normal"
  | "maximized"
  | "fullscreen";

export interface RuntimeWindowMonitorAssignment {
  readonly runtimeWindowId: RuntimeWindowId;
  readonly monitorId: MonitorId;
  readonly bounds: MonitorBounds;
  readonly placementMode: RuntimeWindowPlacementMode;
}

/* =============================================================================
 * SECTION — WORKSPACE FOCUS & PRESENTATION MODE TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-11
 *
 * These types define provider-neutral workspace mode semantics.
 *
 * They intentionally do not define:
 * - DOM elements;
 * - React components;
 * - CSS classes;
 * - browser fullscreen objects;
 * - Dockview provider objects;
 * - Phase-20 panel identities;
 * - persistence payloads;
 * - recovery payloads.
 *
 * =============================================================================
 */

export type WorkspacePresentationMode =
  | "normal"
  | "focus"
  | "fullscreen"
  | "presentation";

export interface WorkspaceVisibilityState {
  readonly topRegionVisible: boolean;
  readonly leftRegionVisible: boolean;
  readonly rightRegionVisible: boolean;
  readonly bottomRegionVisible: boolean;
  readonly statusRegionVisible: boolean;
}

export interface WorkspaceModeRestorationPoint {
  readonly workspaceId: WorkspaceId;
  readonly layoutId: LayoutId | null;
  readonly focusTargetId: string | null;
  readonly visibility: WorkspaceVisibilityState;
}

export interface WorkspaceModeState {
  readonly workspaceId: WorkspaceId;
  readonly mode: WorkspacePresentationMode;
  readonly focusTargetId: string | null;
  readonly visibility: WorkspaceVisibilityState;
  readonly restorationPoint: WorkspaceModeRestorationPoint | null;
}

/* =============================================================================
 * SECTION — WORKSPACE SWITCHING & ACTIVE CONTEXT TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-12
 *
 * These types define the provider-neutral active-context projection used by
 * workspace-switch coordination.
 *
 * The Step-03 Workspace Operational Coordinator remains the authoritative
 * owner of workspace identity, lifecycle, and active-workspace state.
 *
 * Step-12 does not introduce:
 * - a competing workspace registry;
 * - a competing lifecycle state machine;
 * - persistence or serialization;
 * - event publication;
 * - global state integration;
 * - Shell or React ownership.
 *
 * =============================================================================
 */

export interface WorkspaceActiveContext {
  readonly activeWorkspaceId: WorkspaceId | null;
  readonly previousWorkspaceId: WorkspaceId | null;
  readonly switchSequence: number;
}

export interface WorkspaceSwitchResult {
  readonly previousWorkspaceId: WorkspaceId | null;
  readonly activeWorkspaceId: WorkspaceId;
  readonly changed: boolean;
  readonly switchSequence: number;
}

/* =============================================================================
 * SECTION — WORKSPACE PERSISTENCE & SERIALIZATION TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-13
 *
 * These types establish the provider-neutral persistence envelope used by the
 * Window & Workspace Platform.
 *
 * Step-13 owns deterministic persistence representation and storage delegation.
 *
 * Step-13 does not own:
 * - restoration execution;
 * - recovery execution;
 * - Shell hydration;
 * - Workbench hydration;
 * - browser storage selection;
 * - infrastructure-specific storage implementation.
 *
 * =============================================================================
 */

export type WindowWorkspacePersistenceKey = string;

export type WindowWorkspacePersistenceSchemaVersion =
  "corei.window-workspace.persistence.v1";

export interface WindowWorkspacePersistenceRecord {
  readonly key: WindowWorkspacePersistenceKey;
  readonly schemaVersion: WindowWorkspacePersistenceSchemaVersion;
  readonly serializedSnapshot: string;
}

/* =============================================================================
 * SECTION — WORKSPACE RESTORATION & RECOVERY TYPES
 * =============================================================================
 *
 * Stage-25 / Phase-19 / Step-14
 *
 * These types establish deterministic restoration and recovery classification.
 *
 * Step-14 owns:
 * - restoration validation;
 * - restoration readiness;
 * - recovery classification;
 * - fallback selection.
 *
 * Step-14 does not own:
 * - Shell integration;
 * - Workbench integration;
 * - active runtime hydration;
 * - event publication;
 * - State Platform synchronization.
 *
 * =============================================================================
 */

export type WorkspaceRestorationStatus =
  | "ready"
  | "missing"
  | "invalid-record"
  | "deserialization-failed";

export type WorkspaceRecoveryStatus =
  | "primary-ready"
  | "fallback-ready"
  | "failed";

export type WorkspaceRecoveryFailureCode =
  | "primary-missing"
  | "primary-invalid-record"
  | "primary-deserialization-failed"
  | "fallback-missing"
  | "fallback-invalid-record"
  | "fallback-deserialization-failed";
