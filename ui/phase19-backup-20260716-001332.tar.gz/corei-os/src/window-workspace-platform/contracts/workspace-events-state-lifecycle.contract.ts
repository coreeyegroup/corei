/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-16 — Workspace Events, State & Lifecycle Coordination
 *
 * File:
 *   workspace-events-state-lifecycle.contract.ts
 *
 * Purpose:
 *   Defines the provider-independent coordination boundary for deterministic
 *   Phase-19 workspace, window, layout, persistence, and recovery lifecycle
 *   events and their corresponding projected state.
 *
 * Architectural Ownership:
 *   Phase-19 owns Window & Workspace lifecycle semantics.
 *   The existing COREI Event Platform owns event infrastructure.
 *   The existing COREI State Platform owns state infrastructure.
 *
 * Critical Boundary:
 *   This contract does not create an event bus, global store, provider,
 *   diagnostics platform, telemetry system, or UI state system.
 *
 * Browser Visibility:
 *   Step-16 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  LayoutId,
  WindowId,
  WorkspaceId,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — EVENT TYPE SURFACE
 * =============================================================================
 */

export type WorkspacePlatformLifecycleEventType =
  | "workspace.opened"
  | "workspace.activated"
  | "workspace.deactivated"
  | "workspace.closed"
  | "window.opened"
  | "window.focused"
  | "window.closed"
  | "layout.changed"
  | "layout.restored"
  | "workspace.persistence.completed"
  | "workspace.recovery.started"
  | "workspace.recovery.completed"
  | "workspace.recovery.failed";

/* =============================================================================
 * SECTION 02 — EVENT IDENTITY / ENVELOPE
 * =============================================================================
 */

export type WorkspacePlatformLifecycleEventSequence =
  number;

export interface WorkspacePlatformLifecycleEvent {
  readonly type:
    WorkspacePlatformLifecycleEventType;

  readonly sequence:
    WorkspacePlatformLifecycleEventSequence;

  readonly workspaceId:
    WorkspaceId | null;

  readonly windowId:
    WindowId | null;

  readonly layoutId:
    LayoutId | null;
}

/* =============================================================================
 * SECTION 03 — PROJECTED PHASE-19 STATE
 * =============================================================================
 */

export interface WorkspacePlatformLifecycleState {
  readonly sequence:
    WorkspacePlatformLifecycleEventSequence;

  readonly activeWorkspaceId:
    WorkspaceId | null;

  readonly activeWindowId:
    WindowId | null;

  readonly activeLayoutId:
    LayoutId | null;

  readonly persistenceCompleted:
    boolean;

  readonly recoveryInProgress:
    boolean;

  readonly recoveryFailed:
    boolean;

  readonly lastEventType:
    WorkspacePlatformLifecycleEventType | null;
}

/* =============================================================================
 * SECTION 04 — EXISTING EVENT PLATFORM ADAPTER PORT
 * =============================================================================
 */

export interface WorkspacePlatformEventPublicationPort {
  publish(
    event:
      Readonly<WorkspacePlatformLifecycleEvent>,
  ): void;
}

/* =============================================================================
 * SECTION 05 — EXISTING STATE PLATFORM ADAPTER PORT
 * =============================================================================
 */

export interface WorkspacePlatformStatePublicationPort {
  publish(
    state:
      Readonly<WorkspacePlatformLifecycleState>,
  ): void;
}

/* =============================================================================
 * SECTION 06 — COORDINATION SNAPSHOT
 * =============================================================================
 */

export interface WorkspaceEventsStateLifecycleSnapshot {
  readonly state:
    Readonly<WorkspacePlatformLifecycleState>;

  readonly events:
    readonly Readonly<WorkspacePlatformLifecycleEvent>[];
}

/* =============================================================================
 * SECTION 07 — COORDINATION CONTRACT
 * =============================================================================
 */

export interface WorkspaceEventsStateLifecycleContract {
  coordinate(
    type:
      WorkspacePlatformLifecycleEventType,

    context?: {
      readonly workspaceId?:
        WorkspaceId | null;

      readonly windowId?:
        WindowId | null;

      readonly layoutId?:
        LayoutId | null;
    },
  ): Readonly<WorkspacePlatformLifecycleEvent>;

  getState():
    Readonly<WorkspacePlatformLifecycleState>;

  getEvents():
    readonly Readonly<WorkspacePlatformLifecycleEvent>[];

  getSnapshot():
    Readonly<WorkspaceEventsStateLifecycleSnapshot>;
}
