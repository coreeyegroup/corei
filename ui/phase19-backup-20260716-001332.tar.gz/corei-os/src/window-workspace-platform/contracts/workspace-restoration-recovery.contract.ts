/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-restoration-recovery.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-14 — Workspace Restoration & Recovery
 *
 * Purpose:
 *   Defines deterministic restoration validation, restoration readiness,
 *   recovery classification, and fallback recovery coordination.
 *
 * Ownership Boundary:
 *   Step-14 validates and prepares persisted workspace state for later runtime
 *   application.
 *
 *   Step-14 does not directly hydrate the Shell, Workbench, WorkspaceHost,
 *   layout runtime, window runtime, event platform, or state platform.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by Step-14.
 *
 * =============================================================================
 */

import type {
  WindowWorkspacePersistenceIntegrationContract,
  WindowWorkspacePersistenceSnapshot,
} from "./workspace-persistence-serialization.contract";

import type {
  WindowWorkspacePersistenceKey,
  WorkspaceRecoveryFailureCode,
  WorkspaceRecoveryStatus,
  WorkspaceRestorationStatus,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — RESTORATION RESULT
 * =============================================================================
 */

export interface WorkspaceRestorationResult {
  readonly key: WindowWorkspacePersistenceKey;
  readonly status: WorkspaceRestorationStatus;
  readonly snapshot:
    WindowWorkspacePersistenceSnapshot | null;
  readonly failureMessage:
    string | null;
}

/* =============================================================================
 * SECTION 02 — RECOVERY REQUEST
 * =============================================================================
 */

export interface WorkspaceRecoveryRequest {
  readonly primaryKey:
    WindowWorkspacePersistenceKey;

  readonly fallbackKey:
    WindowWorkspacePersistenceKey | null;
}

/* =============================================================================
 * SECTION 03 — RECOVERY RESULT
 * =============================================================================
 */

export interface WorkspaceRecoveryResult {
  readonly status:
    WorkspaceRecoveryStatus;

  readonly selectedKey:
    WindowWorkspacePersistenceKey | null;

  readonly snapshot:
    WindowWorkspacePersistenceSnapshot | null;

  readonly primary:
    WorkspaceRestorationResult;

  readonly fallback:
    WorkspaceRestorationResult | null;

  readonly failureCodes:
    readonly WorkspaceRecoveryFailureCode[];
}

/* =============================================================================
 * SECTION 04 — RESTORATION / RECOVERY CONTRACT
 * =============================================================================
 */

export interface WorkspaceRestorationRecoveryContract {
  restore(
    key: WindowWorkspacePersistenceKey,
  ): WorkspaceRestorationResult;

  recover(
    request: WorkspaceRecoveryRequest,
  ): WorkspaceRecoveryResult;
}

/* =============================================================================
 * SECTION 05 — DEPENDENCY CONTRACT
 * =============================================================================
 */

export type WorkspaceRestorationPersistenceAuthority =
  Pick<
    WindowWorkspacePersistenceIntegrationContract,
    "has" | "load" | "deserializeRecord"
  >;
