/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-15 — Shell ↔ Workbench ↔ Workspace Runtime Integration
 *
 * File:
 *   shell-workbench-workspace-runtime-integration.contract.ts
 *
 * Purpose:
 *   Defines the authoritative integration boundary through which the Workbench
 *   consumes the completed Phase-19 Window & Workspace Platform authorities.
 *
 * Architectural Ownership:
 *   The Window & Workspace Platform owns runtime coordination.
 *   The Workbench owns React integration and workspace presentation.
 *   The Institutional Shell remains a consumer of the Workbench public API.
 *
 * Critical Boundaries:
 *   - no Shell internals;
 *   - no direct Dockview mechanics;
 *   - no Event Platform integration;
 *   - no State Platform integration;
 *   - no diagnostics ownership;
 *   - no Panel / Visualization Platform ownership.
 *
 * =============================================================================
 */

import type {
  DockviewRuntimeIntegrationContract,
} from "./dockview-runtime-integration.contract";

import type {
  FloatingWindowManagementContract,
} from "./floating-window-management.contract";

import type {
  LayoutCompositionContract,
} from "./layout-composition.contract";

import type {
  LayoutRuntimeContract,
} from "./layout-runtime.contract";

import type {
  MultiMonitorRuntimeContract,
} from "./multi-monitor-runtime.contract";

import type {
  MultiWindowRuntimeContract,
} from "./multi-window-runtime.contract";

import type {
  WindowManagementContract,
} from "./window-management.contract";

import type {
  WindowWorkspacePersistenceIntegrationContract,
} from "./workspace-persistence-serialization.contract";

import type {
  WorkspaceFocusPresentationContract,
} from "./workspace-focus-presentation.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "./workspace-operational-coordinator.contract";

import type {
  WorkspaceRestorationRecoveryContract,
} from "./workspace-restoration-recovery.contract";

import type {
  WorkspaceSwitchingContract,
} from "./workspace-switching.contract";

/* =============================================================================
 * SECTION 01 — INTEGRATION LIFECYCLE
 * =============================================================================
 */

export type ShellWorkbenchWorkspaceRuntimeIntegrationState =
  | "created"
  | "initialized"
  | "running"
  | "stopped";

/* =============================================================================
 * SECTION 02 — AUTHORITATIVE RUNTIME AUTHORITY SET
 * =============================================================================
 */

export interface ShellWorkbenchWorkspaceRuntimeAuthorities {
  readonly workspaceOperations:
    WorkspaceOperationalCoordinatorContract;

  readonly windowManagement:
    WindowManagementContract;

  readonly docking:
    DockviewRuntimeIntegrationContract;

  readonly layout:
    LayoutRuntimeContract;

  readonly layoutComposition:
    LayoutCompositionContract;

  readonly floatingWindows:
    FloatingWindowManagementContract;

  readonly multiWindow:
    MultiWindowRuntimeContract;

  readonly multiMonitor:
    MultiMonitorRuntimeContract;

  readonly focusPresentation:
    WorkspaceFocusPresentationContract;

  readonly workspaceSwitching:
    WorkspaceSwitchingContract;

  readonly persistence:
    WindowWorkspacePersistenceIntegrationContract;

  readonly restorationRecovery:
    WorkspaceRestorationRecoveryContract;
}

/* =============================================================================
 * SECTION 03 — WORKBENCH INTEGRATION CONTRACT
 * =============================================================================
 */

export interface ShellWorkbenchWorkspaceRuntimeIntegrationContract {
  initialize(): void;

  start(): void;

  stop(): void;

  getState():
    ShellWorkbenchWorkspaceRuntimeIntegrationState;

  getAuthorities():
    Readonly<ShellWorkbenchWorkspaceRuntimeAuthorities>;
}
