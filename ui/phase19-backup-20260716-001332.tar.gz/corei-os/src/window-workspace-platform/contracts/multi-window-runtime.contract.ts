/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   multi-window-runtime.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-09 — Multi-Window Runtime
 *
 * Purpose:
 *   Defines provider-neutral runtime coordination for multiple simultaneous
 *   COREI operational windows.
 *
 * Architectural Boundary:
 *   This contract owns logical runtime-window identity, registration, lifecycle,
 *   active/focus coordination, workspace association, runtime-context identity,
 *   and deterministic snapshots.
 *
 *   It does not execute:
 *   - browser window creation;
 *   - browser window focus;
 *   - browser window destruction;
 *   - cross-window messaging;
 *   - multi-monitor placement;
 *   - Dockview provider APIs;
 *   - persistence;
 *   - rendering.
 *
 * Browser Visibility:
 *   Step-09 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  ApplicationRuntimeId,
  RuntimeWindowId,
  RuntimeWindowReference,
  WindowId,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — RUNTIME WINDOW REGISTRATION REQUEST
 * =============================================================================
 */

export interface RegisterRuntimeWindowRequest
  extends RuntimeWindowReference {}

/* =============================================================================
 * SECTION 02 — MULTI-WINDOW RUNTIME SNAPSHOT
 * =============================================================================
 */

export interface MultiWindowRuntimeSnapshot {
  readonly applicationRuntimeId: ApplicationRuntimeId;
  readonly runtimeWindows: readonly RuntimeWindowReference[];
  readonly activeRuntimeWindowId: RuntimeWindowId | null;
  readonly focusedRuntimeWindowId: RuntimeWindowId | null;
}

/* =============================================================================
 * SECTION 03 — MULTI-WINDOW RUNTIME CONTRACT
 * =============================================================================
 */

export interface MultiWindowRuntimeContract {
  registerRuntimeWindow(
    request: RegisterRuntimeWindowRequest,
  ): void;

  unregisterRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  hasRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): boolean;

  getRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): RuntimeWindowReference | null;

  getRuntimeWindowForWindow(
    windowId: WindowId,
  ): RuntimeWindowReference | null;

  getRuntimeWindows():
    readonly RuntimeWindowReference[];

  activateRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  focusRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  closeRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  restoreRuntimeWindow(
    runtimeWindowId: RuntimeWindowId,
  ): void;

  getSnapshot(): MultiWindowRuntimeSnapshot;
}
