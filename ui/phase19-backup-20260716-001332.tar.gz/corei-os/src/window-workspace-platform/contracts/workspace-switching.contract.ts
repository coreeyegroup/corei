/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-switching.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-12 — Workspace Switching & Active Context Coordination
 *
 * Purpose:
 *   Defines deterministic workspace-switch coordination over the authoritative
 *   Step-03 Workspace Operational Coordinator.
 *
 * Architectural Boundary:
 *   Step-12 owns switching intent, transition ordering, no-op semantics,
 *   switch sequencing, and active-context projection.
 *
 *   Step-12 does not own:
 *   - workspace identity registration;
 *   - workspace lifecycle implementation;
 *   - persistence;
 *   - serialization;
 *   - restoration;
 *   - recovery;
 *   - event publication;
 *   - global state integration;
 *   - Shell rendering;
 *   - React binding;
 *   - browser execution.
 *
 * Browser Visibility:
 *   Step-12 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  WorkspaceActiveContext,
  WorkspaceId,
  WorkspaceSwitchResult,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — WORKSPACE SWITCHING SNAPSHOT
 * =============================================================================
 */

export interface WorkspaceSwitchingSnapshot {
  readonly activeContext: WorkspaceActiveContext;
}

/* =============================================================================
 * SECTION 02 — WORKSPACE SWITCHING CONTRACT
 * =============================================================================
 */

export interface WorkspaceSwitchingContract {
  switchWorkspace(
    targetWorkspaceId: WorkspaceId,
  ): WorkspaceSwitchResult;

  getActiveContext(): WorkspaceActiveContext;

  getSnapshot(): WorkspaceSwitchingSnapshot;
}
