/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-operational-coordinator.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-03 — Workspace Operational Coordination
 *
 * Purpose:
 *   Defines the provider-independent operational coordination contract for
 *   workspace references known to the Phase-19 platform boundary.
 *
 * Architectural Boundary:
 *   This contract coordinates workspace operational state.
 *
 *   It does not replace:
 *   - existing workspace registries;
 *   - existing workspace runtimes;
 *   - existing workspace loaders;
 *   - existing workspace persistence;
 *   - existing Workbench composition.
 *
 * =============================================================================
 */

import type {
  WorkspaceId,
  WorkspaceLifecycleState,
  WorkspaceReference,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — COORDINATOR SNAPSHOT
 * =============================================================================
 */

export interface WorkspaceOperationalSnapshot {
  readonly activeWorkspaceId: WorkspaceId | null;
  readonly workspaces: readonly WorkspaceReference[];
}

/* =============================================================================
 * SECTION 02 — COORDINATOR CONTRACT
 * =============================================================================
 */

export interface WorkspaceOperationalCoordinatorContract {
  /**
   * Registers a workspace reference with the Phase-19 coordination boundary.
   *
   * Duplicate workspace identities are rejected.
   */
  registerWorkspace(workspace: WorkspaceReference): void;

  /**
   * Removes a known workspace from the coordination boundary.
   *
   * Removing the active workspace also clears the active workspace identity.
   */
  unregisterWorkspace(workspaceId: WorkspaceId): void;

  /**
   * Returns whether a workspace identity is currently known.
   */
  hasWorkspace(workspaceId: WorkspaceId): boolean;

  /**
   * Returns a workspace reference when known.
   */
  getWorkspace(workspaceId: WorkspaceId): WorkspaceReference | null;

  /**
   * Returns an immutable snapshot of all known workspace references.
   */
  getWorkspaces(): readonly WorkspaceReference[];

  /**
   * Updates the lifecycle state of a known workspace.
   */
  setWorkspaceLifecycleState(
    workspaceId: WorkspaceId,
    lifecycleState: WorkspaceLifecycleState,
  ): void;

  /**
   * Makes a known workspace the active workspace.
   */
  setActiveWorkspace(workspaceId: WorkspaceId): void;

  /**
   * Clears the active workspace identity.
   */
  clearActiveWorkspace(): void;

  /**
   * Returns the active workspace identity when one exists.
   */
  getActiveWorkspaceId(): WorkspaceId | null;

  /**
   * Returns an immutable operational snapshot.
   */
  getSnapshot(): WorkspaceOperationalSnapshot;
}
