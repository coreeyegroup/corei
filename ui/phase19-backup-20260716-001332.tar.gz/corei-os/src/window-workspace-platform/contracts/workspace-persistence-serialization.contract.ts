/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-persistence-serialization.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-13 — Workspace Persistence & Serialization Integration
 *
 * Purpose:
 *   Defines the canonical Phase-19 persistence snapshot, deterministic
 *   serialization boundary, persistence adapter port, and persistence
 *   integration contract.
 *
 * Ownership Boundary:
 *   Step-13 owns persistence representation and storage delegation.
 *
 *   Step-13 does not own:
 *   - restoration;
 *   - recovery;
 *   - Shell hydration;
 *   - Workbench hydration;
 *   - browser storage technology;
 *   - infrastructure storage implementation.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by Step-13.
 *
 * =============================================================================
 */

import type {
  WindowWorkspacePersistenceKey,
  WindowWorkspacePersistenceRecord,
  WindowWorkspacePersistenceSchemaVersion,
} from "./window-workspace-platform.types";

import type {
  WindowWorkspacePlatformContract,
} from "./window-workspace-platform.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "./workspace-operational-coordinator.contract";

import type {
  WindowManagementSnapshot,
} from "./window-management.contract";

import type {
  LayoutRuntimeSnapshot,
} from "./layout-runtime.contract";

import type {
  LayoutCompositionSnapshot,
} from "./layout-composition.contract";

import type {
  FloatingWindowManagementSnapshot,
} from "./floating-window-management.contract";

import type {
  MultiWindowRuntimeSnapshot,
} from "./multi-window-runtime.contract";

import type {
  MultiMonitorRuntimeSnapshot,
} from "./multi-monitor-runtime.contract";

import type {
  WorkspaceFocusPresentationSnapshot,
} from "./workspace-focus-presentation.contract";

import type {
  WorkspaceSwitchingSnapshot,
} from "./workspace-switching.contract";

/* =============================================================================
 * SECTION 01 — CANONICAL PERSISTENCE SNAPSHOT
 * =============================================================================
 */

export interface WindowWorkspacePersistenceSnapshot {
  readonly schemaVersion:
    WindowWorkspacePersistenceSchemaVersion;

  readonly workspacePlatform:
    ReturnType<
      WindowWorkspacePlatformContract["getSnapshot"]
    >;

  readonly workspaceOperations:
    ReturnType<
      WorkspaceOperationalCoordinatorContract["getSnapshot"]
    >;

  readonly windowManagement:
    WindowManagementSnapshot;

  readonly layoutRuntime:
    LayoutRuntimeSnapshot;

  readonly layoutComposition:
    LayoutCompositionSnapshot;

  readonly floatingWindows:
    FloatingWindowManagementSnapshot;

  readonly multiWindow:
    MultiWindowRuntimeSnapshot;

  readonly multiMonitor:
    MultiMonitorRuntimeSnapshot;

  readonly focusPresentation:
    WorkspaceFocusPresentationSnapshot;

  readonly workspaceSwitching:
    WorkspaceSwitchingSnapshot;
}

/* =============================================================================
 * SECTION 02 — SNAPSHOT SOURCE CONTRACT
 * =============================================================================
 */

export interface WindowWorkspacePersistenceSnapshotSource {
  getPersistenceSnapshot():
    WindowWorkspacePersistenceSnapshot;
}

/* =============================================================================
 * SECTION 03 — DETERMINISTIC SERIALIZER CONTRACT
 * =============================================================================
 */

export interface WindowWorkspaceSerializerContract {
  serialize(
    snapshot: WindowWorkspacePersistenceSnapshot,
  ): string;

  deserialize(
    serializedSnapshot: string,
  ): WindowWorkspacePersistenceSnapshot;
}

/* =============================================================================
 * SECTION 04 — PERSISTENCE ADAPTER PORT
 * =============================================================================
 */

export interface WindowWorkspacePersistenceAdapter {
  save(
    record: WindowWorkspacePersistenceRecord,
  ): void;

  load(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord | null;

  remove(
    key: WindowWorkspacePersistenceKey,
  ): void;

  has(
    key: WindowWorkspacePersistenceKey,
  ): boolean;
}

/* =============================================================================
 * SECTION 05 — PERSISTENCE INTEGRATION CONTRACT
 * =============================================================================
 */

export interface WindowWorkspacePersistenceIntegrationContract {
  capture():
    WindowWorkspacePersistenceSnapshot;

  serialize():
    string;

  createRecord(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord;

  save(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord;

  load(
    key: WindowWorkspacePersistenceKey,
  ): WindowWorkspacePersistenceRecord | null;

  deserializeRecord(
    record: WindowWorkspacePersistenceRecord,
  ): WindowWorkspacePersistenceSnapshot;

  remove(
    key: WindowWorkspacePersistenceKey,
  ): void;

  has(
    key: WindowWorkspacePersistenceKey,
  ): boolean;
}
