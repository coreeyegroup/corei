/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-focus-presentation.contract.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-11 — Workspace Focus & Presentation Modes
 *
 * Purpose:
 *   Defines deterministic provider-neutral workspace mode semantics for Normal,
 *   Focus, Fullscreen, and Presentation operation.
 *
 * Architectural Boundary:
 *   This contract owns workspace mode state and restoration semantics.
 *
 *   It does not execute:
 *   - browser fullscreen APIs;
 *   - DOM mutation;
 *   - Shell visibility mutation;
 *   - React rendering;
 *   - workspace switching;
 *   - persistence;
 *   - serialization;
 *   - recovery;
 *   - event publication.
 *
 * Browser Visibility:
 *   Step-11 introduces no intentional visual change.
 *
 * =============================================================================
 */

import type {
  LayoutId,
  WorkspaceId,
  WorkspaceModeState,
  WorkspacePresentationMode,
  WorkspaceVisibilityState,
} from "./window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — MODE ENTRY INPUT
 * =============================================================================
 */

export interface WorkspaceModeEntry {
  readonly workspaceId: WorkspaceId;
  readonly mode: Exclude<WorkspacePresentationMode, "normal">;
  readonly layoutId: LayoutId | null;
  readonly focusTargetId: string | null;
  readonly currentVisibility: WorkspaceVisibilityState;
  readonly targetVisibility: WorkspaceVisibilityState;
}

/* =============================================================================
 * SECTION 02 — MODE RUNTIME SNAPSHOT
 * =============================================================================
 */

export interface WorkspaceFocusPresentationSnapshot {
  readonly workspaceModes: readonly WorkspaceModeState[];
}

/* =============================================================================
 * SECTION 03 — WORKSPACE FOCUS / PRESENTATION CONTRACT
 * =============================================================================
 */

export interface WorkspaceFocusPresentationContract {
  initializeWorkspace(
    workspaceId: WorkspaceId,
    visibility: WorkspaceVisibilityState,
  ): void;

  enterMode(entry: WorkspaceModeEntry): void;

  restoreNormalMode(workspaceId: WorkspaceId): void;

  hasWorkspaceMode(workspaceId: WorkspaceId): boolean;

  getWorkspaceMode(
    workspaceId: WorkspaceId,
  ): WorkspaceModeState | null;

  getWorkspaceModes(): readonly WorkspaceModeState[];

  getSnapshot(): WorkspaceFocusPresentationSnapshot;
}
