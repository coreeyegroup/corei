/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-15 — Shell ↔ Workbench ↔ Workspace Runtime Integration
 *
 * File:
 *   shell-workbench-workspace-runtime-coordinator.ts
 *
 * Purpose:
 *   Provides the deterministic composition authority consumed by the Workbench
 *   when integrating the active workspace surface with Phase-19 runtime
 *   authorities.
 *
 * Architectural Boundary:
 *   This coordinator aggregates already-completed Phase-19 authorities.
 *   It does not recreate their behavior and does not own Shell rendering,
 *   Workbench rendering, events, global state, diagnostics, or providers.
 *
 * =============================================================================
 */

import type {
  ShellWorkbenchWorkspaceRuntimeAuthorities,
  ShellWorkbenchWorkspaceRuntimeIntegrationContract,
  ShellWorkbenchWorkspaceRuntimeIntegrationState,
} from "../contracts/shell-workbench-workspace-runtime-integration.contract";

/* =============================================================================
 * SECTION 01 — COORDINATOR
 * =============================================================================
 */

export class ShellWorkbenchWorkspaceRuntimeCoordinator
  implements ShellWorkbenchWorkspaceRuntimeIntegrationContract
{
  private state:
    ShellWorkbenchWorkspaceRuntimeIntegrationState =
      "created";

  public constructor(
    private readonly authorities:
      Readonly<ShellWorkbenchWorkspaceRuntimeAuthorities>,
  ) {}

  /* ===========================================================================
   * LIFECYCLE
   * ===========================================================================
   */

  public initialize(): void {
    if (this.state !== "created") {
      return;
    }

    this.state = "initialized";
  }

  public start(): void {
    if (this.state === "running") {
      return;
    }

    if (this.state === "created") {
      this.initialize();
    }

    if (this.state === "stopped") {
      this.state = "initialized";
    }

    this.state = "running";
  }

  public stop(): void {
    if (this.state === "stopped") {
      return;
    }

    this.state = "stopped";
  }

  /* ===========================================================================
   * STATE / AUTHORITY ACCESS
   * ===========================================================================
   */

  public getState():
    ShellWorkbenchWorkspaceRuntimeIntegrationState {
    return this.state;
  }

  public getAuthorities():
    Readonly<ShellWorkbenchWorkspaceRuntimeAuthorities> {
    return this.authorities;
  }
}
