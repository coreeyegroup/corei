/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM COMPOSITION
 * =============================================================================
 *
 * Public composition surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  ShellWorkbenchWorkspaceRuntimeCoordinator,
} from "./shell-workbench-workspace-runtime-coordinator";
