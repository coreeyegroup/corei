/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-switching-coordinator.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-12 — Workspace Switching & Active Context Coordination
 *
 * Purpose:
 *   Coordinates deterministic workspace switching through the existing Step-03
 *   Workspace Operational Coordinator public authority.
 *
 * Repository-Reality Reconciliation:
 *   The Step-03 public contract exposes setActiveWorkspace(...) as the canonical
 *   active-workspace transition authority.
 *
 *   Step-12 therefore coordinates switching through that existing authority
 *   rather than inventing unsupported activateWorkspace(...) or
 *   suspendWorkspace(...) operations.
 *
 * Ownership:
 *   - Owns workspace-switch intent.
 *   - Owns deterministic no-op semantics.
 *   - Owns switch sequence tracking.
 *   - Owns previous-workspace transition context.
 *   - Owns active-context projection derived from Step-03 authority.
 *
 * Non-Ownership:
 *   - Does not own workspace registration.
 *   - Does not implement workspace lifecycle.
 *   - Does not expand the Step-03 contract.
 *   - Does not persist or serialize state.
 *   - Does not restore or recover workspaces.
 *   - Does not publish events.
 *   - Does not mutate global state.
 *   - Does not render UI.
 *   - Does not execute browser APIs.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  WorkspaceSwitchingContract,
  WorkspaceSwitchingSnapshot,
} from "../contracts/workspace-switching.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  WorkspaceActiveContext,
  WorkspaceId,
  WorkspaceSwitchResult,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const unknownWorkspaceMessage = (
  workspaceId: WorkspaceId,
): string =>
  `Workspace is not registered: ${workspaceId}`;

const activeContextMismatchMessage = (
  targetWorkspaceId: WorkspaceId,
  authoritativeWorkspaceId: WorkspaceId | null,
): string =>
  [
    "Workspace switch did not establish the requested active context.",
    `Requested: ${targetWorkspaceId}.`,
    `Authoritative: ${String(authoritativeWorkspaceId)}.`,
  ].join(" ");

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyActiveContext = (
  context: WorkspaceActiveContext,
): WorkspaceActiveContext => ({
  activeWorkspaceId: context.activeWorkspaceId,
  previousWorkspaceId: context.previousWorkspaceId,
  switchSequence: context.switchSequence,
});

const copySwitchResult = (
  result: WorkspaceSwitchResult,
): WorkspaceSwitchResult => ({
  previousWorkspaceId: result.previousWorkspaceId,
  activeWorkspaceId: result.activeWorkspaceId,
  changed: result.changed,
  switchSequence: result.switchSequence,
});

/* =============================================================================
 * SECTION 03 — WORKSPACE SWITCHING COORDINATOR
 * =============================================================================
 */

export class WorkspaceSwitchingCoordinator
  implements WorkspaceSwitchingContract
{
  private previousWorkspaceId: WorkspaceId | null = null;

  private switchSequence = 0;

  public constructor(
    private readonly workspaceCoordinator:
      WorkspaceOperationalCoordinatorContract,
  ) {}

  /* ===========================================================================
   * SWITCH COORDINATION
   * ===========================================================================
   */

  public switchWorkspace(
    targetWorkspaceId: WorkspaceId,
  ): WorkspaceSwitchResult {
    this.requireWorkspace(targetWorkspaceId);

    const previousWorkspaceId =
      this.workspaceCoordinator.getActiveWorkspaceId();

    if (previousWorkspaceId === targetWorkspaceId) {
      return copySwitchResult({
        previousWorkspaceId,
        activeWorkspaceId: targetWorkspaceId,
        changed: false,
        switchSequence: this.switchSequence,
      });
    }

    this.workspaceCoordinator.setActiveWorkspace(
      targetWorkspaceId,
    );

    const authoritativeActiveWorkspaceId =
      this.workspaceCoordinator.getActiveWorkspaceId();

    if (
      authoritativeActiveWorkspaceId !==
      targetWorkspaceId
    ) {
      throw new Error(
        activeContextMismatchMessage(
          targetWorkspaceId,
          authoritativeActiveWorkspaceId,
        ),
      );
    }

    this.previousWorkspaceId =
      previousWorkspaceId;

    this.switchSequence += 1;

    return copySwitchResult({
      previousWorkspaceId,
      activeWorkspaceId: targetWorkspaceId,
      changed: true,
      switchSequence: this.switchSequence,
    });
  }

  /* ===========================================================================
   * ACTIVE CONTEXT
   * ===========================================================================
   */

  public getActiveContext():
    WorkspaceActiveContext {
    return copyActiveContext({
      activeWorkspaceId:
        this.workspaceCoordinator.getActiveWorkspaceId(),
      previousWorkspaceId:
        this.previousWorkspaceId,
      switchSequence:
        this.switchSequence,
    });
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot():
    WorkspaceSwitchingSnapshot {
    return {
      activeContext: this.getActiveContext(),
    };
  }

  /* ===========================================================================
   * INTERNAL AUTHORITY VALIDATION
   * ===========================================================================
   */

  private requireWorkspace(
    workspaceId: WorkspaceId,
  ): void {
    if (
      !this.workspaceCoordinator.hasWorkspace(
        workspaceId,
      )
    ) {
      throw new Error(
        unknownWorkspaceMessage(workspaceId),
      );
    }
  }
}
