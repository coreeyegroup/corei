/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM SWITCHING
 * =============================================================================
 *
 * Public workspace-switching coordination surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  WorkspaceSwitchingCoordinator,
} from "./workspace-switching-coordinator";
