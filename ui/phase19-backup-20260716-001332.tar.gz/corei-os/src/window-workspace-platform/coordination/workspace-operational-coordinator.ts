/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   workspace-operational-coordinator.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-03 — Workspace Operational Coordination
 *
 * Purpose:
 *   Provides deterministic in-memory operational coordination for workspace
 *   references known to the Phase-19 platform boundary.
 *
 * Ownership:
 *   - Owns Phase-19 coordination state only.
 *   - Does not own the underlying workspace runtime.
 *   - Does not load or render workspaces.
 *   - Does not persist workspace state.
 *   - Does not publish events.
 *   - Does not integrate Dockview.
 *
 * =============================================================================
 */

import type {
  WorkspaceOperationalCoordinatorContract,
  WorkspaceOperationalSnapshot,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  WorkspaceId,
  WorkspaceLifecycleState,
  WorkspaceReference,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateWorkspaceMessage = (workspaceId: WorkspaceId): string =>
  `Workspace is already registered: ${workspaceId}`;

const unknownWorkspaceMessage = (workspaceId: WorkspaceId): string =>
  `Workspace is not registered: ${workspaceId}`;

/* =============================================================================
 * SECTION 02 — INTERNAL SNAPSHOT HELPERS
 * =============================================================================
 */

const copyWorkspaceReference = (
  workspace: WorkspaceReference,
): WorkspaceReference => ({
  workspaceId: workspace.workspaceId,
  lifecycleState: workspace.lifecycleState,
});

/* =============================================================================
 * SECTION 03 — WORKSPACE OPERATIONAL COORDINATOR
 * =============================================================================
 */

export class WorkspaceOperationalCoordinator
  implements WorkspaceOperationalCoordinatorContract
{
  private readonly workspaces = new Map<WorkspaceId, WorkspaceReference>();

  private activeWorkspaceId: WorkspaceId | null = null;

  /* ===========================================================================
   * REGISTRATION
   * ===========================================================================
   */

  public registerWorkspace(workspace: WorkspaceReference): void {
    if (this.workspaces.has(workspace.workspaceId)) {
      throw new Error(duplicateWorkspaceMessage(workspace.workspaceId));
    }

    this.workspaces.set(
      workspace.workspaceId,
      copyWorkspaceReference(workspace),
    );
  }

  public unregisterWorkspace(workspaceId: WorkspaceId): void {
    this.requireWorkspace(workspaceId);

    this.workspaces.delete(workspaceId);

    if (this.activeWorkspaceId === workspaceId) {
      this.activeWorkspaceId = null;
    }
  }

  /* ===========================================================================
   * LOOKUP
   * ===========================================================================
   */

  public hasWorkspace(workspaceId: WorkspaceId): boolean {
    return this.workspaces.has(workspaceId);
  }

  public getWorkspace(workspaceId: WorkspaceId): WorkspaceReference | null {
    const workspace = this.workspaces.get(workspaceId);

    return workspace === undefined
      ? null
      : copyWorkspaceReference(workspace);
  }

  public getWorkspaces(): readonly WorkspaceReference[] {
    return Array.from(
      this.workspaces.values(),
      copyWorkspaceReference,
    );
  }

  /* ===========================================================================
   * LIFECYCLE COORDINATION
   * ===========================================================================
   */

  public setWorkspaceLifecycleState(
    workspaceId: WorkspaceId,
    lifecycleState: WorkspaceLifecycleState,
  ): void {
    const workspace = this.requireWorkspace(workspaceId);

    this.workspaces.set(workspaceId, {
      workspaceId: workspace.workspaceId,
      lifecycleState,
    });
  }

  /* ===========================================================================
   * ACTIVE WORKSPACE COORDINATION
   * ===========================================================================
   */

  public setActiveWorkspace(workspaceId: WorkspaceId): void {
    this.requireWorkspace(workspaceId);
    this.activeWorkspaceId = workspaceId;
  }

  public clearActiveWorkspace(): void {
    this.activeWorkspaceId = null;
  }

  public getActiveWorkspaceId(): WorkspaceId | null {
    return this.activeWorkspaceId;
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): WorkspaceOperationalSnapshot {
    return {
      activeWorkspaceId: this.activeWorkspaceId,
      workspaces: this.getWorkspaces(),
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireWorkspace(workspaceId: WorkspaceId): WorkspaceReference {
    const workspace = this.workspaces.get(workspaceId);

    if (workspace === undefined) {
      throw new Error(unknownWorkspaceMessage(workspaceId));
    }

    return workspace;
  }
}
