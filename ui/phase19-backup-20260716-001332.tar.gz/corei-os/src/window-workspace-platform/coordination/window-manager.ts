/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   window-manager.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-04 — Window Management Platform
 *
 * Purpose:
 *   Provides deterministic in-memory operational management for logical window
 *   references known to the Phase-19 platform boundary.
 *
 * Ownership:
 *   - Owns Phase-19 logical window coordination state.
 *   - Consults workspace coordination for workspace identity validity.
 *   - Does not own the workspace registry.
 *   - Does not create browser windows.
 *   - Does not render UI.
 *   - Does not integrate Dockview.
 *   - Does not persist window state.
 *   - Does not publish events.
 *
 * =============================================================================
 */

import type {
  WindowManagementContract,
  WindowManagementSnapshot,
} from "../contracts/window-management.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  WindowId,
  WindowLifecycleState,
  WindowReference,
  WorkspaceId,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateWindowMessage = (windowId: WindowId): string =>
  `Window is already registered: ${windowId}`;

const unknownWindowMessage = (windowId: WindowId): string =>
  `Window is not registered: ${windowId}`;

const unknownWorkspaceMessage = (workspaceId: WorkspaceId): string =>
  `Workspace is not registered: ${workspaceId}`;

/* =============================================================================
 * SECTION 02 — INTERNAL SNAPSHOT HELPERS
 * =============================================================================
 */

const copyWindowReference = (
  window: WindowReference,
): WindowReference => ({
  windowId: window.windowId,
  workspaceId: window.workspaceId,
  lifecycleState: window.lifecycleState,
});

/* =============================================================================
 * SECTION 03 — WINDOW MANAGER
 * =============================================================================
 */

export class WindowManager implements WindowManagementContract {
  private readonly windows = new Map<WindowId, WindowReference>();

  private activeWindowId: WindowId | null = null;

  public constructor(
    private readonly workspaceCoordinator:
      WorkspaceOperationalCoordinatorContract,
  ) {}

  /* ===========================================================================
   * REGISTRATION
   * ===========================================================================
   */

  public registerWindow(window: WindowReference): void {
    if (this.windows.has(window.windowId)) {
      throw new Error(duplicateWindowMessage(window.windowId));
    }

    if (window.workspaceId !== null) {
      this.requireWorkspace(window.workspaceId);
    }

    this.windows.set(
      window.windowId,
      copyWindowReference(window),
    );
  }

  public unregisterWindow(windowId: WindowId): void {
    this.requireWindow(windowId);

    this.windows.delete(windowId);

    if (this.activeWindowId === windowId) {
      this.activeWindowId = null;
    }
  }

  /* ===========================================================================
   * LOOKUP
   * ===========================================================================
   */

  public hasWindow(windowId: WindowId): boolean {
    return this.windows.has(windowId);
  }

  public getWindow(windowId: WindowId): WindowReference | null {
    const window = this.windows.get(windowId);

    return window === undefined
      ? null
      : copyWindowReference(window);
  }

  public getWindows(): readonly WindowReference[] {
    return Array.from(
      this.windows.values(),
      copyWindowReference,
    );
  }

  /* ===========================================================================
   * LIFECYCLE COORDINATION
   * ===========================================================================
   */

  public setWindowLifecycleState(
    windowId: WindowId,
    lifecycleState: WindowLifecycleState,
  ): void {
    const window = this.requireWindow(windowId);

    this.windows.set(windowId, {
      windowId: window.windowId,
      workspaceId: window.workspaceId,
      lifecycleState,
    });
  }

  /* ===========================================================================
   * WORKSPACE ASSOCIATION
   * ===========================================================================
   */

  public assignWindowToWorkspace(
    windowId: WindowId,
    workspaceId: WorkspaceId,
  ): void {
    const window = this.requireWindow(windowId);

    this.requireWorkspace(workspaceId);

    this.windows.set(windowId, {
      windowId: window.windowId,
      workspaceId,
      lifecycleState: window.lifecycleState,
    });
  }

  public detachWindowFromWorkspace(windowId: WindowId): void {
    const window = this.requireWindow(windowId);

    this.windows.set(windowId, {
      windowId: window.windowId,
      workspaceId: null,
      lifecycleState: window.lifecycleState,
    });
  }

  /* ===========================================================================
   * ACTIVE WINDOW COORDINATION
   * ===========================================================================
   */

  public setActiveWindow(windowId: WindowId): void {
    this.requireWindow(windowId);
    this.activeWindowId = windowId;
  }

  public clearActiveWindow(): void {
    this.activeWindowId = null;
  }

  public getActiveWindowId(): WindowId | null {
    return this.activeWindowId;
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): WindowManagementSnapshot {
    return {
      activeWindowId: this.activeWindowId,
      windows: this.getWindows(),
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireWindow(windowId: WindowId): WindowReference {
    const window = this.windows.get(windowId);

    if (window === undefined) {
      throw new Error(unknownWindowMessage(windowId));
    }

    return window;
  }

  private requireWorkspace(workspaceId: WorkspaceId): void {
    if (!this.workspaceCoordinator.hasWorkspace(workspaceId)) {
      throw new Error(unknownWorkspaceMessage(workspaceId));
    }
  }
}
