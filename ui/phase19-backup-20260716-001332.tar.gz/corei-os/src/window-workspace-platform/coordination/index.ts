/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM COORDINATION
 * =============================================================================
 *
 * Public coordination surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  WorkspaceOperationalCoordinator,
} from "./workspace-operational-coordinator";

export {
  WindowManager,
} from "./window-manager";
