/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM FLOATING MANAGEMENT
 * =============================================================================
 *
 * Public floating-window management surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  FloatingWindowManager,
} from "./floating-window-manager";
