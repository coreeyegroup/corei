/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   floating-window-manager.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-08 — Floating Window Management
 *
 * Purpose:
 *   Provides deterministic provider-neutral logical floating-window management.
 *
 * Ownership:
 *   - Owns floating-window registration and lifecycle.
 *   - Owns floating bounds.
 *   - Owns active and focused floating identities.
 *   - Preserves workspace, layout, item, runtime-context, and restoration state.
 *   - Consults Step-04 Window Management as window authority.
 *   - Consults Step-06 Layout Runtime as layout authority.
 *   - Consults Step-07 Layout Composition Runtime as composition authority.
 *   - Does not open browser windows.
 *   - Does not execute Dockview APIs.
 *   - Does not render UI.
 *   - Does not persist state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  FloatWindowRequest,
  FloatingWindowManagementContract,
  FloatingWindowManagementSnapshot,
} from "../contracts/floating-window-management.contract";

import type {
  LayoutRuntimeContract,
} from "../contracts/layout-runtime.contract";

import type {
  LayoutCompositionContract,
} from "../contracts/layout-composition.contract";

import type {
  WindowManagementContract,
} from "../contracts/window-management.contract";

import type {
  FloatingWindowBounds,
  FloatingWindowId,
  FloatingWindowLifecycleState,
  FloatingWindowReference,
  LayoutGroupId,
  LayoutItemId,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const duplicateFloatingWindowMessage = (
  floatingWindowId: FloatingWindowId,
): string =>
  `Floating window is already registered: ${floatingWindowId}`;

const duplicateFloatingItemMessage = (
  itemId: LayoutItemId,
): string =>
  `Layout item is already floating: ${itemId}`;

const unknownFloatingWindowMessage = (
  floatingWindowId: FloatingWindowId,
): string =>
  `Floating window is not registered: ${floatingWindowId}`;

const invalidBoundsMessage = (): string =>
  "Floating window bounds must be finite and dimensions must be greater than zero";

const invalidSourceIndexMessage = (
  sourceIndex: number,
): string =>
  `Floating window source index must be a non-negative integer: ${sourceIndex}`;

const ownershipMismatchMessage = (
  subject: string,
): string =>
  `Floating window ownership mismatch: ${subject}`;

const closedStateRequiredMessage = (
  floatingWindowId: FloatingWindowId,
): string =>
  `Floating window must be closed before restore: ${floatingWindowId}`;

const closedOperationMessage = (
  floatingWindowId: FloatingWindowId,
): string =>
  `Floating window is closed: ${floatingWindowId}`;

/* =============================================================================
 * SECTION 02 — COPY HELPERS
 * =============================================================================
 */

const copyBounds = (
  bounds: FloatingWindowBounds,
): FloatingWindowBounds => ({
  x: bounds.x,
  y: bounds.y,
  width: bounds.width,
  height: bounds.height,
});

const copyFloatingWindowReference = (
  reference: FloatingWindowReference,
): FloatingWindowReference => ({
  floatingWindowId: reference.floatingWindowId,
  windowId: reference.windowId,
  workspaceId: reference.workspaceId,
  layoutId: reference.layoutId,
  itemId: reference.itemId,
  sourceGroupId: reference.sourceGroupId,
  lifecycleState: reference.lifecycleState,
  bounds: copyBounds(reference.bounds),
  runtimeContextId: reference.runtimeContextId,
  restorationMetadata: {
    sourceGroupId: reference.restorationMetadata.sourceGroupId,
    sourceIndex: reference.restorationMetadata.sourceIndex,
  },
});

/* =============================================================================
 * SECTION 03 — FLOATING WINDOW MANAGER
 * =============================================================================
 */

export class FloatingWindowManager
  implements FloatingWindowManagementContract
{
  private readonly floatingWindows =
    new Map<FloatingWindowId, FloatingWindowReference>();

  private readonly floatingWindowByItem =
    new Map<LayoutItemId, FloatingWindowId>();

  private activeFloatingWindowId:
    FloatingWindowId | null = null;

  private focusedFloatingWindowId:
    FloatingWindowId | null = null;

  public constructor(
    private readonly windowManager: WindowManagementContract,
    private readonly layoutRuntime: LayoutRuntimeContract,
    private readonly layoutComposition: LayoutCompositionContract,
  ) {}

  /* ===========================================================================
   * FLOAT / REATTACH
   * ===========================================================================
   */

  public float(request: FloatWindowRequest): void {
    if (
      this.floatingWindows.has(request.floatingWindowId)
    ) {
      throw new Error(
        duplicateFloatingWindowMessage(
          request.floatingWindowId,
        ),
      );
    }

    if (this.floatingWindowByItem.has(request.itemId)) {
      throw new Error(
        duplicateFloatingItemMessage(request.itemId),
      );
    }

    this.validateBounds(request.bounds);
    this.validateSourceIndex(
      request.restorationMetadata.sourceIndex,
    );

    const windowReference =
      this.windowManager.getWindow(request.windowId);

    if (windowReference === null) {
      throw new Error(
        ownershipMismatchMessage(
          `unknown window ${request.windowId}`,
        ),
      );
    }

    if (
      windowReference.workspaceId !== request.workspaceId
    ) {
      throw new Error(
        ownershipMismatchMessage(
          `window ${request.windowId} does not belong to workspace ${request.workspaceId}`,
        ),
      );
    }

    const layoutReference =
      this.layoutRuntime.getLayout(request.layoutId);

    if (layoutReference === null) {
      throw new Error(
        ownershipMismatchMessage(
          `unknown layout ${request.layoutId}`,
        ),
      );
    }

    if (
      layoutReference.workspaceId !== request.workspaceId
    ) {
      throw new Error(
        ownershipMismatchMessage(
          `layout ${request.layoutId} does not belong to workspace ${request.workspaceId}`,
        ),
      );
    }

    const itemReference =
      this.layoutComposition.getItem(request.itemId);

    if (itemReference === null) {
      throw new Error(
        ownershipMismatchMessage(
          `unknown item ${request.itemId}`,
        ),
      );
    }

    if (itemReference.layoutId !== request.layoutId) {
      throw new Error(
        ownershipMismatchMessage(
          `item ${request.itemId} does not belong to layout ${request.layoutId}`,
        ),
      );
    }

    if (itemReference.groupId !== request.sourceGroupId) {
      throw new Error(
        ownershipMismatchMessage(
          `item ${request.itemId} does not belong to source group ${request.sourceGroupId}`,
        ),
      );
    }

    if (
      request.restorationMetadata.sourceGroupId !==
      request.sourceGroupId
    ) {
      throw new Error(
        ownershipMismatchMessage(
          "restoration source group does not match source group",
        ),
      );
    }

    const sourceGroup =
      this.layoutComposition.getGroup(
        request.sourceGroupId,
      );

    if (
      sourceGroup === null ||
      sourceGroup.layoutId !== request.layoutId
    ) {
      throw new Error(
        ownershipMismatchMessage(
          `source group ${request.sourceGroupId} does not belong to layout ${request.layoutId}`,
        ),
      );
    }

    this.layoutComposition.unregisterItem(
      request.itemId,
    );

    const reference: FloatingWindowReference = {
      floatingWindowId: request.floatingWindowId,
      windowId: request.windowId,
      workspaceId: request.workspaceId,
      layoutId: request.layoutId,
      itemId: request.itemId,
      sourceGroupId: request.sourceGroupId,
      lifecycleState: "floating",
      bounds: copyBounds(request.bounds),
      runtimeContextId: request.runtimeContextId,
      restorationMetadata: {
        sourceGroupId:
          request.restorationMetadata.sourceGroupId,
        sourceIndex:
          request.restorationMetadata.sourceIndex,
      },
    };

    this.floatingWindows.set(
      reference.floatingWindowId,
      reference,
    );

    this.floatingWindowByItem.set(
      reference.itemId,
      reference.floatingWindowId,
    );
  }

  public reattach(
    floatingWindowId: FloatingWindowId,
    targetGroupId?: LayoutGroupId,
    targetIndex?: number,
  ): void {
    const reference =
      this.requireFloatingWindow(floatingWindowId);

    const resolvedGroupId =
      targetGroupId ??
      reference.restorationMetadata.sourceGroupId;

    const group =
      this.layoutComposition.getGroup(resolvedGroupId);

    if (
      group === null ||
      group.layoutId !== reference.layoutId
    ) {
      throw new Error(
        ownershipMismatchMessage(
          `target group ${resolvedGroupId} does not belong to layout ${reference.layoutId}`,
        ),
      );
    }

    const resolvedIndex =
      targetIndex ??
      reference.restorationMetadata.sourceIndex;

    this.validateSourceIndex(resolvedIndex);

    this.layoutComposition.registerItem({
      itemId: reference.itemId,
      layoutId: reference.layoutId,
      groupId: resolvedGroupId,
    });

    this.layoutComposition.reorderItem(
      resolvedGroupId,
      reference.itemId,
      resolvedIndex,
    );

    this.removeFloatingWindow(reference);
  }

  /* ===========================================================================
   * GEOMETRY
   * ===========================================================================
   */

  public move(
    floatingWindowId: FloatingWindowId,
    x: number,
    y: number,
  ): void {
    const reference =
      this.requireOpenFloatingWindow(floatingWindowId);

    const bounds: FloatingWindowBounds = {
      ...reference.bounds,
      x,
      y,
    };

    this.validateBounds(bounds);

    this.replaceFloatingWindow(reference, {
      bounds,
    });
  }

  public resize(
    floatingWindowId: FloatingWindowId,
    width: number,
    height: number,
  ): void {
    const reference =
      this.requireOpenFloatingWindow(floatingWindowId);

    const bounds: FloatingWindowBounds = {
      ...reference.bounds,
      width,
      height,
    };

    this.validateBounds(bounds);

    this.replaceFloatingWindow(reference, {
      bounds,
    });
  }

  /* ===========================================================================
   * OPERATIONAL STATE
   * ===========================================================================
   */

  public activate(
    floatingWindowId: FloatingWindowId,
  ): void {
    const reference =
      this.requireOpenFloatingWindow(floatingWindowId);

    this.clearActiveStateExcept(floatingWindowId);

    this.activeFloatingWindowId = floatingWindowId;

    this.replaceFloatingWindow(reference, {
      lifecycleState: "active",
    });
  }

  public focus(
    floatingWindowId: FloatingWindowId,
  ): void {
    const reference =
      this.requireOpenFloatingWindow(floatingWindowId);

    this.clearFocusStateExcept(floatingWindowId);
    this.clearActiveStateExcept(floatingWindowId);

    this.activeFloatingWindowId = floatingWindowId;
    this.focusedFloatingWindowId = floatingWindowId;

    this.replaceFloatingWindow(reference, {
      lifecycleState: "focused",
    });
  }

  public close(
    floatingWindowId: FloatingWindowId,
  ): void {
    const reference =
      this.requireFloatingWindow(floatingWindowId);

    if (
      this.activeFloatingWindowId === floatingWindowId
    ) {
      this.activeFloatingWindowId = null;
    }

    if (
      this.focusedFloatingWindowId === floatingWindowId
    ) {
      this.focusedFloatingWindowId = null;
    }

    this.replaceFloatingWindow(reference, {
      lifecycleState: "closed",
    });
  }

  public restore(
    floatingWindowId: FloatingWindowId,
  ): void {
    const reference =
      this.requireFloatingWindow(floatingWindowId);

    if (reference.lifecycleState !== "closed") {
      throw new Error(
        closedStateRequiredMessage(floatingWindowId),
      );
    }

    this.replaceFloatingWindow(reference, {
      lifecycleState: "floating",
    });
  }

  /* ===========================================================================
   * LOOKUP / SNAPSHOT
   * ===========================================================================
   */

  public hasFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): boolean {
    return this.floatingWindows.has(floatingWindowId);
  }

  public getFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): FloatingWindowReference | null {
    const reference =
      this.floatingWindows.get(floatingWindowId);

    return reference === undefined
      ? null
      : copyFloatingWindowReference(reference);
  }

  public getFloatingWindowForItem(
    itemId: LayoutItemId,
  ): FloatingWindowReference | null {
    const floatingWindowId =
      this.floatingWindowByItem.get(itemId);

    if (floatingWindowId === undefined) {
      return null;
    }

    return this.getFloatingWindow(floatingWindowId);
  }

  public getSnapshot():
    FloatingWindowManagementSnapshot {
    return {
      floatingWindows: Array.from(
        this.floatingWindows.values(),
        copyFloatingWindowReference,
      ),
      activeFloatingWindowId:
        this.activeFloatingWindowId,
      focusedFloatingWindowId:
        this.focusedFloatingWindowId,
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): FloatingWindowReference {
    const reference =
      this.floatingWindows.get(floatingWindowId);

    if (reference === undefined) {
      throw new Error(
        unknownFloatingWindowMessage(floatingWindowId),
      );
    }

    return reference;
  }

  private requireOpenFloatingWindow(
    floatingWindowId: FloatingWindowId,
  ): FloatingWindowReference {
    const reference =
      this.requireFloatingWindow(floatingWindowId);

    if (reference.lifecycleState === "closed") {
      throw new Error(
        closedOperationMessage(floatingWindowId),
      );
    }

    return reference;
  }

  private validateBounds(
    bounds: FloatingWindowBounds,
  ): void {
    const values = [
      bounds.x,
      bounds.y,
      bounds.width,
      bounds.height,
    ];

    if (
      values.some((value) => !Number.isFinite(value)) ||
      bounds.width <= 0 ||
      bounds.height <= 0
    ) {
      throw new Error(invalidBoundsMessage());
    }
  }

  private validateSourceIndex(
    sourceIndex: number,
  ): void {
    if (
      !Number.isInteger(sourceIndex) ||
      sourceIndex < 0
    ) {
      throw new Error(
        invalidSourceIndexMessage(sourceIndex),
      );
    }
  }

  private replaceFloatingWindow(
    reference: FloatingWindowReference,
    changes: {
      readonly lifecycleState?:
        FloatingWindowLifecycleState;
      readonly bounds?: FloatingWindowBounds;
    },
  ): void {
    this.floatingWindows.set(
      reference.floatingWindowId,
      {
        ...reference,
        lifecycleState:
          changes.lifecycleState ??
          reference.lifecycleState,
        bounds:
          changes.bounds === undefined
            ? copyBounds(reference.bounds)
            : copyBounds(changes.bounds),
      },
    );
  }

  private removeFloatingWindow(
    reference: FloatingWindowReference,
  ): void {
    this.floatingWindows.delete(
      reference.floatingWindowId,
    );

    this.floatingWindowByItem.delete(
      reference.itemId,
    );

    if (
      this.activeFloatingWindowId ===
      reference.floatingWindowId
    ) {
      this.activeFloatingWindowId = null;
    }

    if (
      this.focusedFloatingWindowId ===
      reference.floatingWindowId
    ) {
      this.focusedFloatingWindowId = null;
    }
  }

  private clearActiveStateExcept(
    floatingWindowId: FloatingWindowId,
  ): void {
    const currentId = this.activeFloatingWindowId;

    if (
      currentId === null ||
      currentId === floatingWindowId
    ) {
      return;
    }

    const current =
      this.floatingWindows.get(currentId);

    if (
      current !== undefined &&
      current.lifecycleState !== "closed"
    ) {
      this.replaceFloatingWindow(current, {
        lifecycleState: "floating",
      });
    }

    this.activeFloatingWindowId = null;

    if (this.focusedFloatingWindowId === currentId) {
      this.focusedFloatingWindowId = null;
    }
  }

  private clearFocusStateExcept(
    floatingWindowId: FloatingWindowId,
  ): void {
    const currentId = this.focusedFloatingWindowId;

    if (
      currentId === null ||
      currentId === floatingWindowId
    ) {
      return;
    }

    const current =
      this.floatingWindows.get(currentId);

    if (
      current !== undefined &&
      current.lifecycleState === "focused"
    ) {
      this.replaceFloatingWindow(current, {
        lifecycleState:
          this.activeFloatingWindowId === currentId
            ? "active"
            : "floating",
      });
    }

    this.focusedFloatingWindowId = null;
  }
}
