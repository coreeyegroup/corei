/**
 * =============================================================================
 * COREI — WINDOW & WORKSPACE PLATFORM INTEGRATION
 * =============================================================================
 *
 * Public integration surface for Stage-25 Phase-19.
 *
 * =============================================================================
 */

export {
  DockviewRuntimeIntegration,
} from "./dockview-runtime-integration";
