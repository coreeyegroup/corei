/**
 * =============================================================================
 * COREI — INSTITUTIONAL ALGORITHMIC TRADING PLATFORM
 * =============================================================================
 *
 * File:
 *   dockview-runtime-integration.ts
 *
 * Stage:
 *   Stage-25 — Platform Enablement
 *
 * Phase:
 *   Phase-19 — Window & Workspace Platform
 *
 * Step:
 *   Step-05 — Dockview Runtime Integration
 *
 * Purpose:
 *   Coordinates the Phase-19 logical workspace and window authorities with an
 *   attached adapter representing the existing Dockview runtime boundary.
 *
 * Ownership:
 *   - Owns runtime attachment state only.
 *   - Does not own workspace state.
 *   - Does not own window state.
 *   - Does not directly import Dockview.
 *   - Does not render UI.
 *   - Does not own layout geometry.
 *   - Does not persist runtime state.
 *
 * Browser Visibility:
 *   No intentional visual change is introduced by this implementation.
 *
 * =============================================================================
 */

import type {
  DockviewRuntimeAdapterContract,
  DockviewRuntimeIntegrationContract,
  DockviewRuntimeIntegrationSnapshot,
} from "../contracts/dockview-runtime-integration.contract";

import type {
  WindowManagementContract,
} from "../contracts/window-management.contract";

import type {
  WorkspaceOperationalCoordinatorContract,
} from "../contracts/workspace-operational-coordinator.contract";

import type {
  WindowId,
  WorkspaceId,
} from "../contracts/window-workspace-platform.types";

/* =============================================================================
 * SECTION 01 — ERROR MESSAGES
 * =============================================================================
 */

const runtimeAlreadyAttachedMessage =
  "Dockview runtime adapter is already attached.";

const runtimeNotAttachedMessage =
  "Dockview runtime adapter is not attached.";

const runtimeNotReadyMessage =
  "Dockview runtime adapter is not ready.";

const unknownWorkspaceMessage = (workspaceId: WorkspaceId): string =>
  `Workspace is not registered: ${workspaceId}`;

const unknownWindowMessage = (windowId: WindowId): string =>
  `Window is not registered: ${windowId}`;

/* =============================================================================
 * SECTION 02 — DOCKVIEW RUNTIME INTEGRATION
 * =============================================================================
 */

export class DockviewRuntimeIntegration
  implements DockviewRuntimeIntegrationContract
{
  private runtimeAdapter: DockviewRuntimeAdapterContract | null = null;

  public constructor(
    private readonly workspaceCoordinator:
      WorkspaceOperationalCoordinatorContract,
    private readonly windowManager:
      WindowManagementContract,
  ) {}

  /* ===========================================================================
   * RUNTIME ATTACHMENT
   * ===========================================================================
   */

  public attachRuntime(adapter: DockviewRuntimeAdapterContract): void {
    if (this.runtimeAdapter !== null) {
      throw new Error(runtimeAlreadyAttachedMessage);
    }

    this.runtimeAdapter = adapter;
  }

  public detachRuntime(): void {
    this.runtimeAdapter = null;
  }

  public isAttached(): boolean {
    return this.runtimeAdapter !== null;
  }

  public isReady(): boolean {
    return this.runtimeAdapter?.isReady() ?? false;
  }

  /* ===========================================================================
   * WORKSPACE SYNCHRONIZATION
   * ===========================================================================
   */

  public synchronizeWorkspace(workspaceId: WorkspaceId): void {
    const runtime = this.requireReadyRuntime();
    const workspace = this.workspaceCoordinator.getWorkspace(workspaceId);

    if (workspace === null) {
      throw new Error(unknownWorkspaceMessage(workspaceId));
    }

    runtime.synchronizeWorkspace(workspace);
  }

  public removeWorkspace(workspaceId: WorkspaceId): void {
    const runtime = this.requireReadyRuntime();

    if (!this.workspaceCoordinator.hasWorkspace(workspaceId)) {
      throw new Error(unknownWorkspaceMessage(workspaceId));
    }

    runtime.removeWorkspace(workspaceId);
  }

  /* ===========================================================================
   * WINDOW SYNCHRONIZATION
   * ===========================================================================
   */

  public synchronizeWindow(windowId: WindowId): void {
    const runtime = this.requireReadyRuntime();
    const window = this.windowManager.getWindow(windowId);

    if (window === null) {
      throw new Error(unknownWindowMessage(windowId));
    }

    runtime.synchronizeWindow(window);
  }

  public removeWindow(windowId: WindowId): void {
    const runtime = this.requireReadyRuntime();

    if (!this.windowManager.hasWindow(windowId)) {
      throw new Error(unknownWindowMessage(windowId));
    }

    runtime.removeWindow(windowId);
  }

  /* ===========================================================================
   * SNAPSHOT
   * ===========================================================================
   */

  public getSnapshot(): DockviewRuntimeIntegrationSnapshot {
    return {
      attached: this.isAttached(),
      ready: this.isReady(),
    };
  }

  /* ===========================================================================
   * INTERNAL INVARIANT ENFORCEMENT
   * ===========================================================================
   */

  private requireReadyRuntime(): DockviewRuntimeAdapterContract {
    if (this.runtimeAdapter === null) {
      throw new Error(runtimeNotAttachedMessage);
    }

    if (!this.runtimeAdapter.isReady()) {
      throw new Error(runtimeNotReadyMessage);
    }

    return this.runtimeAdapter;
  }
}
