/**
 * =============================================================================
 * COREI OPERATING SYSTEM
 *
 * Stage       : 25
 * Phase       : 06
 * Step        : 01
 *
 * File        : workspace-manager.ts
 * Purpose     : Workspace Manager
 * =============================================================================
 */

import type { WorkspaceModel } from "../models/workspace";
import { WorkspaceRegistry } from "../registry/workspace-registry";

export class WorkspaceManager {

    public register(
        workspace: WorkspaceModel
    ): void {

        (WorkspaceRegistry as WorkspaceModel[]).push(workspace);

    }

    public getAll(): readonly WorkspaceModel[] {

        return WorkspaceRegistry;

    }

}
