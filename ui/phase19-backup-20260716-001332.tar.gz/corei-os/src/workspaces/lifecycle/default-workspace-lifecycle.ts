/**
 * =============================================================================
 * COREI OPERATING SYSTEM
 *
 * Stage       : 25
 * Phase       : 06
 * Step        : 02
 *
 * File        : default-workspace-lifecycle.ts
 * Purpose     : Default Workspace Lifecycle
 * =============================================================================
 */

import type { WorkspaceLifecycle } from "./workspace-lifecycle";

export const DefaultWorkspaceLifecycle: WorkspaceLifecycle = {

    initialize(): void {},

    activate(): void {},

    deactivate(): void {},

    suspend(): void {},

    resume(): void {},

    dispose(): void {}

};
