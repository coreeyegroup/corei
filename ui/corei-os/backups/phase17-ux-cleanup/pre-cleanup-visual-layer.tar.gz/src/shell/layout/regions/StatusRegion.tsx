import { StatusBar } from "../../../workbench/status-bar/StatusBar";


export function StatusRegion(): React.JSX.Element {

    return (

        <footer
            className="corei-region corei-region-status"
        >

            <div className="corei-region-surface">

                <StatusBar />

            </div>

        </footer>

    );

}


export default StatusRegion;
