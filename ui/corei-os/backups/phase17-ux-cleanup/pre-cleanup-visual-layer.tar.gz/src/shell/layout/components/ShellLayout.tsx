import "../styles/shell-layout.css";

import {
    TopRegion,
    LeftRegion,
    CenterRegion,
    RightRegion,
    BottomRegion,
    StatusRegion,
} from "../regions";

export function ShellLayout() {
    return (
        <div className="corei-shell-layout">

            <div className="shell-top">
                <TopRegion />
            </div>

            <div className="shell-left">
                <LeftRegion />
            </div>

            <div className="shell-center">
                <CenterRegion />
            </div>

            <div className="shell-right">
                <RightRegion />
            </div>

            <div className="shell-bottom">
                <BottomRegion />
            </div>

            <div className="shell-status">
                <StatusRegion />
            </div>

        </div>
    );
}

export default ShellLayout;
