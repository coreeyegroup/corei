import { WorkspaceHost } from "../../../workbench/components/WorkspaceHost";

export function CenterRegion() {
    return (
        <section className="corei-region corei-region-center">
            <div className="corei-region-surface">
                <WorkspaceHost />
            </div>
        </section>
    );
}

export default CenterRegion;
