import { IntelligenceRightPanel } from "../../../intelligence/right-panel/IntelligenceRightPanel";

export function RightRegion(): React.JSX.Element {

    return (

        <section className="corei-region corei-region-right">

            <div className="corei-region-surface">

                <IntelligenceRightPanel />

            </div>

        </section>

    );

}

export default RightRegion;
