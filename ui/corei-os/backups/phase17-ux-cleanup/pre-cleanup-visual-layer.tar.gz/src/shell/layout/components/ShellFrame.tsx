import "../styles/shell-viewport.css";
import "../styles/shell-geometry.css";
import "../styles/shell-frame.css";

import { ShellLayout } from "./ShellLayout";

export function ShellFrame() {
    return (
        <div className="corei-shell-frame">
            <ShellLayout />
        </div>
    );
}

export default ShellFrame;
