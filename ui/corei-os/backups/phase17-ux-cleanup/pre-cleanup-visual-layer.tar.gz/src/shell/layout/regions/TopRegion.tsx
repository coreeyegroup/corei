import { TopRibbon } from "../../../ribbon/components/TopRibbon";

export function TopRegion(): React.JSX.Element {

    return (

        <section className="corei-region corei-region-top">

            <div className="corei-region-surface">

                <TopRibbon />

            </div>

        </section>

    );

}

export default TopRegion;
