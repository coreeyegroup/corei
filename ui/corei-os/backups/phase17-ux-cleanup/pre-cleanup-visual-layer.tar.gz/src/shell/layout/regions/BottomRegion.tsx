import { BottomPanel } from "../../../workbench/bottom-panel/BottomPanel";


export function BottomRegion(): React.JSX.Element {

    return (

        <section
            className="corei-region corei-region-bottom"
        >

            <div className="corei-region-surface">

                <BottomPanel />

            </div>

        </section>

    );

}


export default BottomRegion;
