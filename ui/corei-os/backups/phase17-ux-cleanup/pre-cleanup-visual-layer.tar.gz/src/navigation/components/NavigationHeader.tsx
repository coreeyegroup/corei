/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-17
 *
 * FILE:
 * NavigationHeader.tsx
 *
 * PURPOSE:
 * Institutional Navigation Header
 *
 * OWNERSHIP:
 * Navigation Domain
 *
 ******************************************************************************/

import type {
    ReactElement
} from "react";

export interface NavigationHeaderProps {

    readonly eyebrow: string;

    readonly title: string;

    readonly description: string;

}

export function NavigationHeader({
    eyebrow,
    title,
    description
}: NavigationHeaderProps): ReactElement {

    return (

        <header
            className="corei-navigation-header"
            data-navigation-element="header"
        >

            <span className="corei-navigation-header__eyebrow">
                {eyebrow}
            </span>

            <div className="corei-navigation-header__identity">

                <span
                    className="corei-navigation-header__mark"
                    aria-hidden="true"
                >
                    C
                </span>

                <div className="corei-navigation-header__copy">

                    <strong className="corei-navigation-header__title">
                        {title}
                    </strong>

                    <span className="corei-navigation-header__description">
                        {description}
                    </span>

                </div>

            </div>

        </header>

    );

}

export default NavigationHeader;
