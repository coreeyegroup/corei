import type {

    PropsWithChildren

} from "react";

export function DockHost(

    props: PropsWithChildren

): React.JSX.Element {

    return <>{props.children}</>;

}
