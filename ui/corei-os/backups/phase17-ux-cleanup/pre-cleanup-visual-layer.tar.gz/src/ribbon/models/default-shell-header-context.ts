/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-15
 *
 * FILE:
 * default-shell-header-context.ts
 *
 * PURPOSE:
 * Deterministic default Shell header presentation context.
 *
 * IMPORTANT:
 * These values are explicit presentation defaults.
 * They are not inferred authentication, authorization, broker,
 * portfolio, account, strategy, or execution state.
 *
 ******************************************************************************/

import type {
    ShellHeaderContextContract
} from "../contracts/shell-header-context-contract";

export const DEFAULT_SHELL_HEADER_CONTEXT: ShellHeaderContextContract = {
    institution: {
        name: "COREI",
        product: "Operating System"
    },
    environment: {
        environment: "development",
        region: "LOCAL"
    },
    session: {
        sessionId: "LOCAL-SESSION",
        operatorLabel: "Operator"
    },
    operatingContext: {
        workspace: "Institutional Workspace",
        mode: "research",
        runtimeHealth: "operational"
    }
};
