/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-02
 *
 * FILE:
 * RibbonWorkspace.tsx
 *
 * PURPOSE:
 * Active Workspace Indicator
 *
 ******************************************************************************/

import type { ReactElement } from "react";

export function RibbonWorkspace(): ReactElement {

    return (

        <div className="corei-ribbon-workspace">

            Workspace

        </div>

    );

}

export default RibbonWorkspace;

