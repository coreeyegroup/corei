/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-02
 *
 * FILE:
 * TopRibbon.tsx
 *
 * PURPOSE:
 * Institutional Top Ribbon Composition
 *
 ******************************************************************************/

import type { ReactElement } from "react";

import "../styles/top-ribbon.css";

import RibbonBrand from "./RibbonBrand";
import RibbonWorkspace from "./RibbonWorkspace";
import RibbonSearch from "./RibbonSearch";
import RibbonRuntime from "./RibbonRuntime";
import RibbonNotifications from "./RibbonNotifications";
import RibbonClock from "./RibbonClock";
import RibbonUser from "./RibbonUser";

import {
    RibbonShellHeaderDetail
} from "./RibbonShellHeaderDetail";

import {
    RibbonMicroSurface
} from "./RibbonMicroSurface";

import {
    DEFAULT_SHELL_HEADER_CONTEXT
} from "../models/default-shell-header-context";

import {
    DEFAULT_RIBBON_MICRO_MODEL
} from "../models/default-ribbon-micro-model";

export function TopRibbon(): ReactElement {

    return (

        <header className="corei-top-ribbon">

            <RibbonBrand />

            <RibbonWorkspace />

            <RibbonSearch />

            <div className="corei-top-ribbon-spacer" />

            <RibbonRuntime />

            <RibbonNotifications />

            <RibbonClock />

            <RibbonUser />

            <RibbonShellHeaderDetail
                context={DEFAULT_SHELL_HEADER_CONTEXT}
            />

            <RibbonMicroSurface
                model={DEFAULT_RIBBON_MICRO_MODEL}
            />

        </header>

    );

}

export default TopRibbon;

