/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-02
 *
 * FILE:
 * RibbonNotifications.tsx
 *
 * PURPOSE:
 * Institutional Notification Center
 *
 ******************************************************************************/

import type { ReactElement } from "react";

export function RibbonNotifications(): ReactElement {

    return (

        <div className="corei-ribbon-notifications">

            Alerts

        </div>

    );

}

export default RibbonNotifications;

