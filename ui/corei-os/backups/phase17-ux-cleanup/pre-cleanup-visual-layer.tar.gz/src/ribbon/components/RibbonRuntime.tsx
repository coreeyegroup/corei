/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-02
 *
 * FILE:
 * RibbonRuntime.tsx
 *
 * PURPOSE:
 * Runtime Status Widget
 *
 ******************************************************************************/

import type { ReactElement } from "react";

export function RibbonRuntime(): ReactElement {

    return (

        <div className="corei-ribbon-runtime">

            Runtime

        </div>

    );

}

export default RibbonRuntime;

