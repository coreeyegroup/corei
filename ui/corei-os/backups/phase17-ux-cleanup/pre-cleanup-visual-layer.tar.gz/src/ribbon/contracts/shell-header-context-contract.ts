/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-15
 *
 * FILE:
 * shell-header-context-contract.ts
 *
 * PURPOSE:
 * Institutional Shell Header Context Contract
 *
 * OWNERSHIP:
 * Ribbon presentation boundary
 *
 * IMPORTANT:
 * This contract describes Shell header presentation context only.
 * It does not own authentication, authorization, tenant resolution,
 * environment discovery, session lifecycle, or platform runtime state.
 *
 ******************************************************************************/

export type ShellEnvironmentKind =
    | "development"
    | "staging"
    | "production";

export type ShellOperatingMode =
    | "research"
    | "simulation"
    | "paper"
    | "live";

export type ShellRuntimeHealth =
    | "operational"
    | "degraded"
    | "unavailable";

export interface ShellInstitutionIdentity {
    readonly name: string;
    readonly product: string;
}

export interface ShellEnvironmentIdentity {
    readonly environment: ShellEnvironmentKind;
    readonly region: string;
}

export interface ShellSessionContext {
    readonly sessionId: string;
    readonly operatorLabel: string;
}

export interface ShellOperatingContext {
    readonly workspace: string;
    readonly mode: ShellOperatingMode;
    readonly runtimeHealth: ShellRuntimeHealth;
}

export interface ShellHeaderContextContract {
    readonly institution: ShellInstitutionIdentity;
    readonly environment: ShellEnvironmentIdentity;
    readonly session: ShellSessionContext;
    readonly operatingContext: ShellOperatingContext;
}
