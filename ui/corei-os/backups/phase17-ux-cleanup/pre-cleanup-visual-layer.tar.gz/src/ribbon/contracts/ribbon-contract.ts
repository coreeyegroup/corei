/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-02
 *
 * FILE:
 * ribbon-contract.ts
 *
 * PURPOSE:
 * Institutional Top Ribbon Contract
 *
 ******************************************************************************/

export interface RibbonItemContract {

    readonly id: string;

    readonly title: string;

    readonly visible: boolean;

    readonly order: number;

}

export interface RibbonContract {

    readonly brand: RibbonItemContract;

    readonly workspace: RibbonItemContract;

    readonly search: RibbonItemContract;

    readonly runtime: RibbonItemContract;

    readonly notifications: RibbonItemContract;

    readonly clock: RibbonItemContract;

    readonly user: RibbonItemContract;

}

