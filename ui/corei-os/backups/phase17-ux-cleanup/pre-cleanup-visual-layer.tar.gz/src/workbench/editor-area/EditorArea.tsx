/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * EditorArea.tsx
 *
 * PURPOSE:
 * Institutional Workspace Canvas Surface
 *
 ******************************************************************************/

import { WorkbenchTabs } from "../tabs/components/WorkbenchTabs";


export function EditorArea(): React.JSX.Element {

    return (

        <section
            className="corei-editor-area"
            data-corei-surface="editor"
        >

            <WorkbenchTabs />

            <main
                className="corei-editor-canvas"
                data-corei-canvas="workspace"
            />

        </section>

    );

}


export default EditorArea;
