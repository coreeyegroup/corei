/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * WorkspaceHost.tsx
 *
 * PURPOSE:
 * Institutional Workspace Mount Boundary
 *
 ******************************************************************************/

import {
    useEffect
} from "react";

import {
    workbenchRuntime
} from "../runtime/workbench-runtime";

import {
    WindowHost
} from "../../windowing";

import {
    EditorArea
} from "../editor-area/EditorArea";


export function WorkspaceHost(): React.JSX.Element {


    useEffect(() => {

        workbenchRuntime.initialize();


        return () => {

            workbenchRuntime.dispose();

        };

    }, []);


    return (

        <section
            className="corei-workspace-host"
            data-corei-host="workspace"
        >

            <WindowHost>

                <EditorArea />

            </WindowHost>

        </section>

    );

}


export default WorkspaceHost;
