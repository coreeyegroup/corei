/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * Workbench.tsx
 *
 * PURPOSE:
 * Institutional Workspace Environment
 *
 ******************************************************************************/

import { WorkbenchCenter } from "./WorkbenchCenter";


export function Workbench(): React.JSX.Element {

    return (

        <main
            className="corei-workbench"
            data-corei-surface="workspace"
        >

            <WorkbenchCenter />

        </main>

    );

}


export default Workbench;
