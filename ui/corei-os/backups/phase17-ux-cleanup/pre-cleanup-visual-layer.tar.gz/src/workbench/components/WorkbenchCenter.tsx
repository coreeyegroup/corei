/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * WorkbenchCenter.tsx
 *
 ******************************************************************************/

import "../styles/workspace-foundation.css";

import {
    WorkspaceHost
} from "./WorkspaceHost";


export function WorkbenchCenter(): React.JSX.Element {

    return (

        <section
            className="corei-workspace-center"
        >

            <WorkspaceHost />

        </section>

    );

}


export default WorkbenchCenter;
