/**
 * ============================================================================
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * BottomPanel.tsx
 *
 * PURPOSE:
 * COREI Operational Bottom Surface
 * ============================================================================
 */

import "../styles/workspace-bottom.css";


export function BottomPanel(): React.JSX.Element {

    return (

        <section className="corei-bottom-panel">

            <div className="corei-bottom-panel-header">

                <span>
                    Operational Surface
                </span>

            </div>


            <div className="corei-bottom-panel-content">

            </div>


        </section>

    );

}


export default BottomPanel;
