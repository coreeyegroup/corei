/**
 * ============================================================================
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 *
 * FILE:
 * StatusBar.tsx
 *
 * PURPOSE:
 * COREI System Status Surface
 * ============================================================================
 */

import "../styles/workspace-status.css";


export function StatusBar(): React.JSX.Element {

    return (

        <footer className="corei-status-bar">

            <span>
                COREI OS
            </span>

            <span>
                Ready
            </span>

        </footer>

    );

}


export default StatusBar;
