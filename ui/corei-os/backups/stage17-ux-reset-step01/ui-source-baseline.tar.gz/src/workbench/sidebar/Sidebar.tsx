/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-03
 *
 * FILE
 * Sidebar.tsx
 *
 * PURPOSE
 * Runtime Driven Sidebar Container
 * ============================================================================
 */

import { Explorer } from "./Explorer";

import {

    useSidebarState

} from "./state/sidebar-state";

export function Sidebar(): React.JSX.Element {

    const visible =

        useSidebarState(

            state => state.visible

        );

    if (!visible) {

        return <></>;

    }

    return <Explorer />;

}
