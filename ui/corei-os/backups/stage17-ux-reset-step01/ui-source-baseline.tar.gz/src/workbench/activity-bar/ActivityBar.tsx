/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-01
 *
 * FILE
 * ActivityBar.tsx
 *
 * PURPOSE
 * Institutional Activity Bar
 *
 * RESPONSIBILITY
 * UI ONLY
 * Runtime owns behaviour.
 * ============================================================================
 */

import {

    ChartCandlestick,
    FolderTree,
    Server,
    Shield,
    Bot,
    Settings

} from "lucide-react";

import {

    useWorkbenchState,
    type ActivityType

} from "../state";

import {

    activityRuntime

} from "./runtime/activity-runtime";

interface ActivityItem {

    id: ActivityType;

    icon: React.ComponentType<{

        size?: number;

    }>;

}

const ITEMS: readonly ActivityItem[] = [

    {

        id: "trading",

        icon: ChartCandlestick

    },

    {

        id: "research",

        icon: FolderTree

    },

    {

        id: "infrastructure",

        icon: Server

    },

    {

        id: "risk",

        icon: Shield

    },

    {

        id: "ai",

        icon: Bot

    }

];

export function ActivityBar(): React.JSX.Element {

    const activity = useWorkbenchState(

        state => state.activity

    );

    return (

        <div

            style={{

                height: "100%",

                width: "100%",

                display: "flex",

                flexDirection: "column",

                justifyContent: "space-between",

                alignItems: "center",

                background: "#181818"

            }}

        >

            <div

                style={{

                    display: "flex",

                    flexDirection: "column",

                    gap: 8,

                    paddingTop: 10

                }}

            >

                {

                    ITEMS.map(item => {

                        const Icon = item.icon;

                        const active =

                            activity === item.id;

                        return (

                            <button

                                key={item.id}

                                type="button"

                                onClick={() =>

                                    activityRuntime.activate(

                                        item.id

                                    )

                                }

                                onMouseEnter={() =>

                                    activityRuntime.hover(

                                        item.id

                                    )

                                }

                                onMouseLeave={() =>

                                    activityRuntime.hover(

                                        null

                                    )

                                }

                                style={{

                                    width: 40,

                                    height: 40,

                                    border: 0,

                                    outline: "none",

                                    cursor: "pointer",

                                    transition:

                                        "all 120ms ease",

                                    background:

                                        active

                                            ? "#2d2d30"

                                            : "transparent",

                                    color:

                                        active

                                            ? "#ffffff"

                                            : "#8b8b8b",

                                    borderLeft:

                                        active

                                            ? "2px solid #007acc"

                                            : "2px solid transparent"

                                }}

                            >

                                <Icon

                                    size={18}

                                />

                            </button>

                        );

                    })

                }

            </div>

            <div

                style={{

                    paddingBottom: 10

                }}

            >

                <button

                    type="button"

                    style={{

                        width: 40,

                        height: 40,

                        border: 0,

                        background: "transparent",

                        color: "#8b8b8b",

                        cursor: "pointer"

                    }}

                >

                    <Settings

                        size={18}

                    />

                </button>

            </div>

        </div>

    );

}

