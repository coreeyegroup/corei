import "../styles/workspace-foundation.css";

export function WorkbenchCenter(): React.JSX.Element {

    return (

        <section className="corei-workspace-root">

        </section>

    );

}
