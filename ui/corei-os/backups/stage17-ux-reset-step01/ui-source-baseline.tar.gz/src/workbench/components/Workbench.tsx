/**
 * ============================================================================
 * STAGE-25
 * PHASE-19
 * STEP-UX-01
 *
 * FILE
 * Workbench.tsx
 *
 * PURPOSE
 * Institutional Workbench Shell
 * ============================================================================
 */

import { useEffect } from "react";

import { WorkbenchCenter } from "./WorkbenchCenter";
import { ActivityBar } from "../activity-bar/ActivityBar";
import { Sidebar } from "../sidebar/Sidebar";

import { workbenchRuntime } from "../runtime/workbench-runtime";

import { useSidebarState } from "../sidebar/state/sidebar-state";
import { useDockState } from "../docking/state";

export function Workbench(): React.JSX.Element {

    useEffect(() => {

        workbenchRuntime.initialize();

        return () => {

            workbenchRuntime.dispose();

        };

    }, []);

    const {

        visible

    } = useSidebarState();

    const {

        layout

    } = useDockState();

    return (

        <div

            className="corei-workbench-shell"

            data-shell="institutional"

            style={{

                gridTemplateColumns:

                    `52px ${visible ? layout.leftWidth : 0}px minmax(0,1fr) ${layout.rightWidth}px`,

                gridTemplateRows:

                    `40px minmax(0,1fr) ${layout.bottomHeight}px 28px`

            }}

        >

            <header className="corei-shell-ribbon">

                COREI TOP RIBBON

            </header>

            <aside className="corei-shell-activity">

                <ActivityBar />

            </aside>

            <aside className="corei-shell-sidebar">

                <Sidebar />

            </aside>

            <main className="corei-shell-center">

                <WorkbenchCenter />

            </main>

            <aside className="corei-shell-right">

            </aside>

            <section className="corei-shell-bottom">

            </section>

            <footer className="corei-shell-status">

                COREI STATUS BAR

            </footer>

        </div>

    );

}