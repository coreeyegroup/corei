/******************************************************************************
 *
 * COREI OPERATING SYSTEM
 *
 * STAGE-25
 * PHASE-17
 * STEP-18
 *
 * FILE:
 * WorkspaceHost.tsx
 *
 * PURPOSE:
 * Institutional Workspace Host
 *
 * DESCRIPTION:
 * Defines the authoritative host boundary between the Institutional Shell
 * center region and the existing Workbench operating surface.
 *
 * The Workspace Host owns only:
 *
 * - Workbench runtime lifecycle integration
 * - Workbench center surface mounting
 *
 * The Workspace Host does not own:
 *
 * - Institutional Shell geometry
 * - Shell regions
 * - Workspace platform implementation
 * - Workspace loading implementation
 * - Docking implementation
 * - Panel implementation
 * - Tab implementation
 * - Workspace persistence implementation
 *
 * AUTHORITATIVE COMPOSITION:
 *
 * ShellLayout
 *     ↓
 * CenterRegion
 *     ↓
 * WorkspaceHost
 *     ↓
 * WorkbenchCenter
 *     ↓
 * Existing Workbench / Workspace Infrastructure
 *
 * OWNERSHIP:
 * Workbench Integration Boundary
 *
 ******************************************************************************/

/*=============================================================================
    IMPORTS
=============================================================================*/

import {
    useEffect
} from "react";

import type {
    ReactElement
} from "react";

import {
    WorkbenchCenter
} from "./WorkbenchCenter";

import {
    workbenchRuntime
} from "../runtime/workbench-runtime";

import {

    WindowHost

} from "../../windowing";

/*=============================================================================
    COMPONENT
=============================================================================*/

export function WorkspaceHost(): ReactElement {

    
    useEffect(() => {

        workbenchRuntime.initialize();

        return () => {

            workbenchRuntime.dispose();

        };

    }, []);

    return (

        <section
            className="corei-workspace-host"
            data-workspace-host="institutional"
            data-workspace-surface="workbench"
        >
            <WindowHost>
            
                <WorkbenchCenter />

             </WindowHost>

        </section>

    );

}

export default WorkspaceHost;
