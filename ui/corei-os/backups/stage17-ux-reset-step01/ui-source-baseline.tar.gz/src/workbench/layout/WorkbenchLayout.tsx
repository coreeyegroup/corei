export function WorkbenchLayout(): React.JSX.Element {

    return (

        <div className="flex h-screen w-screen overflow-hidden">

            <div id="activity-bar"/>

            <div id="sidebar"/>

            <div className="flex flex-1 flex-col">

                <div id="editor-area" className="flex-1"/>

                <div id="bottom-panel"/>

            </div>

            <div id="status-bar"/>

        </div>

    );

}
