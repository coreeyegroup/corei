export * from "./NewsPanel";
