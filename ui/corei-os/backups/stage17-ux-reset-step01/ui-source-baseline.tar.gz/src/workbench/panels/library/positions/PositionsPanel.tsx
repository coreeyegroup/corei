import type { ReactElement } from "react";

/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-22
 *
 * PANEL
 * PositionsPanel
 * ============================================================================
 */

export function PositionsPanel(): ReactElement {

    return (

        <div
            style={{

                width: "100%",

                height: "100%",

                display: "flex",

                alignItems: "center",

                justifyContent: "center",

                color: "#bdbdbd",

                fontSize: 18

            }}
        >

            Positions Panel

        </div>

    );

}
