export function CommandPalette(): React.JSX.Element {

    return <></>;

}
