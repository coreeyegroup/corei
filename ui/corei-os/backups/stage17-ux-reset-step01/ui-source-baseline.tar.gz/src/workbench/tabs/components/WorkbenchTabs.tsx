/**
 * ============================================================================
 * STAGE-25
 * STEP-02
 * BUILD UNIT-04
 *
 * FILE
 * WorkbenchTabs.tsx
 * ============================================================================
 */

import { X } from "lucide-react";

import {

    useTabState

} from "../state/tab-state";

import {

    tabRuntime

} from "../runtime/tab-runtime";

export function WorkbenchTabs(): React.JSX.Element {

    const {

        tabs,
        activeTab

    } = useTabState();

    return (

        <div
            style={{
                height: 34,
                display: "flex",
                background: "#252526",
                borderBottom: "1px solid #313131",
                overflowX: "auto"
            }}
        >

            {

                tabs.map(tab => (

                    <button

                        key={tab.id}

                        onClick={() =>

                            tabRuntime.activate(

                                tab.id

                            )

                        }

                        style={{

                            display: "flex",

                            alignItems: "center",

                            justifyContent: "space-between",

                            gap: 10,

                            minWidth: 180,

                            padding: "0 12px",

                            border: 0,

                            cursor: "pointer",

                            background:

                                activeTab === tab.id

                                    ? "#1e1e1e"

                                    : "#2d2d30",

                            color:

                                activeTab === tab.id

                                    ? "#ffffff"

                                    : "#bdbdbd",

                            borderTop:

                                activeTab === tab.id

                                    ? "2px solid #007ACC"

                                    : "2px solid transparent"

                        }}

                    >

                        <span>

                            {tab.title}

                        </span>

                        {

                            tab.closable && (

                                <X

                                    size={13}

                                    onClick={event => {

                                        event.stopPropagation();

                                        tabRuntime.close(

                                            tab.id

                                        );

                                    }}

                                />

                            )

                        }

                    </button>

                ))

            }

        </div>

    );

}
