export function StatusBar(): React.JSX.Element {

    return <></>;

}
