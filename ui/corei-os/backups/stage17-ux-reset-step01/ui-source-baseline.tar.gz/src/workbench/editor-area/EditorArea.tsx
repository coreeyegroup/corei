export function EditorArea(): React.JSX.Element {

    return <></>;

}
