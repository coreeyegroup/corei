export * from "./capability-manager";
