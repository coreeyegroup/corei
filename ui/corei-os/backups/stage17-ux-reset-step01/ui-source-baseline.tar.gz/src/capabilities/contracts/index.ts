export * from "./capability-contract";
