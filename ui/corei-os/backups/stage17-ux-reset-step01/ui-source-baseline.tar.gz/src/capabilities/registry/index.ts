export * from "./capability-registry";
