#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing Docker Engine"
echo "========================================="

sudo apt-get update

sudo apt-get install -y \
ca-certificates \
curl \
gnupg \
lsb-release

sudo install -m 0755 -d /etc/apt/keyrings

curl -fsSL \
https://download.docker.com/linux/ubuntu/gpg \
| sudo gpg --dearmor \
-o /etc/apt/keyrings/docker.gpg

sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
"deb [arch=$(dpkg --print-architecture) \
signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/ubuntu \
$(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
| sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update

sudo apt-get install -y \
docker-ce \
docker-ce-cli \
containerd.io \
docker-buildx-plugin \
docker-compose-plugin

sudo systemctl enable docker
sudo systemctl start docker

echo
echo "Docker installation completed."

docker --version

