#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing Falco"
echo "========================================="

helm repo add falcosecurity https://falcosecurity.github.io/charts
helm repo update

kubectl create namespace logging --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install falco falcosecurity/falco \
  --namespace logging

echo
echo "Falco installation completed."

kubectl get pods -n logging
