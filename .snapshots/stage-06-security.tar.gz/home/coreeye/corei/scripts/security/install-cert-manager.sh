#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing cert-manager"
echo "========================================="

helm repo add jetstack https://charts.jetstack.io
helm repo update

kubectl create namespace cert-manager --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --set installCRDs=true

echo
echo "cert-manager installation completed."

kubectl get pods -n cert-manager
