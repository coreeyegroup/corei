#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Configuring Kong"
echo "========================================="

kubectl apply -f \
~/corei/kubernetes/security/kong/jwt-plugin.yaml

echo
echo "Kong configuration completed."

kubectl get kongplugins -A || true
