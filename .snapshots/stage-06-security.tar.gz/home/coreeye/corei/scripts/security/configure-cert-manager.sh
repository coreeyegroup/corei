#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Configuring cert-manager"
echo "========================================="

kubectl apply -f \
~/corei/kubernetes/security/cert-manager/cluster-issuer.yaml

echo
echo "cert-manager configuration completed."

kubectl get clusterissuers
