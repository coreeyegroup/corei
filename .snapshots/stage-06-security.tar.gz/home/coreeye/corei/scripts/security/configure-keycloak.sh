#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Configuring Keycloak"
echo "========================================="

KEYCLOAK_POD=$(kubectl get pods -n auth \
  -l app.kubernetes.io/name=keycloak \
  -o jsonpath="{.items[0].metadata.name}")

echo "Waiting for Keycloak readiness..."

kubectl wait \
  --for=condition=Ready \
  pod/"$KEYCLOAK_POD" \
  -n auth \
  --timeout=600s

ADMIN_PASSWORD="admin123"

ACCESS_TOKEN=$(kubectl exec -n auth "$KEYCLOAK_POD" -- \
  curl -s \
  -X POST \
  http://localhost:8080/realms/master/protocol/openid-connect/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "username=admin" \
  -d "password=$ADMIN_PASSWORD" \
  -d 'grant_type=password' \
  -d 'client_id=admin-cli' \
  | jq -r '.access_token')

kubectl cp \
~/corei/infrastructure/components/keycloak/realms/trading-platform.json \
auth/"$KEYCLOAK_POD":/tmp/trading-platform.json

kubectl exec -n auth "$KEYCLOAK_POD" -- \
  curl -s \
  -X POST \
  http://localhost:8080/admin/realms \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  --data @/tmp/trading-platform.json

echo
echo "Keycloak configuration completed."
