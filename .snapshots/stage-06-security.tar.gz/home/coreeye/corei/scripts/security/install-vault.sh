#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing HashiCorp Vault"
echo "========================================="

helm repo add hashicorp https://helm.releases.hashicorp.com
helm repo update

kubectl create namespace vault --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install vault hashicorp/vault \
  --namespace vault \
  --set "server.dev.enabled=false"

echo
echo "Vault installation completed."

kubectl get pods -n vault
