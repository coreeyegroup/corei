#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Security Runtime Validation"
echo "========================================="

VAULT_POD=$(kubectl get pods -n vault \
  -l app.kubernetes.io/name=vault \
  -o jsonpath="{.items[0].metadata.name}")

kubectl exec -n vault "$VAULT_POD" -- vault status

kubectl exec -n vault "$VAULT_POD" -- \
  vault kv get secret/trading/db || true

kubectl exec -n vault "$VAULT_POD" -- \
  vault kv get secret/trading/alerting || true

kubectl get pods -n auth

kubectl get peerauthentication -A

kubectl get pods -n istio-system

kubectl get pods -n platform

kubectl get pods -n cert-manager

kubectl get pods -n logging

echo
echo "Security validation completed."
