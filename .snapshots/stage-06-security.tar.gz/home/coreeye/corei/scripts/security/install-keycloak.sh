#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing Keycloak"
echo "========================================="

helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update

kubectl create namespace auth --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install keycloak bitnami/keycloak \
  --namespace auth \
  --set auth.adminUser=admin \
  --set auth.adminPassword=admin123

echo
echo "Keycloak installation completed."

kubectl get pods -n auth
