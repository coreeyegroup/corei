#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Configuring Vault"
echo "========================================="

VAULT_POD=$(kubectl get pods -n vault \
  -l app.kubernetes.io/name=vault \
  -o jsonpath="{.items[0].metadata.name}")

if kubectl exec -n vault "$VAULT_POD" -- \
  vault status | grep -q "Initialized.*true"; then

  echo "Vault already initialized."

else

  INIT_FILE="/root/.vault-init-$(date +%Y%m%d-%H%M%S).json"

  kubectl exec -n vault "$VAULT_POD" -- \
    vault operator init -format=json \
    > "$INIT_FILE"

  echo
  echo "Vault initialized:"
  echo "$INIT_FILE"

  UNSEAL_KEY_1=$(jq -r '.unseal_keys_b64[0]' "$INIT_FILE")
  UNSEAL_KEY_2=$(jq -r '.unseal_keys_b64[1]' "$INIT_FILE")
  UNSEAL_KEY_3=$(jq -r '.unseal_keys_b64[2]' "$INIT_FILE")

  kubectl exec -n vault "$VAULT_POD" -- \
    vault operator unseal "$UNSEAL_KEY_1"

  kubectl exec -n vault "$VAULT_POD" -- \
    vault operator unseal "$UNSEAL_KEY_2"

  kubectl exec -n vault "$VAULT_POD" -- \
    vault operator unseal "$UNSEAL_KEY_3"

  echo
  echo "SAVE $INIT_FILE TO OFFLINE STORAGE NOW"

fi

ROOT_TOKEN=$(jq -r '.root_token' /root/.vault-init-*.json | head -n 1)

kubectl exec -n vault "$VAULT_POD" -- \
  vault login "$ROOT_TOKEN"

kubectl exec -n vault "$VAULT_POD" -- \
  vault secrets enable -path=secret kv-v2 || true

kubectl exec -n vault "$VAULT_POD" -- \
  vault auth enable kubernetes || true

kubectl cp \
~/corei/infrastructure/components/vault/policies/trading-policy.hcl \
vault/"$VAULT_POD":/tmp/trading-policy.hcl

kubectl exec -n vault "$VAULT_POD" -- \
  vault policy write trading-policy /tmp/trading-policy.hcl

echo
echo "Vault configuration completed."

kubectl exec -n vault "$VAULT_POD" -- vault status
