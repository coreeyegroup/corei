#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing Kong"
echo "========================================="

helm repo add kong https://charts.konghq.com
helm repo update

kubectl create namespace platform --dry-run=client -o yaml | kubectl apply -f -

helm upgrade --install kong kong/kong \
  --namespace platform \
  --set ingressController.installCRDs=false

echo
echo "Kong installation completed."

kubectl get pods -n platform
