#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Configuring Istio"
echo "========================================="

kubectl apply -f \
~/corei/kubernetes/security/mtls/strict-mtls.yaml

echo
echo "Istio mTLS configuration completed."

kubectl get peerauthentication -A
