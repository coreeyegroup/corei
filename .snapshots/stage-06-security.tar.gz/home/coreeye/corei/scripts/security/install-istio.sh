#!/usr/bin/env bash

set -euo pipefail

echo "========================================="
echo "Installing Istio"
echo "========================================="

curl -L https://istio.io/downloadIstio | sh -

ISTIO_DIR=$(find . -maxdepth 1 -type d -name "istio-*" | head -n 1)

sudo mv "$ISTIO_DIR/bin/istioctl" /usr/local/bin/

istioctl install -y

kubectl label namespace market-data istio-injection=enabled --overwrite
kubectl label namespace strategy istio-injection=enabled --overwrite
kubectl label namespace execution istio-injection=enabled --overwrite
kubectl label namespace trading-infra istio-injection=enabled --overwrite

echo
echo "Istio installation completed."

kubectl get pods -n istio-system
