# Corei Platform Schemas

Contains all event and database schemas.
