# Corei Platform Services

Contains all business and platform services.
