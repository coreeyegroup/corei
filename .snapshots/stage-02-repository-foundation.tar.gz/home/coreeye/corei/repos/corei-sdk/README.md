# Corei Platform SDK

Shared runtime SDK used across all services.
