# Corei Platform Infrastructure

Contains Terraform, Kubernetes configs, and infrastructure automation.
